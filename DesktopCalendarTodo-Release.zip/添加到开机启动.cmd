@echo off
setlocal
if not exist "%~dp0DesktopCalendarTodo.exe" (
  echo ERROR: DesktopCalendarTodo.exe not found in this folder.
  exit /b 1
)
set "WIDGET_EXE=%~dp0DesktopCalendarTodo.exe"
set "WIDGET_LNK=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\DesktopCalendarTodo.lnk"
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$w=New-Object -ComObject WScript.Shell;$s=$w.CreateShortcut($env:WIDGET_LNK);$s.TargetPath=$env:WIDGET_EXE;$s.WorkingDirectory=(Split-Path -Parent $env:WIDGET_EXE);$s.Save();if(Test-Path $env:WIDGET_LNK){Write-Output 'SUCCESS: Startup has been enabled.';exit 0}else{Write-Output 'ERROR: shortcut was not created.';exit 1}"
if %errorlevel% neq 0 exit /b %errorlevel%