@echo off
setlocal
set "WIDGET_LNK=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\DesktopCalendarTodo.lnk"
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "if(Test-Path $env:WIDGET_LNK){Remove-Item $env:WIDGET_LNK -Force;if(Test-Path $env:WIDGET_LNK){Write-Output 'ERROR: could not remove shortcut.';exit 1}else{Write-Output 'SUCCESS: Startup has been disabled.';exit 0}}else{Write-Output 'SUCCESS: Startup has been disabled.';exit 0}"
if %errorlevel% neq 0 exit /b %errorlevel%