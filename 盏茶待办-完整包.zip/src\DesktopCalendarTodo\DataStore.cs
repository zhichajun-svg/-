using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace DesktopCalendarTodo
{
    public static class DataStore
    {
        public static string DefaultDir()
        {
            // 数据固定保存到 E:\盏茶待办；若 E 盘不存在则回退到程序目录。
            try
            {
                if (Directory.Exists("E:\\")) return "E:\\盏茶待办";
            }
            catch { }
            string exeDir = AppDomain.CurrentDomain.BaseDirectory;
            return exeDir;
        }

        public static string DataFile(string dir)
        {
            return Path.Combine(dir, "planner-data.json");
        }

        static void ReadStrArray(JVal parent, string key, List<string> target)
        {
            JVal arr = parent.Get(key);
            if (arr == null || arr.Kind != JKind.Array) return;
            for (int i = 0; i < arr.Arr.Count; i++)
                if (arr.Arr[i] != null && arr.Arr[i].Kind == JKind.String) target.Add(arr.Arr[i].Str);
        }

        static JVal StrArray(List<string> list)
        {
            JVal a = JVal.NewArr();
            for (int i = 0; i < list.Count; i++) a.Arr.Add(JVal.NewStr(list[i]));
            return a;
        }

        // ---- 加载 ----
        public static PlannerData Load(string dir)
        {
            PlannerData data = new PlannerData();
            string path = DataFile(dir);
            if (!File.Exists(path)) return data;

            try
            {
                string text = File.ReadAllText(path, Encoding.UTF8);
                JVal root = Json.Parse(text);
                if (root == null || root.Kind != JKind.Object) return data;

                // 旧版便签：原样保留
                JVal notes = root.Get("notes");
                if (notes != null) data.LegacyNotes = notes;
                data.NotesTitle = root.GetStr("notesTitle", "");
                data.NotesBody = root.GetStr("notesBody", "");
                data.NotesBodyRtf = root.GetStr("notesBodyRtf", "");

                JVal settings = root.Get("settings");
                if (settings != null && settings.Kind == JKind.Object)
                {
                    AppSettings s = data.Settings;
                    s.Left = settings.GetNum("left", -1);
                    s.Top = settings.GetNum("top", -1);
                    s.Width = settings.GetNum("width", 1120);
                    s.Height = settings.GetNum("height", 720);
                    s.ScheduleWidth = settings.GetNum("scheduleWidth", 400);
                    s.TodoWidth = settings.GetNum("todoWidth", 330);
                    s.CalendarWidth = settings.GetNum("calendarWidth", 342);
                    s.Background = settings.GetStr("background", "#E6191A22");
                    s.Accent = settings.GetStr("accent", "#4F8CFF");
                    s.Opacity = settings.GetNum("opacity", 0.95);
                    s.Topmost = settings.GetBool("topmost", false);
                    s.EdgeDock = settings.GetBool("edgeDock", true);
                    s.LastMonthlyReport = settings.GetStr("lastMonthlyReport", "");
                    s.DividerStyle = settings.GetStr("dividerStyle", "dash");
                    if (s.DividerStyle != "solid" && s.DividerStyle != "dash" && s.DividerStyle != "double"
                        && s.DividerStyle != "star" && s.DividerStyle != "dot") s.DividerStyle = "dash";
                    s.ViewMode = settings.GetStr("viewMode", "month");
                    if (s.ViewMode != "month" && s.ViewMode != "week" && s.ViewMode != "day") s.ViewMode = "month";
                    JVal cats = settings.Get("categories");
                    if (cats != null && cats.Kind == JKind.Array)
                    {
                        for (int k = 0; k < cats.Arr.Count; k++)
                        {
                            JVal c = cats.Arr[k];
                            if (c != null && c.Kind == JKind.String && !string.IsNullOrEmpty(c.Str))
                                s.Categories.Add(c.Str);
                        }
                    }
                    if (s.Width < 820) s.Width = 1120;
                    if (s.Height < 560) s.Height = 720;
                    JVal delCats = settings.Get("deletedCategories");
                    if (delCats != null && delCats.Kind == JKind.Array)
                    {
                        for (int k = 0; k < delCats.Arr.Count; k++)
                        {
                            JVal c = delCats.Arr[k];
                            if (c != null && c.Kind == JKind.String && !string.IsNullOrEmpty(c.Str))
                                s.DeletedCategories.Add(c.Str);
                        }
                    }
                    s.MonthWidth = settings.GetNum("monthWidth", s.Width);
                    s.MonthHeight = settings.GetNum("monthHeight", s.Height);
                    s.WeekWidth = settings.GetNum("weekWidth", s.Width);
                    s.WeekHeight = settings.GetNum("weekHeight", s.Height);
                    s.DayLeft = settings.GetNum("dayLeft", -1);
                    s.DayTop = settings.GetNum("dayTop", -1);
                    s.DayWidth = settings.GetNum("dayWidth", 0);
                    s.DayHeight = settings.GetNum("dayHeight", 0);
                    JVal catColors = settings.Get("categoryColors");
                    if (catColors != null && catColors.Kind == JKind.Object)
                    {
                        for (int k = 0; k < catColors.Obj.Count; k++)
                        {
                            JVal cv = catColors.Obj[k].Value;
                            if (cv != null && cv.Kind == JKind.String && !string.IsNullOrEmpty(cv.Str))
                                s.CategoryColors[catColors.Obj[k].Key] = cv.Str;
                        }
                    }
                    ReadStrArray(settings, "bgHistory", s.BgHistory);
                    ReadStrArray(settings, "accentHistory", s.AccentHistory);
                    ReadStrArray(settings, "skins", s.Skins);
                }

                JVal scheds = root.Get("schedules");
                if (scheds != null && scheds.Kind == JKind.Object)
                {
                    for (int i = 0; i < scheds.Obj.Count; i++)
                    {
                        string dateKey = scheds.Obj[i].Key;
                        JVal arr = scheds.Obj[i].Value;
                        if (arr == null || arr.Kind != JKind.Array) continue;
                        List<ScheduleItem> list = new List<ScheduleItem>();
                        for (int j = 0; j < arr.Arr.Count; j++)
                        {
                            ScheduleItem item = ParseSchedule(arr.Arr[j]);
                            if (item != null) list.Add(item);
                        }
                        data.Schedules[dateKey] = list;
                    }
                }

                JVal todos = root.Get("todos");
                if (todos != null && todos.Kind == JKind.Array)
                {
                    for (int i = 0; i < todos.Arr.Count; i++)
                    {
                        TodoItem t = ParseTodo(todos.Arr[i]);
                        if (t != null) data.Todos.Add(t);
                    }
                }

                // 升级逻辑：若 schedules/todos 缺失但旧版字段存在，也尝试读取（兼容 v1）
                if (data.Schedules.Count == 0 && root.Get("schedule") != null)
                {
                    JVal old = root.Get("schedule");
                    if (old.Kind == JKind.Object)
                    {
                        for (int i = 0; i < old.Obj.Count; i++)
                        {
                            JVal arr = old.Obj[i].Value;
                            if (arr == null || arr.Kind != JKind.Array) continue;
                            List<ScheduleItem> list = new List<ScheduleItem>();
                            for (int j = 0; j < arr.Arr.Count; j++)
                            {
                                ScheduleItem item = ParseSchedule(arr.Arr[j]);
                                if (item != null) list.Add(item);
                            }
                            data.Schedules[old.Obj[i].Key] = list;
                        }
                    }
                }
                if (data.Todos.Count == 0 && root.Get("todo") != null)
                {
                    JVal old = root.Get("todo");
                    if (old.Kind == JKind.Array)
                    {
                        for (int i = 0; i < old.Arr.Count; i++)
                        {
                            TodoItem t = ParseTodo(old.Arr[i]);
                            if (t != null) data.Todos.Add(t);
                        }
                    }
                }
            }
            catch (Exception)
            {
                // 数据损坏时保留内存中的空数据，不覆盖原文件（下次保存时才写）
            }
            return data;
        }

        static ScheduleItem ParseSchedule(JVal v)
        {
            if (v == null || v.Kind != JKind.Object) return null;
            ScheduleItem item = new ScheduleItem();
            item.Id = v.GetStr("id", Guid.NewGuid().ToString("N"));
            item.Text = v.GetStr("text", "");
            item.Time = v.GetStr("time", "");
            item.EndTime = v.GetStr("endTime", "");
            item.Done = v.GetBool("done", false);
            item.Category = v.GetStr("category", "日常");
            item.CustomColor = v.GetStr("customColor", "");
            JVal subs = v.Get("subtasks");
            if (subs != null && subs.Kind == JKind.Array)
            {
                for (int i = 0; i < subs.Arr.Count; i++)
                {
                    JVal sv = subs.Arr[i];
                    if (sv == null || sv.Kind != JKind.Object) continue;
                    SubtaskItem st = new SubtaskItem();
                    st.Id = sv.GetStr("id", Guid.NewGuid().ToString("N"));
                    st.Text = sv.GetStr("text", "");
                    st.Done = sv.GetBool("done", false);
                    if (!string.IsNullOrEmpty(st.Text)) item.Subtasks.Add(st);
                }
            }
            return item;
        }

        static TodoItem ParseTodo(JVal v)
        {
            if (v == null || v.Kind != JKind.Object) return null;
            TodoItem t = new TodoItem();
            t.Id = v.GetStr("id", Guid.NewGuid().ToString("N"));
            t.Text = v.GetStr("text", "");
            t.Done = v.GetBool("done", false);
            t.Category = v.GetStr("category", "日常");
            t.CustomColor = v.GetStr("customColor", "");
            t.Date = v.GetStr("date", "");
            t.Time = v.GetStr("time", "");
            t.EndTime = v.GetStr("endTime", "");
            JVal tsubs = v.Get("subtasks");
            if (tsubs != null && tsubs.Kind == JKind.Array)
            {
                for (int i = 0; i < tsubs.Arr.Count; i++)
                {
                    JVal sv = tsubs.Arr[i];
                    if (sv == null || sv.Kind != JKind.Object) continue;
                    SubtaskItem st = new SubtaskItem();
                    st.Id = sv.GetStr("id", Guid.NewGuid().ToString("N"));
                    st.Text = sv.GetStr("text", "");
                    st.Done = sv.GetBool("done", false);
                    if (!string.IsNullOrEmpty(st.Text)) t.Subtasks.Add(st);
                }
            }
            return t;
        }

        // ---- 保存 ----
        public static void Save(string dir, PlannerData data)
        {
            try
            {
                if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
                JVal root = JVal.NewObj();
                root.Set("version", (double)data.Version);

                JVal settings = JVal.NewObj();
                AppSettings s = data.Settings;
                settings.Set("left", s.Left);
                settings.Set("top", s.Top);
                settings.Set("width", s.Width);
                settings.Set("height", s.Height);
                settings.Set("scheduleWidth", s.ScheduleWidth);
                settings.Set("todoWidth", s.TodoWidth);
                settings.Set("calendarWidth", s.CalendarWidth);
                settings.Set("background", s.Background);
                settings.Set("accent", s.Accent);
                settings.Set("opacity", s.Opacity);
                settings.Set("topmost", s.Topmost);
                settings.Set("edgeDock", s.EdgeDock);
                settings.Set("lastMonthlyReport", s.LastMonthlyReport);
                settings.Set("dividerStyle", s.DividerStyle);
                settings.Set("viewMode", s.ViewMode);
                settings.Set("monthWidth", s.MonthWidth);
                settings.Set("monthHeight", s.MonthHeight);
                settings.Set("weekWidth", s.WeekWidth);
                settings.Set("weekHeight", s.WeekHeight);
                settings.Set("dayLeft", s.DayLeft);
                settings.Set("dayTop", s.DayTop);
                settings.Set("dayWidth", s.DayWidth);
                settings.Set("dayHeight", s.DayHeight);
                JVal cats = JVal.NewArr();
                for (int i = 0; i < s.Categories.Count; i++) cats.Arr.Add(JVal.NewStr(s.Categories[i]));
                settings.Set("categories", cats);
                JVal delCats = JVal.NewArr();
                for (int i = 0; i < s.DeletedCategories.Count; i++) delCats.Arr.Add(JVal.NewStr(s.DeletedCategories[i]));
                settings.Set("deletedCategories", delCats);
                JVal catColors = JVal.NewObj();
                foreach (KeyValuePair<string, string> kv in s.CategoryColors)
                    catColors.Set(kv.Key, JVal.NewStr(kv.Value));
                settings.Set("categoryColors", catColors);
                settings.Set("bgHistory", StrArray(s.BgHistory));
                settings.Set("accentHistory", StrArray(s.AccentHistory));
                settings.Set("skins", StrArray(s.Skins));
                root.Set("settings", settings);

                JVal scheds = JVal.NewObj();
                foreach (KeyValuePair<string, List<ScheduleItem>> kv in data.Schedules)
                {
                    JVal arr = JVal.NewArr();
                    for (int i = 0; i < kv.Value.Count; i++)
                        arr.Arr.Add(ScheduleToJ(kv.Value[i]));
                    scheds.Set(kv.Key, arr);
                }
                root.Set("schedules", scheds);

                JVal todos = JVal.NewArr();
                for (int i = 0; i < data.Todos.Count; i++)
                    todos.Arr.Add(TodoToJ(data.Todos[i]));
                root.Set("todos", todos);

                // 旧版便签数据原样保留
                if (data.LegacyNotes != null) root.Set("notes", data.LegacyNotes);
                root.Set("notesTitle", data.NotesTitle);
                root.Set("notesBody", data.NotesBody);
                root.Set("notesBodyRtf", data.NotesBodyRtf);

                string json = Json.Stringify(root);
                string path = DataFile(dir);
                string tmp = path + ".tmp";
                File.WriteAllText(tmp, json, new UTF8Encoding(false));
                if (File.Exists(path)) File.Delete(path);
                File.Move(tmp, path);
            }
            catch (Exception)
            {
                // 保存失败静默：下次保存重试
            }
        }

        static JVal ScheduleToJ(ScheduleItem item)
        {
            JVal o = JVal.NewObj();
            o.Set("id", item.Id);
            o.Set("text", item.Text);
            o.Set("time", item.Time);
            o.Set("endTime", item.EndTime);
            o.Set("done", item.Done);
            o.Set("category", item.Category);
            o.Set("customColor", item.CustomColor);
            JVal subs = JVal.NewArr();
            for (int i = 0; i < item.Subtasks.Count; i++)
            {
                JVal so = JVal.NewObj();
                so.Set("id", item.Subtasks[i].Id);
                so.Set("text", item.Subtasks[i].Text);
                so.Set("done", item.Subtasks[i].Done);
                subs.Arr.Add(so);
            }
            o.Set("subtasks", subs);
            return o;
        }

        static JVal TodoToJ(TodoItem t)
        {
            JVal o = JVal.NewObj();
            o.Set("id", t.Id);
            o.Set("text", t.Text);
            o.Set("done", t.Done);
            o.Set("category", t.Category);
            o.Set("customColor", t.CustomColor);
            o.Set("date", t.Date);
            o.Set("time", t.Time);
            o.Set("endTime", t.EndTime);
            if (t.Subtasks != null && t.Subtasks.Count > 0)
            {
                JVal subs = JVal.NewArr();
                for (int i = 0; i < t.Subtasks.Count; i++)
                {
                    JVal so = JVal.NewObj();
                    so.Set("id", t.Subtasks[i].Id);
                    so.Set("text", t.Subtasks[i].Text);
                    so.Set("done", t.Subtasks[i].Done);
                    subs.Arr.Add(so);
                }
                o.Set("subtasks", subs);
            }
            return o;
        }
    }
}
