using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Controls.Primitives;

namespace DesktopCalendarTodo
{
    // 备忘录文件导出：Word（.docx，手写最小 OOXML 包）与 PDF（A4 单页，内嵌高清图片）
    public partial class MainWindow
    {
        // ============ 导出菜单 ============
        void ShowExportFileMenu(FrameworkElement anchor)
        {
            ContextMenu cm = new ContextMenu();
            cm.PlacementTarget = anchor;
            cm.Placement = PlacementMode.Top;
            cm.FontFamily = Ui.Font;
            cm.FontSize = 12;
            MenuItem m1 = new MenuItem();
            m1.Header = "Word 文档 (.docx)";
            AutomationProperties.SetName(m1, "NotesExportDocx");
            m1.Click += delegate { ExportNotesDocx(); };
            MenuItem m2 = new MenuItem();
            m2.Header = "PDF 文件 (.pdf)";
            AutomationProperties.SetName(m2, "NotesExportPdf");
            m2.Click += delegate { ExportNotesPdf(); };
            cm.Items.Add(m1);
            cm.Items.Add(m2);
            cm.IsOpen = true;
        }

        // 导出文件前询问：是否按公文版式
        bool AskGongwenLayout()
        {
            return Dialogs.Confirm(this, "导出格式", "是否按公文版式导出？\n（A4、页边距 上37/下35/左28/右26mm、行距 28 磅）");
        }

        void ExportNotesDocx()
        {
            if (_data.NotesTitle.Length == 0 && _data.NotesBody.Length == 0)
            {
                Flash("备忘录内容为空");
                return;
            }
            Microsoft.Win32.SaveFileDialog sfd = new Microsoft.Win32.SaveFileDialog();
            sfd.Title = "导出 Word 文档";
            sfd.Filter = "Word 文档|*.docx";
            sfd.FileName = "备忘录-" + DateTime.Now.ToString("yyyyMMdd-HHmm") + ".docx";
            sfd.InitialDirectory = _dataDir;
            if (sfd.ShowDialog() != true) return;
            bool gongwen = AskGongwenLayout();
            try
            {
                File.WriteAllBytes(sfd.FileName, BuildDocxBytes(gongwen));
                Flash("已导出：" + sfd.FileName);
            }
            catch (Exception ex)
            {
                Flash("导出失败：" + ex.Message);
            }
        }

        void ExportNotesPdf()
        {
            if (_data.NotesTitle.Length == 0 && _data.NotesBody.Length == 0)
            {
                Flash("备忘录内容为空");
                return;
            }
            Microsoft.Win32.SaveFileDialog sfd = new Microsoft.Win32.SaveFileDialog();
            sfd.Title = "导出 PDF 文件";
            sfd.Filter = "PDF 文件|*.pdf";
            sfd.FileName = "备忘录-" + DateTime.Now.ToString("yyyyMMdd-HHmm") + ".pdf";
            sfd.InitialDirectory = _dataDir;
            if (sfd.ShowDialog() != true) return;
            try
            {
                File.WriteAllBytes(sfd.FileName, BuildPdfBytes());
                Flash("已导出：" + sfd.FileName);
            }
            catch (Exception ex)
            {
                Flash("导出失败：" + ex.Message);
            }
        }

        // ============ DOCX ============
        static string XmlEscape(string s)
        {
            if (s == null) return "";
            StringBuilder sb = new StringBuilder(s.Length + 16);
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if (c == '&') sb.Append("&amp;");
                else if (c == '<') sb.Append("&lt;");
                else if (c == '>') sb.Append("&gt;");
                else if (c == '"') sb.Append("&quot;");
                else if (c == '\'' || c == '"') sb.Append(c);
                else if (c < 0x20 && c != '\t') sb.Append(' ');
                else sb.Append(c);
            }
            return sb.ToString();
        }

        string DocxParagraph(string text, string font, int halfPoints, bool center, bool firstLineIndent, string asciiFont, bool gongwen)
        {
            if (string.IsNullOrEmpty(asciiFont)) asciiFont = font;
            StringBuilder sb = new StringBuilder();
            sb.Append("<w:p><w:pPr>");
            if (center) sb.Append("<w:jc w:val=\"center\"/>");
            // 公文版式：行距固定值 28 磅（560 twips，exact）；普通版式沿用 1.5 倍行距
            if (gongwen) sb.Append("<w:spacing w:line=\"560\" w:lineRule=\"exact\" w:after=\"0\"/>");
            else sb.Append("<w:spacing w:line=\"360\" w:lineRule=\"auto\" w:after=\"120\"/>");
            if (firstLineIndent) sb.Append("<w:ind w:firstLine=\"640\"/>");
            sb.Append("</w:pPr><w:r><w:rPr><w:rFonts w:ascii=\"").Append(asciiFont)
              .Append("\" w:hAnsi=\"").Append(asciiFont)
              .Append("\" w:eastAsia=\"").Append(font)
              .Append("\"/><w:sz w:val=\"").Append(halfPoints).Append("\"/><w:szCs w:val=\"")
              .Append(halfPoints).Append("\"/></w:rPr><w:t xml:space=\"preserve\">")
              .Append(XmlEscape(text)).Append("</w:t></w:r></w:p>");
            return sb.ToString();
        }

        byte[] BuildDocxBytes(bool gongwen)
        {
            string titleFont = "方正小标宋_GBK";
            string bodyFont = "方正仿宋_GBK";

            StringBuilder doc = new StringBuilder();
            doc.Append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
            doc.Append("<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>");
            if (_data.NotesTitle.Length > 0)
            {
                if (gongwen) doc.Append(DocxParagraph("", titleFont, 44, false, false, titleFont, true)); // 公文：标题上空一行
                doc.Append(DocxParagraph(_data.NotesTitle, titleFont, 44, true, false, titleFont, gongwen)); // 二号
            }
            string body = _data.NotesBody.Replace("\r\n", "\n").Replace('\r', '\n');
            string[] lines = body.Split('\n');
            for (int i = 0; i < lines.Length; i++)
                doc.Append(DocxParagraph(lines[i], bodyFont, 32, false, false, gongwen ? "Times New Roman" : bodyFont, gongwen)); // 三号
            doc.Append("<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/><w:pgMar w:top=\"" + (gongwen ? "2098" : "1440")
                + "\" w:right=\"" + (gongwen ? "1474" : "1440") + "\" w:bottom=\"" + (gongwen ? "1984" : "1440")
                + "\" w:left=\"" + (gongwen ? "1587" : "1440") + "\" w:header=\"851\" w:footer=\"992\" w:gutter=\"0\"/></w:sectPr>");
            doc.Append("</w:body></w:document>");

            string contentTypes = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
                + "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
                + "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"
                + "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>"
                + "</Types>";
            string rels = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>"
                + "</Relationships>";

            List<KeyValuePair<string, byte[]>> entries = new List<KeyValuePair<string, byte[]>>();
            entries.Add(new KeyValuePair<string, byte[]>("[Content_Types].xml", Encoding.UTF8.GetBytes(contentTypes)));
            entries.Add(new KeyValuePair<string, byte[]>("_rels/.rels", Encoding.UTF8.GetBytes(rels)));
            entries.Add(new KeyValuePair<string, byte[]>("word/document.xml", Encoding.UTF8.GetBytes(doc.ToString())));

            MemoryStream ms = new MemoryStream();
            MiniZip.Write(ms, entries);
            return ms.ToArray();
        }

        // ============ PDF（A4 单页，内嵌图片） ============
        byte[] BuildPdfBytes()
        {
            RenderTargetBitmap rtb = RenderNotesBitmap("gongwen"); // 公文模板 A4 300 DPI
            JpegBitmapEncoder jenc = new JpegBitmapEncoder();
            jenc.QualityLevel = 88;
            jenc.Frames.Add(BitmapFrame.Create(rtb));
            MemoryStream jms = new MemoryStream();
            jenc.Save(jms);
            byte[] jpeg = jms.ToArray();

            double pageW = 595.28, pageH = 841.89; // A4 pt
            MemoryStream ms = new MemoryStream();
            List<long> offsets = new List<long>();
            Action<string> w = delegate(string s)
            {
                byte[] b = Encoding.ASCII.GetBytes(s);
                ms.Write(b, 0, b.Length);
            };

            w("%PDF-1.4\n");
            offsets.Add(ms.Position);
            w("1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n");
            offsets.Add(ms.Position);
            w("2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n");
            offsets.Add(ms.Position);
            w(string.Format("3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 {0:0.##} {1:0.##}]/Resources<</XObject<</Im0 4 0 R>>>>/Contents 5 0 R>>endobj\n", pageW, pageH));
            offsets.Add(ms.Position);
            w(string.Format("4 0 obj<</Type/XObject/Subtype/Image/Width {0}/Height {1}/ColorSpace/DeviceRGB/BitsPerComponent 8/Filter/DCTDecode/Length {2}>>stream\n", rtb.PixelWidth, rtb.PixelHeight, jpeg.Length));
            ms.Write(jpeg, 0, jpeg.Length);
            w("\nendstream endobj\n");
            string content = string.Format("q {0:0.##} 0 0 {1:0.##} 0 0 cm /Im0 Do Q", pageW, pageH);
            offsets.Add(ms.Position);
            w(string.Format("5 0 obj<</Length {0}>>stream\n{1}\nendstream endobj\n", content.Length, content));
            long xref = ms.Position;
            w("xref\n0 6\n0000000000 65535 f \n");
            for (int i = 0; i < offsets.Count; i++) w(offsets[i].ToString("D10") + " 00000 n \n");
            w(string.Format("trailer<</Size 6/Root 1 0 R>>\nstartxref\n{0}\n%%EOF", xref));
            return ms.ToArray();
        }
    }

    // 极简 ZIP 写入器（仅 store，不压缩；用于生成 .docx）
    static class MiniZip
    {
        static uint[] _crcTable;

        static uint[] CrcTable()
        {
            if (_crcTable != null) return _crcTable;
            _crcTable = new uint[256];
            for (uint i = 0; i < 256; i++)
            {
                uint c = i;
                for (int k = 0; k < 8; k++) c = ((c & 1) != 0) ? (0xEDB88320u ^ (c >> 1)) : (c >> 1);
                _crcTable[i] = c;
            }
            return _crcTable;
        }

        static uint Crc32(byte[] data)
        {
            uint[] t = CrcTable();
            uint c = 0xFFFFFFFFu;
            for (int i = 0; i < data.Length; i++) c = t[(c ^ data[i]) & 0xFF] ^ (c >> 8);
            return c ^ 0xFFFFFFFFu;
        }

        static void U16(Stream s, int v)
        {
            s.WriteByte((byte)(v & 0xFF));
            s.WriteByte((byte)((v >> 8) & 0xFF));
        }

        static void U32(Stream s, uint v)
        {
            s.WriteByte((byte)(v & 0xFF));
            s.WriteByte((byte)((v >> 8) & 0xFF));
            s.WriteByte((byte)((v >> 16) & 0xFF));
            s.WriteByte((byte)((v >> 24) & 0xFF));
        }

        public static void Write(Stream s, List<KeyValuePair<string, byte[]>> entries)
        {
            List<long> offsets = new List<long>();
            List<uint> crcs = new List<uint>();
            for (int i = 0; i < entries.Count; i++)
            {
                offsets.Add(s.Position);
                byte[] name = Encoding.UTF8.GetBytes(entries[i].Key);
                byte[] data = entries[i].Value;
                uint crc = Crc32(data);
                crcs.Add(crc);
                U32(s, 0x04034b50);
                U16(s, 20);
                U16(s, 0x0800); // UTF-8 文件名
                U16(s, 0);      // store
                U16(s, 0);
                U16(s, 0);
                U32(s, crc);
                U32(s, (uint)data.Length);
                U32(s, (uint)data.Length);
                U16(s, name.Length);
                U16(s, 0);
                s.Write(name, 0, name.Length);
                s.Write(data, 0, data.Length);
            }
            long cdStart = s.Position;
            for (int i = 0; i < entries.Count; i++)
            {
                byte[] name = Encoding.UTF8.GetBytes(entries[i].Key);
                U32(s, 0x02014b50);
                U16(s, 20);
                U16(s, 20);
                U16(s, 0x0800);
                U16(s, 0);
                U16(s, 0);
                U16(s, 0);
                U32(s, crcs[i]);
                U32(s, (uint)entries[i].Value.Length);
                U32(s, (uint)entries[i].Value.Length);
                U16(s, name.Length);
                U16(s, 0);
                U16(s, 0);
                U16(s, 0);
                U16(s, 0);
                U32(s, 0);
                U32(s, (uint)offsets[i]);
                s.Write(name, 0, name.Length);
            }
            long cdEnd = s.Position;
            U32(s, 0x06054b50);
            U16(s, 0);
            U16(s, 0);
            U16(s, entries.Count);
            U16(s, entries.Count);
            U32(s, (uint)(cdEnd - cdStart));
            U32(s, (uint)cdStart);
            U16(s, 0);
        }
    }
}
