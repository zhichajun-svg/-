using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace DesktopCalendarTodo
{
    // 极简有序 JSON 模型：保留字段顺序，容忍未知字段（用于旧数据兼容）。
    public enum JKind { Null, Bool, Number, String, Array, Object }

    public sealed class JVal
    {
        public JKind Kind = JKind.Null;
        public bool Bool;
        public double Number;
        public string Str = "";
        public List<JVal> Arr;
        public List<KeyValuePair<string, JVal>> Obj; // 有序

        public static JVal NewNull() { return new JVal(); }
        public static JVal NewBool(bool b) { JVal v = new JVal(); v.Kind = JKind.Bool; v.Bool = b; return v; }
        public static JVal NewNum(double n) { JVal v = new JVal(); v.Kind = JKind.Number; v.Number = n; return v; }
        public static JVal NewStr(string s) { JVal v = new JVal(); v.Kind = JKind.String; v.Str = (s == null ? "" : s); return v; }
        public static JVal NewArr() { JVal v = new JVal(); v.Kind = JKind.Array; v.Arr = new List<JVal>(); return v; }
        public static JVal NewObj() { JVal v = new JVal(); v.Kind = JKind.Object; v.Obj = new List<KeyValuePair<string, JVal>>(); return v; }

        public JVal Get(string key)
        {
            if (Kind != JKind.Object || Obj == null) return null;
            for (int i = 0; i < Obj.Count; i++)
                if (Obj[i].Key == key) return Obj[i].Value;
            return null;
        }

        public string GetStr(string key, string def)
        {
            JVal v = Get(key);
            if (v == null || v.Kind != JKind.String) return def;
            return v.Str;
        }

        public double GetNum(string key, double def)
        {
            JVal v = Get(key);
            if (v == null || v.Kind != JKind.Number) return def;
            return v.Number;
        }

        public bool GetBool(string key, bool def)
        {
            JVal v = Get(key);
            if (v == null) return def;
            if (v.Kind == JKind.Bool) return v.Bool;
            if (v.Kind == JKind.Number) return v.Number != 0;
            return def;
        }

        public void Set(string key, JVal val)
        {
            if (Kind != JKind.Object) { Kind = JKind.Object; Obj = new List<KeyValuePair<string, JVal>>(); }
            for (int i = 0; i < Obj.Count; i++)
            {
                if (Obj[i].Key == key) { Obj[i] = new KeyValuePair<string, JVal>(key, val); return; }
            }
            Obj.Add(new KeyValuePair<string, JVal>(key, val));
        }

        public void Set(string key, string s) { Set(key, NewStr(s)); }
        public void Set(string key, double n) { Set(key, NewNum(n)); }
        public void Set(string key, bool b) { Set(key, NewBool(b)); }

        // 仅当 key 不存在时写入（用于升级时保留旧字段）
        public void SetIfMissing(string key, JVal val) { if (Get(key) == null) Set(key, val); }
    }

    public static class Json
    {
        public static JVal Parse(string text)
        {
            if (string.IsNullOrEmpty(text)) return JVal.NewNull();
            int pos = 0;
            JVal v = ParseValue(text, ref pos);
            if (v == null) return JVal.NewNull();
            return v;
        }

        static void SkipWs(string s, ref int i)
        {
            while (i < s.Length && (s[i] == ' ' || s[i] == '\t' || s[i] == '\r' || s[i] == '\n')) i++;
        }

        static JVal ParseValue(string s, ref int i)
        {
            SkipWs(s, ref i);
            if (i >= s.Length) return null;
            char c = s[i];
            if (c == '{') return ParseObj(s, ref i);
            if (c == '[') return ParseArr(s, ref i);
            if (c == '"') return JVal.NewStr(ParseStr(s, ref i));
            if (c == 't') { i += 4; return JVal.NewBool(true); }
            if (c == 'f') { i += 5; return JVal.NewBool(false); }
            if (c == 'n') { i += 4; return JVal.NewNull(); }
            return ParseNum(s, ref i);
        }

        static JVal ParseObj(string s, ref int i)
        {
            JVal o = JVal.NewObj();
            i++;
            SkipWs(s, ref i);
            if (i < s.Length && s[i] == '}') { i++; return o; }
            while (i < s.Length)
            {
                SkipWs(s, ref i);
                if (i < s.Length && s[i] == '"')
                {
                    string key = ParseStr(s, ref i);
                    SkipWs(s, ref i);
                    if (i < s.Length && s[i] == ':') i++;
                    JVal v = ParseValue(s, ref i);
                    o.Obj.Add(new KeyValuePair<string, JVal>(key, (v == null ? JVal.NewNull() : v)));
                }
                SkipWs(s, ref i);
                if (i < s.Length && s[i] == ',') { i++; continue; }
                if (i < s.Length && s[i] == '}') { i++; break; }
                i++;
            }
            return o;
        }

        static JVal ParseArr(string s, ref int i)
        {
            JVal a = JVal.NewArr();
            i++;
            SkipWs(s, ref i);
            if (i < s.Length && s[i] == ']') { i++; return a; }
            while (i < s.Length)
            {
                JVal v = ParseValue(s, ref i);
                a.Arr.Add((v == null ? JVal.NewNull() : v));
                SkipWs(s, ref i);
                if (i < s.Length && s[i] == ',') { i++; continue; }
                if (i < s.Length && s[i] == ']') { i++; break; }
                i++;
            }
            return a;
        }

        static string ParseStr(string s, ref int i)
        {
            i++;
            StringBuilder sb = new StringBuilder();
            while (i < s.Length)
            {
                char c = s[i];
                if (c == '"') { i++; break; }
                if (c == '\\')
                {
                    i++;
                    if (i >= s.Length) break;
                    char e = s[i];
                    switch (e)
                    {
                        case '"': sb.Append('"'); break;
                        case '\\': sb.Append('\\'); break;
                        case '/': sb.Append('/'); break;
                        case 'b': sb.Append('\b'); break;
                        case 'f': sb.Append('\f'); break;
                        case 'n': sb.Append('\n'); break;
                        case 'r': sb.Append('\r'); break;
                        case 't': sb.Append('\t'); break;
                        case 'u':
                            if (i + 4 < s.Length)
                            {
                                string hex = s.Substring(i + 1, 4);
                                int cp;
                                if (int.TryParse(hex, NumberStyles.HexNumber, CultureInfo.InvariantCulture, out cp))
                                {
                                    sb.Append((char)cp);
                                    i += 4;
                                }
                            }
                            break;
                        default: sb.Append(e); break;
                    }
                    i++;
                }
                else { sb.Append(c); i++; }
            }
            return sb.ToString();
        }

        static JVal ParseNum(string s, ref int i)
        {
            int start = i;
            while (i < s.Length && (char.IsDigit(s[i]) || s[i] == '-' || s[i] == '+' || s[i] == '.' || s[i] == 'e' || s[i] == 'E')) i++;
            string t = s.Substring(start, i - start);
            double d;
            if (double.TryParse(t, NumberStyles.Float, CultureInfo.InvariantCulture, out d)) return JVal.NewNum(d);
            return JVal.NewNum(0);
        }

        public static string Stringify(JVal v)
        {
            StringBuilder sb = new StringBuilder();
            Write(sb, v);
            return sb.ToString();
        }

        static void Write(StringBuilder sb, JVal v)
        {
            if (v == null) { sb.Append("null"); return; }
            switch (v.Kind)
            {
                case JKind.Null: sb.Append("null"); break;
                case JKind.Bool: sb.Append(v.Bool ? "true" : "false"); break;
                case JKind.Number:
                    if (double.IsNaN(v.Number) || double.IsInfinity(v.Number)) sb.Append("0");
                    else if (v.Number == Math.Floor(v.Number) && Math.Abs(v.Number) < 9e15)
                        sb.Append(((long)v.Number).ToString(CultureInfo.InvariantCulture));
                    else sb.Append(v.Number.ToString("R", CultureInfo.InvariantCulture));
                    break;
                case JKind.String: WriteStr(sb, v.Str); break;
                case JKind.Array:
                    sb.Append('[');
                    for (int i = 0; i < v.Arr.Count; i++)
                    {
                        if (i > 0) sb.Append(',');
                        Write(sb, v.Arr[i]);
                    }
                    sb.Append(']');
                    break;
                case JKind.Object:
                    sb.Append('{');
                    for (int i = 0; i < v.Obj.Count; i++)
                    {
                        if (i > 0) sb.Append(',');
                        WriteStr(sb, v.Obj[i].Key);
                        sb.Append(':');
                        Write(sb, v.Obj[i].Value);
                    }
                    sb.Append('}');
                    break;
            }
        }

        static void WriteStr(StringBuilder sb, string s)
        {
            sb.Append('"');
            if (s != null)
            {
                for (int i = 0; i < s.Length; i++)
                {
                    char c = s[i];
                    switch (c)
                    {
                        case '"': sb.Append("\\\""); break;
                        case '\\': sb.Append("\\\\"); break;
                        case '\b': sb.Append("\\b"); break;
                        case '\f': sb.Append("\\f"); break;
                        case '\n': sb.Append("\\n"); break;
                        case '\r': sb.Append("\\r"); break;
                        case '\t': sb.Append("\\t"); break;
                        default:
                            if (c < 0x20) sb.Append("\\u").Append(((int)c).ToString("x4", CultureInfo.InvariantCulture));
                            else sb.Append(c);
                            break;
                    }
                }
            }
            sb.Append('"');
        }
    }
}
