using System;

namespace DesktopCalendarTodo
{
    // 公历 -> 农历（1900-2100）。数据表为经典 lunarInfo 表（已与公开权威实现核对）。
    public struct LunarDate
    {
        public int Year;      // 农历年
        public int Month;     // 农历月 1-12
        public bool IsLeap;   // 是否闰月
        public int Day;       // 农历日 1-30
        public string GanZhiYear; // 年干支，如 丙午
        public string ShengXiao;  // 生肖，如 马
        public string MonthName;  // 如 九月 / 闰二月
        public string DayName;    // 如 初十

        public string Full
        {
            get { return GanZhiYear + "年 · " + MonthName + DayName; }
        }

        public string Header
        {
            get { return MonthName + DayName + " · " + GanZhiYear + ShengXiao + "年"; }
        }
    }

    public static class Lunar
    {
        // 1900-2100 农历年数据（来自公开经典实现，与闰月表核对一致）
        static readonly int[] Info = new int[]
        {
            0x04bd8,0x04ae0,0x0a570,0x054d5,0x0d260,0x0d950,0x16554,0x056a0,0x09ad0,0x055d2,//1900-1909
            0x04ae0,0x0a5b6,0x0a4d0,0x0d250,0x1d255,0x0b540,0x0d6a0,0x0ada2,0x095b0,0x14977,//1910-1919
            0x04970,0x0a4b0,0x0b4b5,0x06a50,0x06d40,0x1ab54,0x02b60,0x09570,0x052f2,0x04970,//1920-1929
            0x06566,0x0d4a0,0x0ea50,0x06e95,0x05ad0,0x02b60,0x186e3,0x092e0,0x1c8d7,0x0c950,//1930-1939
            0x0d4a0,0x1d8a6,0x0b550,0x056a0,0x1a5b4,0x025d0,0x092d0,0x0d2b2,0x0a950,0x0b557,//1940-1949
            0x06ca0,0x0b550,0x15355,0x04da0,0x0a5b0,0x14573,0x052b0,0x0a9a8,0x0e950,0x06aa0,//1950-1959
            0x0aea6,0x0ab50,0x04b60,0x0aae4,0x0a570,0x05260,0x0f263,0x0d950,0x05b57,0x056a0,//1960-1969
            0x096d0,0x04dd5,0x04ad0,0x0a4d0,0x0d4d4,0x0d250,0x0d558,0x0b540,0x0b6a0,0x195a6,//1970-1979
            0x095b0,0x049b0,0x0a974,0x0a4b0,0x0b27a,0x06a50,0x06d40,0x0af46,0x0ab60,0x09570,//1980-1989
            0x04af5,0x04970,0x064b0,0x074a3,0x0ea50,0x06b58,0x055c0,0x0ab60,0x096d5,0x092e0,//1990-1999
            0x0c960,0x0d954,0x0d4a0,0x0da50,0x07552,0x056a0,0x0abb7,0x025d0,0x092d0,0x0cab5,//2000-2009
            0x0a950,0x0b4a0,0x0baa4,0x0ad50,0x055d9,0x04ba0,0x0a5b0,0x15176,0x052b0,0x0a930,//2010-2019
            0x07954,0x06aa0,0x0ad50,0x05b52,0x04b60,0x0a6e6,0x0a4e0,0x0d260,0x0ea65,0x0d530,//2020-2029
            0x05aa0,0x076a3,0x096d0,0x04bd7,0x04ad0,0x0a4d0,0x1d0b6,0x0d250,0x0d520,0x0dd45,//2030-2039
            0x0b5a0,0x056d0,0x055b2,0x049b0,0x0a577,0x0a4b0,0x0aa50,0x1b255,0x06d20,0x0ada0,//2040-2049
            0x14b63,0x09370,0x049f8,0x04970,0x064b0,0x168a6,0x0ea50,0x06b20,0x1a6c4,0x0aae0,//2050-2059
            0x0a2e0,0x0d2e3,0x0c960,0x0d557,0x0d4a0,0x0da50,0x05d55,0x056a0,0x0a6d0,0x055d4,//2060-2069
            0x052d0,0x0a9b8,0x0a950,0x0b4a0,0x0b6a6,0x0ad50,0x055a0,0x0aba4,0x0a5b0,0x052b0,//2070-2079
            0x0b273,0x06930,0x07337,0x06aa0,0x0ad50,0x14b55,0x04b60,0x0a570,0x054e4,0x0d160,//2080-2089
            0x0e968,0x0d520,0x0daa0,0x16aa6,0x056d0,0x04ae0,0x0a9d4,0x0a2d0,0x0d150,0x0f252,//2090-2099
            0x0d520                                                                             //2100
        };

        static readonly string[] Gan = { "甲", "乙", "丙", "丁", "戊", "己", "庚", "辛", "壬", "癸" };
        static readonly string[] Zhi = { "子", "丑", "寅", "卯", "辰", "巳", "午", "未", "申", "酉", "戌", "亥" };
        static readonly string[] Xiao = { "鼠", "牛", "虎", "兔", "龙", "蛇", "马", "羊", "猴", "鸡", "狗", "猪" };
        static readonly string[] MonthCn = { "正", "二", "三", "四", "五", "六", "七", "八", "九", "十", "冬", "腊" };
        static readonly string[] DayCn = {
            "初一","初二","初三","初四","初五","初六","初七","初八","初九","初十",
            "十一","十二","十三","十四","十五","十六","十七","十八","十九","二十",
            "廿一","廿二","廿三","廿四","廿五","廿六","廿七","廿八","廿九","三十"
        };

        static int LeapMonth(int y) { return Info[y - 1900] & 0xf; }
        static int LeapDays(int y) { if (LeapMonth(y) == 0) return 0; return (Info[y - 1900] & 0x10000) != 0 ? 30 : 29; }
        static int MonthDays(int y, int m)
        {
            return (Info[y - 1900] & (0x10000 >> m)) != 0 ? 30 : 29;
        }
        static int YearDays(int y)
        {
            int sum = 348;
            for (int i = 0x8000; i > 0x8; i >>= 1)
                if ((Info[y - 1900] & 0xfff0 & i) != 0) sum++;
            return sum + LeapDays(y);
        }

        // 农历某年正月初一对应的公历日期
        public static DateTime SolarNewYear(int lunarYear)
        {
            DateTime baseDate = new DateTime(1900, 1, 31); // 农历1900年正月初一
            int days = 0;
            for (int y = 1900; y < lunarYear; y++)
                days += YearDays(y);
            return baseDate.AddDays(days);
        }

        // 农历（年/月/日，是否闰月）-> 公历日期；若该农历月不存在（如该年无某闰月）返回 null
        public static DateTime? LunarToSolar(int lunarYear, int month, int day, bool isLeap)
        {
            if (lunarYear < 1900 || lunarYear > 2100) return null;
            if (month < 1 || month > 12 || day < 1 || day > 30) return null;
            int leap = LeapMonth(lunarYear);
            if (isLeap && leap != month) return null; // 该年没有这个闰月
            if (isLeap && day > LeapDays(lunarYear)) return null;
            if (!isLeap && day > MonthDays(lunarYear, month)) return null;

            DateTime newYear = SolarNewYear(lunarYear);
            int offset = 0;
            for (int m = 1; m < month; m++)
                offset += MonthDays(lunarYear, m);
            if (leap > 0 && month > leap)
                offset += LeapDays(lunarYear);
            if (isLeap)
                offset += MonthDays(lunarYear, month); // 闰月排在同名月之后
            offset += day - 1;
            return newYear.AddDays(offset);
        }

        public static LunarDate FromSolar(DateTime solar)
        {
            DateTime baseDate = new DateTime(1900, 1, 31); // 农历1900年正月初一
            int offset = (int)(solar.Date - baseDate).TotalDays;

            // 年份：先减到 offset<=0，再用循环变量回退修正（经典算法语义）
            int i = 1900;
            int temp = 0;
            for (i = 1900; i < 2101 && offset > 0; i++)
            {
                temp = YearDays(i);
                offset -= temp;
            }
            if (offset < 0) { offset += temp; i--; }
            int lunarYear = i;

            int leap = LeapMonth(lunarYear);
            bool isLeap = false;
            temp = 0;
            for (i = 1; i < 13 && offset > 0; i++)
            {
                if (leap > 0 && i == leap + 1 && !isLeap)
                {
                    --i;
                    isLeap = true;
                    temp = LeapDays(lunarYear);
                }
                else
                {
                    temp = MonthDays(lunarYear, i);
                }
                if (isLeap && i == leap + 1) isLeap = false;
                offset -= temp;
            }
            if (offset == 0 && leap > 0 && i == leap + 1)
            {
                if (isLeap) isLeap = false;
                else { isLeap = true; --i; }
            }
            if (offset < 0) { offset += temp; --i; }
            int lunarMonth = i;
            int lunarDay = offset + 1;

            LunarDate r = new LunarDate();
            r.Year = lunarYear;
            r.Month = lunarMonth;
            r.IsLeap = isLeap;
            r.Day = lunarDay;

            int gan = (lunarYear - 4) % 10;
            int zhi = (lunarYear - 4) % 12;
            if (gan < 0) gan += 10;
            if (zhi < 0) zhi += 12;
            r.GanZhiYear = Gan[gan] + Zhi[zhi];
            r.ShengXiao = Xiao[zhi];
            r.MonthName = (isLeap ? "闰" : "") + MonthCn[lunarMonth - 1] + "月";
            r.DayName = DayCn[lunarDay - 1];
            return r;
        }
    }
}
