using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Documents;
using System.Windows.Threading;

namespace DesktopCalendarTodo
{
    public partial class MainWindow : Window
    {
        public const int ResizeZone = 6;
        public const int MinWinW = 880;
        public const int MinWinH = 580;

        // ---- Win32 ----
        [DllImport("user32.dll")]
        static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
        [DllImport("user32.dll")]
        static extern bool GetCursorPos(out POINT lpPoint);
        [DllImport("user32.dll")]
        static extern IntPtr SetCapture(IntPtr hWnd);
        [DllImport("user32.dll")]
        static extern bool ReleaseCapture();
        [DllImport("user32.dll")]
        static extern bool MoveWindow(IntPtr hWnd, int x, int y, int w, int h, bool repaint);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        static extern IntPtr LoadCursor(IntPtr hInstance, int cursor);
        [DllImport("user32.dll")]
        static extern IntPtr SetCursor(IntPtr hCursor);
        [StructLayout(LayoutKind.Sequential)]
        public struct RECT { public int Left, Top, Right, Bottom; }
        [StructLayout(LayoutKind.Sequential)]
        public struct POINT { public int X, Y; }
        const int WM_NCHITTEST = 0x84;
        const int WM_EXITSIZEMOVE = 0x0232;
        const int WM_NCLBUTTONDOWN = 0xA1;
        const int WM_NCMOUSEMOVE = 0x00A0;
        const int WM_MOUSEMOVE = 0x0200;
        const int WM_NCLBUTTONUP = 0x00A2;
        const int WM_LBUTTONUP = 0x0202;
        const int WM_SETCURSOR = 0x0020;
        const int HTLEFT = 10, HTRIGHT = 11, HTTOP = 12, HTTOPLEFT = 13, HTTOPRIGHT = 14,
                  HTBOTTOM = 15, HTBOTTOMLEFT = 16, HTBOTTOMRIGHT = 17, HTCAPTION = 2;
        const int IDC_SIZENWSE = 32642, IDC_SIZENESW = 32643, IDC_SIZEWE = 32644, IDC_SIZENS = 32645;

        // ---- 状态 ----
        PlannerData _data;
        string _dataDir;
        DateTime _selected;
        DateTime _viewMonth;
        bool _compact;
        bool _docked;
        bool _dockedLeft;
        bool _dragging;      // 正在拖动标题栏（拖动期间不触发贴边，避免拖动中变成细条后卡住）
        bool _dockArmed;     // 贴边后需要先移开一段距离，再把鼠标移到边缘才展开（避免刚贴边就弹回）
        Rect _fullBounds;    // 贴边前完整位置
        Rect _normalBounds;  // 紧凑前完整位置
        double _preCompactMinW;  // 紧凑前的窗口最小宽度（恢复时按视图还原，避免日视图被 880 顶回）
        double _preCompactMinH;  // 紧凑前的窗口最小高度
        bool _closingByExit;
        // 自定义缩放跟踪（无边框窗口系统不自动进入缩放循环，自实现四边/四角拖拽）
        bool _resizing;
        int _resizeEdge;
        RECT _resizeStart;
        POINT _resizeOrigin;

        DispatcherTimer _edgeTimer;
        DispatcherTimer _saveTimer;
        DispatcherTimer _posTimer;
        DispatcherTimer _statusTimer;
        DispatcherTimer _monthlyTimer;
        HwndSource _hwnd;

        // ---- 控件 ----
        Border _rootBorder;
        Grid _viewRoot;      // 外层根（日视图左侧待办标签 + 主体）
        Border _todoTab = null; // 已删除：日视图左侧待办标签（统合至分类下拉）
        Border _catPickerBtn;   // 日视图事项分类下拉按钮（强调色半透明圆角扁长方形）
        TextBlock _catPickerLabel; // 下拉按钮当前分类文本
        double _preDayWidth = -1;  // 切离日视图前的窗口宽度（进入日视图时恢复用）
        double _preDayHeight = -1; // 切离日视图前的窗口高度
        double _monthCalW = 342;   // 月视图日历栏最近一次实际宽度（进入日视图的默认宽度基准）
        bool _daySized;            // 本次日视图是否已套用“月历栏尺寸”
        readonly List<Button> _toolBtns = new List<Button>(); // 工具栏按钮（日视图窄窗口下收窄内边距）
        bool _pinHoverWired;       // 置顶按钮悬停委托只挂一次（避免重复订阅累积）
        Grid _main;
        Grid _body;
        Button _pinBtn;
        Button _btnToday;
        Button _btnCalIcon;      // 日视图日历入口（替代“今天”）
        Button _btnPrev;         // 上一周期
        Button _btnNext;         // 下一周期
        Button _btnTodoFloat;    // 周视图待办浮窗入口
        TextBlock _appTitle;
        TextBlock _monthLabel;
        TextBlock _statusLine;
        TextBlock _todoHeader;
        TextBlock _todoCount;
        TextBlock _todoHint;
        TextBox _schedText;
        TextBox _schedTime;
        TextBox _todoText;
        StackPanel _schedStack;
        StackPanel _todoStack;
        Grid _calendarGrid;
        Grid _weekGrid;          // 周视图一周日历（已并入日程格，字段保留兼容）
        Border _compactLabel;
        Border _dockBar;
        Border _dashLine1;
        Border _dashLine2;
        Window _todoFloatWin;    // 周视图待办浮窗
        Border _todoFloatBorder; // 浮窗底板（跟随设置背景色/透明度）
        HashSet<string> _expandedSubs = new HashSet<string>();
        int _loadedTick = -1;

        // 视图状态
        DateTime _viewWeek;                  // 周视图当前周（周一）
        string _catFilterVal = "全部";        // 日视图分类筛选
        bool _dayShowTodo;                   // 日视图：显示待办主体
        string _lastViewMode = "";

        public static MainWindow Instance;
        // 供弹窗统一取用当前外观设置（背景底色/透明度/强调色）
        public static AppSettings CurrentSettings { get { return Instance != null ? Instance._data.Settings : null; } }

        public static bool StartInNotes; // 测试用：--notes 启动即进入备忘录

        public MainWindow(string dataDir)
        {
            Instance = this;
            _dataDir = dataDir;
            _data = DataStore.Load(dataDir);
            Cats.SetCustomColors(_data.Settings.CategoryColors);
            if (StartInNotes) _notesMode = true;
            _monthCalW = _data.Settings.CalendarWidth;
            if (_monthCalW < 200) _monthCalW = 342;
            _selected = DateTime.Today;
            _viewMonth = new DateTime(_selected.Year, _selected.Month, 1);
            _viewWeek = _selected.AddDays(-(((int)_selected.DayOfWeek + 6) % 7));
            _lastViewMode = _data.Settings.ViewMode;
            BuildShell();
            BuildToolbar();
            BuildBody();
            BuildTray();
            BuildTimers();
            ApplySettings();
            Loaded += OnLoaded;
            Closing += OnClosing;
            LocationChanged += delegate
            {
                UpdateDockState();
                RestartPosSave();
                PositionTodoFloat();
                if (_daySized && _data != null && _data.Settings.ViewMode == "day")
                {
                    _data.Settings.DayLeft = Left;
                    _data.Settings.DayTop = Top;
                }
            };
            SizeChanged += delegate
            {
                PositionTodoFloat();
                FitMonthLayout();
                if (_daySized && _data != null && _data.Settings.ViewMode == "day")
                {
                    _data.Settings.DayWidth = Width;
                    _data.Settings.DayHeight = Height;
                }
            };
        }

        // ================= 窗口外壳 =================
        void BuildShell()
        {
            Title = "盏茶待办";
            WindowStyle = WindowStyle.None;
            AllowsTransparency = true;
            Background = Brushes.Transparent;
            ResizeMode = ResizeMode.CanResize;
            ShowInTaskbar = false;
            Topmost = _data.Settings.Topmost;
            MinWidth = MinWinW;
            MinHeight = MinWinH;
            UseLayoutRounding = true;
            FontFamily = Ui.Font;
            TextOptions.SetTextFormattingMode(this, TextFormattingMode.Display);

            _rootBorder = new Border();
            _rootBorder.CornerRadius = new CornerRadius(14);
            _rootBorder.Margin = new Thickness(18);
            _rootBorder.BorderBrush = new SolidColorBrush(Color.FromArgb(46, 255, 255, 255));
            _rootBorder.BorderThickness = new Thickness(1);
            _rootBorder.ClipToBounds = false;

            DropShadowEffect shadow = new DropShadowEffect();
            shadow.BlurRadius = 22;
            shadow.ShadowDepth = 0;
            shadow.Color = Colors.Black;
            shadow.Opacity = 0.5;
            _rootBorder.Effect = shadow;

            _main = new Grid();
            _main.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(46) });
            _main.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1, GridUnitType.Star) });
            _rootBorder.Child = _main;

            // 外层根：单一内容列（日视图左侧待办标签已删，统合至分类下拉）
            _viewRoot = new Grid();
            _viewRoot.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(0) });
            _viewRoot.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1, GridUnitType.Star) });
            Grid.SetColumn(_rootBorder, 1);
            _viewRoot.Children.Add(_rootBorder);
            Ui.ApplyThinScrollBars(_viewRoot, ColorUtil.Parse(_data.Settings.Accent, Color.FromArgb(255, 79, 140, 255)));
            Content = _viewRoot;

            KeyDown += OnWindowKeyDown;
            MouseEnter += OnWindowMouseEnter;
            // 贴边后鼠标离开窗口即“解除锁定”，再次移入边缘时展开（避免刚贴边就弹回）
            MouseLeave += delegate { if (_docked) _dockArmed = true; };
        }

        void BuildToolbar()
        {
            Grid bar = new Grid();
            bar.Background = Brushes.Transparent;
            bar.MouseLeftButtonDown += delegate { DragWindow(); };
            for (int i = 0; i < 10; i++)
                bar.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });

            _appTitle = Ui.Lbl("盏茶待办", 14, Colors.White, true);
            _appTitle.Margin = new Thickness(16, 0, 10, 0);
            _appTitle.VerticalAlignment = VerticalAlignment.Center;
            _appTitle.HorizontalAlignment = HorizontalAlignment.Left;
            Grid.SetColumn(_appTitle, 0);
            bar.Children.Add(_appTitle);

            Button prev = Ui.ToolButton("◀", "上一周期");
            AutomationProperties.SetName(prev, "BtnPrev");
            prev.Click += delegate { PrevPeriod(); };
            Grid.SetColumn(prev, 1);
            bar.Children.Add(prev);
            _btnPrev = prev;

            _monthLabel = Ui.Lbl("", 14, Colors.White, true);
            _monthLabel.Margin = new Thickness(4, 0, 4, 0);
            _monthLabel.VerticalAlignment = VerticalAlignment.Center;
            _monthLabel.HorizontalAlignment = HorizontalAlignment.Center;
            _monthLabel.MinWidth = 96;
            _monthLabel.TextAlignment = TextAlignment.Center;
            AutomationProperties.SetName(_monthLabel, "MonthLabel");
            Grid.SetColumn(_monthLabel, 2);
            bar.Children.Add(_monthLabel);

            Button next = Ui.ToolButton("▶", "下一周期");
            AutomationProperties.SetName(next, "BtnNext");
            next.Click += delegate { NextPeriod(); };
            Grid.SetColumn(next, 3);
            bar.Children.Add(next);
            _btnNext = next;

            _btnToday = Ui.ToolButton("今天", "回到今天并选中");
            AutomationProperties.SetName(_btnToday, "BtnToday");
            _btnToday.Click += delegate { GoToday(); };
            Grid.SetColumn(_btnToday, 4);
            bar.Children.Add(_btnToday);

            // 日视图：日历 icon（替代“今天”入口，点击弹月历选日期）
            _btnCalIcon = Ui.ToolButton("日历", "打开月历选择日期");
            AutomationProperties.SetName(_btnCalIcon, "BtnCalIcon");
            _btnCalIcon.Click += delegate { ShowMiniCalendar(); };
            Grid.SetColumn(_btnCalIcon, 4);
            bar.Children.Add(_btnCalIcon);
            _btnCalIcon.Visibility = Visibility.Collapsed;

            // 周视图：待办浮窗入口（普通态透明，悬停时强调色半透明，避免未悬停显示实色效果）
            _btnTodoFloat = Ui.ToolButton("待办", "打开独立待办窗口（吸附于本窗口右侧）");
            AutomationProperties.SetName(_btnTodoFloat, "BtnTodoFloat");
            _btnTodoFloat.Foreground = Brushes.White;
            _btnTodoFloat.MouseEnter += delegate { _btnTodoFloat.Background = new SolidColorBrush(Color.FromArgb(70, ColorUtil.Parse(_data.Settings.Accent, Colors.White).R, ColorUtil.Parse(_data.Settings.Accent, Colors.White).G, ColorUtil.Parse(_data.Settings.Accent, Colors.White).B)); };
            _btnTodoFloat.MouseLeave += delegate { _btnTodoFloat.Background = Brushes.Transparent; };
            _btnTodoFloat.Click += delegate { ToggleTodoFloat(); };
            Grid.SetColumn(_btnTodoFloat, 4);
            bar.Children.Add(_btnTodoFloat);
            _btnTodoFloat.Visibility = Visibility.Collapsed;

            _pinBtn = Ui.ToolButton("置顶", "始终置顶开关");
            AutomationProperties.SetName(_pinBtn, "BtnPin");
            _pinBtn.Click += delegate { _data.Settings.Topmost = !_data.Settings.Topmost; ApplyTopmost(); SaveSoon(); };
            Grid.SetColumn(_pinBtn, 5);
            bar.Children.Add(_pinBtn);

            Button settings = Ui.ToolButton("设置", "外观与行为设置");
            AutomationProperties.SetName(settings, "BtnSettings");
            settings.Click += delegate
            {
                Dialogs.ShowSettings(this, _data.Settings, ApplyAppearance,
                    delegate { RunMonthlyReportNow(DateTime.Now); });
                SaveSoon();
            };
            Grid.SetColumn(settings, 6);
            bar.Children.Add(settings);

            Button compact = Ui.ToolButton("—", "紧凑收起为“待办”标签");
            AutomationProperties.SetName(compact, "BtnCompact");
            compact.Click += delegate { EnterCompact(); };
            Grid.SetColumn(compact, 7);
            bar.Children.Add(compact);

            Button hide = Ui.ToolButton("✕", "隐藏到系统托盘（双击托盘图标恢复）");
            AutomationProperties.SetName(hide, "BtnHide");
            hide.Click += delegate { HideToTray(); };
            Grid.SetColumn(hide, 8);
            bar.Children.Add(hide);

            foreach (UIElement el in bar.Children)
            {
                Button b = el as Button;
                if (b != null)
                {
                    Ui.Hover(b, Color.FromArgb(26, 255, 255, 255));
                    _toolBtns.Add(b);
                }
            }

            Grid.SetRow(bar, 0);
            _main.Children.Add(bar);
        }

        void BuildBody()
        {
            _body = new Grid();
            _body.SizeChanged += delegate { RebuildCalendar(); FitMonthLayout(); };
            string mode = _data.Settings.ViewMode;
            if (mode == "week") BuildWeekView();
            else if (mode == "day") BuildDayView();
            else BuildMonthView();
            Grid.SetRow(_body, 1);
            _main.Children.Add(_body);
            UpdateViewToolbar();
        }

        // 月视图：月历 | 日程 | 待办（三栏，含可拖分隔线与强调色竖分隔线）
        void BuildMonthView()
        {
            // 三栏都用“星号比例”分配宽度：窗口无论怎么缩放都能精确铺满，待办栏永远贴右边缘
            double calW = Math.Max(320, _data.Settings.CalendarWidth);
            double schedW = Math.Max(280, _data.Settings.ScheduleWidth);
            double todoW = Math.Max(250, _data.Settings.TodoWidth);
            double total = calW + schedW + todoW;
            _body.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(calW / total, GridUnitType.Star), MinWidth = 300 });
            _body.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(6) });
            _body.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(schedW / total, GridUnitType.Star), MinWidth = 260 });
            _body.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(6) });
            _body.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(todoW / total, GridUnitType.Star), MinWidth = 250 });

            Border cal = BuildCalendarPanel();
            Grid.SetColumn(cal, 0);
            _body.Children.Add(cal);
            Border sched = BuildSchedulePanel();
            Grid.SetColumn(sched, 2);
            _body.Children.Add(sched);
            Border todo = BuildTodoPanel();
            Grid.SetColumn(todo, 4);
            _body.Children.Add(todo);

            Border sp1 = MakeSplitter(0, 2);
            Grid.SetColumn(sp1, 1);
            _body.Children.Add(sp1);
            Border inner1;
            Grid wrap1 = MakeDivider(out inner1);
            Grid.SetColumn(wrap1, 1);
            _body.Children.Add(wrap1);
            _dashLine1 = inner1;
            // 分隔线在下、分隔条在上：保证拖拽分隔线时命中 GridSplitter
            Panel.SetZIndex(wrap1, 0);
            Panel.SetZIndex(sp1, 1);
            Border sp2 = MakeSplitter(2, 4);
            Grid.SetColumn(sp2, 3);
            _body.Children.Add(sp2);
            Border inner2;
            Grid wrap2 = MakeDivider(out inner2);
            Grid.SetColumn(wrap2, 3);
            _body.Children.Add(wrap2);
            _dashLine2 = inner2;
            Panel.SetZIndex(wrap2, 0);
            Panel.SetZIndex(sp2, 1);
            FitMonthLayout();
        }

        // 周视图：日程并入日历格（每列=日期头+该日日程列表），底部单独一行“安排/添加日程/时间/+”，
        // 右侧为月视图日程栏的全部操作按钮（全局仅一份，不随 7 列重复），整行位于日期/日程格子之外
        void BuildWeekView()
        {
            _body.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1, GridUnitType.Star) });
            _body.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });

            Border cols = BuildWeekColumnsPanel();
            Grid.SetRow(cols, 0);
            _body.Children.Add(cols);

            Border bar = BuildWeekActionBar();
            Grid.SetRow(bar, 1);
            _body.Children.Add(bar);
        }

        // 日视图：以日程/待办/备忘录面板为主体；面板右上角的「事项分类」下拉统一切换（不再单独放顶部下拉）
        void BuildDayView()
        {
            _body.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1, GridUnitType.Star) });

            Border main;
            if (_notesMode) main = BuildNotesPanel(true);
            else main = _dayShowTodo ? BuildTodoPanel() : BuildSchedulePanel();
            Grid.SetRow(main, 0);
            _body.Children.Add(main);
        }

        // 日视图：事项分类下拉行（统合日程/待办/自定义分类；强调色半透明圆角扁长方形按钮）
        Border BuildCatPickerRow()
        {
            Border rowWrap = new Border();
            rowWrap.Margin = new Thickness(12, 8, 12, 0);
            StackPanel row = new StackPanel() { Orientation = Orientation.Horizontal };
            row.HorizontalAlignment = HorizontalAlignment.Right;

            _catPickerBtn = new Border();
            Color acc = ColorUtil.Parse(_data.Settings.Accent, Color.FromArgb(255, 79, 140, 255));
            _catPickerBtn.CornerRadius = new CornerRadius(8);
            _catPickerBtn.Background = new SolidColorBrush(Color.FromArgb(64, acc.R, acc.G, acc.B));
            _catPickerBtn.BorderBrush = new SolidColorBrush(Color.FromArgb(150, acc.R, acc.G, acc.B));
            _catPickerBtn.BorderThickness = new Thickness(1);
            _catPickerBtn.Padding = new Thickness(16, 5, 16, 5);
            _catPickerBtn.Cursor = Cursors.Hand;
            _catPickerBtn.ToolTip = "事项分类：日程/待办/自定义";
            _catPickerLabel = Ui.Lbl(_notesMode ? "备忘录" : _catFilterVal, 11.5, Colors.White, true);
            _catPickerLabel.VerticalAlignment = VerticalAlignment.Center;
            // Border 无 AutomationPeer，UIA 名设在内部 TextBlock 上
            AutomationProperties.SetName(_catPickerLabel, "CatPickerBtn");
            _catPickerBtn.Child = _catPickerLabel;
            _catPickerBtn.MouseLeftButtonUp += delegate { ShowCatPicker(); };
            row.Children.Add(_catPickerBtn);
            rowWrap.Child = row;
            return rowWrap;
        }

        void ShowCatPicker()
        {
            ShowCatPicker(null);
        }

        void ShowCatPicker(FrameworkElement anchor)
        {
            List<string> items = new List<string>();
            items.Add("全部");
            items.Add("待办");
            items.Add("备忘录");
            string[] defaults = new string[] { "日常", "重要", "紧急", "工作", "生活" };
            for (int i = 0; i < defaults.Length; i++)
                if (CategoryVisible(defaults[i])) items.Add(defaults[i]);
            for (int i = 0; i < _data.Settings.Categories.Count; i++)
                if (CategoryVisible(_data.Settings.Categories[i]) && !items.Contains(_data.Settings.Categories[i]))
                    items.Add(_data.Settings.Categories[i]);
            items.Add("自定义");

            int rowH = 38;
            int maxShow = 10;
            int shown = Math.Min(items.Count, maxShow);
            DialogHost d = new DialogHost(this, "事项分类", 240, shown * rowH + 96);
            if (anchor != null) d.PlaceNear(anchor);
            StackPanel sp = new StackPanel();
            for (int i = 0; i < items.Count; i++)
            {
                string it = items[i];
                Border rb = new Border();
                rb.Padding = new Thickness(12, 7, 12, 7);
                rb.Cursor = Cursors.Hand;
                rb.Margin = new Thickness(0, 1, 0, 1);
                bool cur = _notesMode ? (it == "备忘录") : (it == _catFilterVal);
                if (cur) rb.Background = new SolidColorBrush(Color.FromArgb(36, 79, 140, 255));
                StackPanel rowSp = new StackPanel() { Orientation = Orientation.Horizontal };
                Border dot = new Border();
                dot.Width = 10; dot.Height = 10; dot.CornerRadius = new CornerRadius(5);
                dot.Margin = new Thickness(0, 0, 8, 0);
                dot.VerticalAlignment = VerticalAlignment.Center;
                dot.Background = (it == "全部" || it == "待办" || it == "备忘录")
                    ? new SolidColorBrush(Color.FromArgb(90, 255, 255, 255))
                    : ColorUtil.Brush(Cats.ColorOf(it, ""));
                rowSp.Children.Add(dot);
                TextBlock t = Ui.Lbl(it, 12, cur ? Color.FromArgb(255, 120, 180, 255) : Color.FromArgb(230, 255, 255, 255));
                rowSp.Children.Add(t);
                rb.Child = rowSp;
                // 单击选择（延迟 240ms 判定，给双击留出时间）；双击 → 重命名
                BindCatRow(rb, it, d);
                sp.Children.Add(rb);
            }
            d.Body.Children.Add(sp);
            d.ShowDialog();
            // 双击某一行请求重命名：等弹窗真正关闭后再弹输入框，避免与模态循环冲突
            if (_pendingRename != null)
            {
                string pending = _pendingRename;
                _pendingRename = null;
                RenameCategory(pending);
            }
        }

        MouseButtonEventHandler MakeCatPick(string cat, DialogHost dlg)
        {
            return delegate(object sender, MouseButtonEventArgs e) { ApplyCatSelection(cat); dlg.Close(); };
        }

        // 分类行：单击=选择（延时 240ms，避免双击的第一下就把列表关掉）；双击=重命名
        void BindCatRow(Border rb, string cat, DialogHost dlg)
        {
            System.Windows.Threading.DispatcherTimer timer = null;
            rb.MouseLeftButtonUp += delegate(object sender, MouseButtonEventArgs e)
            {
                if (e.ClickCount > 1) return;
                if (timer != null) timer.Stop();
                timer = new System.Windows.Threading.DispatcherTimer();
                timer.Interval = TimeSpan.FromMilliseconds(240);
                timer.Tick += delegate(object s2, EventArgs e2)
                {
                    timer.Stop();
                    ApplyCatSelection(cat);
                    dlg.Close();
                };
                timer.Start();
            };
            rb.MouseLeftButtonDown += delegate(object sender, MouseButtonEventArgs e)
            {
                if (e.ClickCount != 2) return;
                if (timer != null) timer.Stop();
                e.Handled = true;
                _pendingRename = cat;
                dlg.Close();
            };
        }

        // 双击分类项 → 记下待重命名项并关闭列表（由 ShowCatPicker 返回后统一处理）
        MouseButtonEventHandler MakeCatRename(string cat, DialogHost dlg)
        {
            return delegate(object sender, MouseButtonEventArgs e)
            {
                if (e.ClickCount != 2) return;
                e.Handled = true;
                _pendingRename = cat;
                dlg.Close();
            };
        }

        string _pendingRename;

        // 分类操作：双击分类项 → 可改名 / 改颜色 / 删除（三者互相独立，只做其中一个也能生效）
        public void RenameCategory(string oldName)
        {
            if (oldName == "全部" || oldName == "待办" || oldName == "备忘录" || oldName == "自定义")
            {
                System.Windows.MessageBox.Show(this, "「" + oldName + "」是功能入口，不能重命名或删除。", "分类设置");
                return;
            }
            string nn = "";
            string newColor = "";
            int act = Dialogs.EditCategory(this, "分类设置：" + oldName, oldName, Cats.ColorOf(oldName, ""), out nn, out newColor, true);
            if (act == 0) return;
            if (act == 2) { DeleteCategory(oldName); return; }

            nn = (nn ?? "").Trim();
            if (nn.Length == 0) return;
            bool renamed = nn != oldName;

            if (renamed)
            {
                bool exists = false;
                for (int i = 0; i < Cats.Names.Length; i++) if (Cats.Names[i] == nn && nn != oldName) exists = true;
                if (_data.Settings.Categories.Contains(nn)) exists = true;
                if (exists)
                {
                    System.Windows.MessageBox.Show(this, "分类「" + nn + "」已存在，请换一个名字。", "分类设置");
                    return;
                }
                for (int i = 0; i < _data.Todos.Count; i++)
                    if (_data.Todos[i].Category == oldName) _data.Todos[i].Category = nn;
                foreach (System.Collections.Generic.List<ScheduleItem> list in _data.Schedules.Values)
                    for (int i = 0; i < list.Count; i++)
                        if (list[i].Category == oldName) list[i].Category = nn;

                if (_data.Settings.Categories.Contains(oldName)) _data.Settings.Categories.Remove(oldName);
                else if (IsBuiltinCategory(oldName) && !_data.Settings.DeletedCategories.Contains(oldName))
                    _data.Settings.DeletedCategories.Add(oldName); // 默认分类改名后隐藏原名
                if (!_data.Settings.Categories.Contains(nn)) _data.Settings.Categories.Add(nn);
                if (_data.Settings.CategoryColors.ContainsKey(oldName)) _data.Settings.CategoryColors.Remove(oldName);
                if (_catFilterVal == oldName) _catFilterVal = nn;
                if (_schedCatFilter == oldName) _schedCatFilter = nn;
            }

            // 颜色单独生效：名字不变也能改色
            string col = string.IsNullOrEmpty(newColor) ? Cats.ColorOf(oldName, "") : newColor;
            _data.Settings.CategoryColors[nn] = col;
            Cats.SetCustomColors(_data.Settings.CategoryColors);

            SaveSoon();
            RebuildBody();
            RefreshAll();
            Flash(renamed ? ("已重命名为「" + nn + "」") : "已更新分类颜色");
        }

        static bool IsBuiltinCategory(string name)
        {
            for (int i = 0; i < Cats.Names.Length; i++) if (Cats.Names[i] == name) return true;
            return false;
        }

        // 删除分类：该分类下的事项改为默认分类；默认分类删除后不再出现在列表里
        void DeleteCategory(string name)
        {
            string fallback = name == "日常" ? "重要" : "日常";
            if (!Dialogs.Confirm(this, "删除分类", "删除分类「" + name + "」？该分类下的事项会改为「" + fallback + "」。")) return;
            for (int i = 0; i < _data.Todos.Count; i++)
                if (_data.Todos[i].Category == name) _data.Todos[i].Category = fallback;
            foreach (System.Collections.Generic.List<ScheduleItem> list in _data.Schedules.Values)
                for (int i = 0; i < list.Count; i++)
                    if (list[i].Category == name) list[i].Category = fallback;

            _data.Settings.Categories.Remove(name);
            _data.Settings.CategoryColors.Remove(name);
            if (IsBuiltinCategory(name) && !_data.Settings.DeletedCategories.Contains(name))
                _data.Settings.DeletedCategories.Add(name);
            if (_catFilterVal == name) _catFilterVal = "全部";
            if (_schedCatFilter == name) _schedCatFilter = "全部";
            Cats.SetCustomColors(_data.Settings.CategoryColors);

            SaveSoon();
            RebuildBody();
            RefreshAll();
            Flash("已删除分类「" + name + "」");
        }

        // 分类是否出现在选择列表里（删除过的默认分类不再出现）
        public bool CategoryVisible(string name)
        {
            return !_data.Settings.DeletedCategories.Contains(name);
        }

        void ApplyCatSelection(string cat)
        {
            if (cat == "备忘录")
            {
                _notesMode = true;
                _catFilterVal = "备忘录";
                RebuildBody();
                RefreshAll();
                RefreshTodoFloatIfOpen();
                return;
            }
            _notesMode = false;
            if (cat == "自定义")
            {
                string name = "";
                if (Dialogs.EditText(this, "新建自定义分类", "", out name) && name.Length > 0)
                {
                    if (!_data.Settings.Categories.Contains(name)) _data.Settings.Categories.Add(name);
                    _catFilterVal = name;
                    _dayShowTodo = false;
                    SaveSoon();
                    RebuildBody();
                    RefreshAll();
                    RefreshTodoFloatIfOpen();
                }
                return;
            }
            _catFilterVal = cat;
            _dayShowTodo = (cat == "待办");
            // 日视图里选择分类后，日程栏也要跟着筛选（此前只改了待办栏的筛选值，看起来“没应用”）
            if (_data.Settings.ViewMode == "day" && !_dayShowTodo)
            {
                _schedCatFilter = (cat == "全部") ? "全部" : cat;
                if (_schedCatLabel != null) _schedCatLabel.Text = _schedCatFilter; // 按钮文字同步
            }
            RebuildBody();
            RefreshTodoFloatIfOpen();
        }

        // 周视图「待办」浮窗开着时，分类选择同样要同步刷新浮窗内容
        void RefreshTodoFloatIfOpen()
        {
            if (_todoFloatBorder == null) return;
            try { RefreshTodoFloat(); } catch { }
        }

        // 按当前视图刷新工具栏入口（今天/日历icon/待办浮窗 互斥显示，避免同列按钮重合）
        void UpdateViewToolbar()
        {
            string mode = _data.Settings.ViewMode;
            bool isWeek = (mode == "week");
            bool isDay = (mode == "day");
            if (_btnToday != null) _btnToday.Visibility = (isWeek || isDay) ? Visibility.Collapsed : Visibility.Visible;
            if (_btnCalIcon != null) _btnCalIcon.Visibility = isDay ? Visibility.Visible : Visibility.Collapsed;
            if (_btnTodoFloat != null) _btnTodoFloat.Visibility = isWeek ? Visibility.Visible : Visibility.Collapsed;
            // 日视图窗口只有月历栏那么宽：隐藏年月与左右切换，统一显示标题“盏茶待办”
            if (_appTitle != null) _appTitle.Visibility = Visibility.Visible;
            if (_monthLabel != null) _monthLabel.Visibility = isDay ? Visibility.Collapsed : Visibility.Visible;
            if (_btnPrev != null) _btnPrev.Visibility = isDay ? Visibility.Collapsed : Visibility.Visible;
            if (_btnNext != null) _btnNext.Visibility = isDay ? Visibility.Collapsed : Visibility.Visible;
            if (_monthLabel != null)
            {
                _monthLabel.FontSize = isDay ? 12 : 14;
                _monthLabel.MinWidth = isDay ? 74 : 96;
            }
            for (int i = 0; i < _toolBtns.Count; i++)
            {
                Button b = _toolBtns[i];
                b.Padding = isDay ? new Thickness(5, 4, 5, 4) : new Thickness(10, 4, 10, 4);
                b.MinWidth = isDay ? 26 : 34;
            }
            // 左侧待办标签已删除：外层根列0 恒为 0 宽
            if (_viewRoot != null) _viewRoot.ColumnDefinitions[0].Width = new GridLength(0);
        }

        void PrevPeriod()
        {
            if (_data.Settings.ViewMode == "week")
            {
                _viewWeek = _viewWeek.AddDays(-7);
                _selected = _viewWeek;
                _viewMonth = new DateTime(_viewWeek.Year, _viewWeek.Month, 1);
            }
            else if (_data.Settings.ViewMode == "day")
            {
                _selected = _selected.AddDays(-1);
            }
            else
            {
                _viewMonth = _viewMonth.AddMonths(-1);
            }
            RefreshAll();
        }

        void NextPeriod()
        {
            if (_data.Settings.ViewMode == "week")
            {
                _viewWeek = _viewWeek.AddDays(7);
                _selected = _viewWeek;
                _viewMonth = new DateTime(_viewWeek.Year, _viewWeek.Month, 1);
            }
            else if (_data.Settings.ViewMode == "day")
            {
                _selected = _selected.AddDays(1);
            }
            else
            {
                _viewMonth = _viewMonth.AddMonths(1);
            }
            RefreshAll();
        }

        void GoToday()
        {
            _selected = DateTime.Today;
            _viewMonth = new DateTime(_selected.Year, _selected.Month, 1);
            DateTime startOfWeek = _selected.AddDays(-(((int)_selected.DayOfWeek + 6) % 7));
            _viewWeek = startOfWeek;
            RefreshAll();
        }

        // 视图模式变化时整体重建主体布局（设置面板中“窗口样式”切换）
        void RebuildBody()
        {
            CaptureDrafts(); // 切换视图前保存已输入的文字，避免丢失
            bool hadFloat = _todoFloatWin != null; // 分类筛选等重建后要恢复浮窗，不能自动收起
            _main.Children.Remove(_body);
            _body = null;
            if (_todoFloatWin != null) { _todoFloatWin.Close(); _todoFloatWin = null; }
            BuildBody();
            ApplyDrafts();   // 新视图的对应输入框恢复同样的文字
            RefreshAll();
            if (hadFloat && _data.Settings.ViewMode == "week" && !_compact) ToggleTodoFloat();
            SaveSoon();
        }

        // 草稿：各视图共享“日程内容 / 时间 / 待办内容”三份文字，切换视图时互相迁移
        string _draftSchedText = "";
        string _draftSchedTime = "";
        string _draftTodoText = "";

        void CaptureDrafts()
        {
            if (_schedText != null) _draftSchedText = _schedText.Text;
            if (_schedTime != null) _draftSchedTime = _schedTime.Text;
            if (_weekText != null) _draftSchedText = _weekText.Text;
            if (_weekTime != null) _draftSchedTime = _weekTime.Text;
            if (_todoText != null) _draftTodoText = _todoText.Text;
        }

        void ApplyDrafts()
        {
            if (_schedText != null && _schedText.Text != _draftSchedText) _schedText.Text = _draftSchedText;
            if (_schedTime != null && _schedTime.Text != _draftSchedTime) _schedTime.Text = _draftSchedTime;
            if (_weekText != null && _weekText.Text != _draftSchedText) _weekText.Text = _draftSchedText;
            if (_weekTime != null && _weekTime.Text != _draftSchedTime) _weekTime.Text = _draftSchedTime;
            if (_todoText != null && _todoText.Text != _draftTodoText) _todoText.Text = _draftTodoText;
        }

        // 周视图：待办独立浮窗（吸附于本窗口右侧）
        void ToggleTodoFloat()
        {
            if (_todoFloatWin != null)
            {
                _todoFloatWin.Close();
                _todoFloatWin = null;
                return;
            }
            Window w = new Window();
            w.WindowStyle = WindowStyle.None;
            w.AllowsTransparency = true;
            w.Background = Brushes.Transparent;
            w.ResizeMode = ResizeMode.NoResize;
            w.ShowInTaskbar = false;
            w.Owner = this;
            w.Width = 350;
            Border bd = new Border();
            bd.CornerRadius = new CornerRadius(12);
            bd.Background = Ui.ThemedBackground();
            bd.BorderBrush = new SolidColorBrush(Color.FromArgb(60, 255, 255, 255));
            bd.BorderThickness = new Thickness(1);
            bd.Margin = new Thickness(6);
            _buildingTodoFloat = true;
            bd.Child = BuildTodoPanel();
            _buildingTodoFloat = false;
            RebuildTodo(); // 立即填充浮窗列表，无需等待自动保存周期

            // 右侧 6px 拖拽条：调整浮窗宽度（左边缘保持吸附主窗口）
            Grid fg = new Grid();
            fg.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1, GridUnitType.Star) });
            fg.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(6) });
            Grid.SetColumn(bd, 0);
            fg.Children.Add(bd);
            Border grip = new Border();
            grip.Background = Brushes.Transparent;
            grip.Cursor = Cursors.SizeWE;
            grip.ToolTip = "拖动调整待办浮窗宽度";
            AutomationProperties.SetName(grip, "TodoFloatGrip");
            double startW = 0, startX = 0;
            bool dragging = false;
            grip.MouseLeftButtonDown += delegate(object s, MouseButtonEventArgs e)
            {
                dragging = true;
                startW = w.Width;
                startX = e.GetPosition(this).X;
                grip.CaptureMouse();
                e.Handled = true;
            };
            grip.MouseMove += delegate(object s, MouseEventArgs e)
            {
                if (!dragging) return;
                double nw = startW + (e.GetPosition(this).X - startX);
                if (nw < 260) nw = 260;
                if (nw > 720) nw = 720;
                w.Width = nw;
            };
            grip.MouseLeftButtonUp += delegate
            {
                dragging = false;
                grip.ReleaseMouseCapture();
                PositionTodoFloat();
            };
            Grid.SetColumn(grip, 1);
            fg.Children.Add(grip);
            w.Content = fg;
            _todoFloatBorder = bd;
            _todoFloatWin = w;
            PositionTodoFloat(); // 紧贴主窗口右侧、顶边与主窗口可见区域对齐
            // 只有点在空白/非交互区域才拖动浮窗，避免吞掉按钮与分类下拉的点击
            w.MouseLeftButtonDown += delegate(object s, MouseButtonEventArgs e)
            {
                if (IsFloatInteractive(e.OriginalSource as DependencyObject)) return;
                try { w.DragMove(); } catch { }
            };
            w.Closed += delegate { _todoFloatWin = null; _todoFloatBorder = null; };
            w.Show();
        }

        // 浮窗内可交互元素（按钮/输入框/滚动条/带 nodrag 标记的面板）不触发整窗拖动
        static bool IsFloatInteractive(DependencyObject src)
        {
            DependencyObject d = src;
            int guard = 0;
            while (d != null && guard++ < 40)
            {
                if (d is ButtonBase || d is TextBox || d is ScrollBar || d is Thumb) return true;
                FrameworkElement fe = d as FrameworkElement;
                if (fe != null && (fe.Tag as string) == "nodrag") return true;
                d = System.Windows.Media.VisualTreeHelper.GetParent(d);
            }
            return false;
        }

        // 让周视图“待办”浮窗紧贴主窗口：主窗口四周有 18 DIP 透明外框、浮窗有 6 DIP 外框，
        // 因此左/上各减去外框差并留 2px 视觉缝隙，高度按可见区域高度对齐。
        void PositionTodoFloat()
        {
            if (_todoFloatWin == null || _compact) return;
            double baseLeft = _docked ? _fullBounds.X : Left;
            double baseTop = _docked ? _fullBounds.Y : Top;
            double baseW = _docked ? _fullBounds.Width : Width;
            double baseH = _docked ? _fullBounds.Height : Height;
            if (double.IsNaN(baseLeft) || double.IsNaN(baseW) || baseW <= 0) return;
            _todoFloatWin.Left = baseLeft + baseW - 22;
            _todoFloatWin.Top = baseTop + 12;
            _todoFloatWin.Height = Math.Max(260, baseH - 24);
        }

        // 日视图：日历 icon 弹出月历选择窗 —— 尺寸恰好容纳全部内容（固定 32px 行高 + 自动高度，无滚动条）
        void ShowMiniCalendar()
        {
            ShowMiniCalendar(null);
        }

        // onPick：点击日期后的回调（周视图“安排”、待办“安排”共用）；null 时按普通“选中日期”处理
        void ShowMiniCalendar(Action<DateTime> onPick)
        {
            // 6 行日期格固定 32px 行高 + 确定按钮行；DialogHost 自动高度模式按内容精确定高，不出现滚动条
            DialogHost d = new DialogHost(this, "选择日期", 316, 32 * 6 + 76, true);
            Grid mg = new Grid();
            for (int i = 0; i < 7; i++) mg.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1, GridUnitType.Star) });
            for (int i = 0; i < 6; i++) mg.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(32) });
            DateTime mFirst = new DateTime(_selected.Year, _selected.Month, 1);
            int lead = ((int)mFirst.DayOfWeek + 6) % 7;
            DateTime mStart = mFirst.AddDays(-lead);
            for (int i = 0; i < 42; i++)
            {
                DateTime day = mStart.AddDays(i);
                Border cell = new Border();
                cell.Margin = new Thickness(1);
                cell.CornerRadius = new CornerRadius(6);
                cell.Cursor = Cursors.Hand;
                cell.Background = Brushes.Transparent;
                bool inM = (day.Month == _selected.Month);
                TextBlock t = Ui.Lbl(day.Day.ToString(), 11.5,
                    inM ? Color.FromArgb(235, 255, 255, 255) : Color.FromArgb(100, 255, 255, 255));
                t.HorizontalAlignment = HorizontalAlignment.Center;
                t.VerticalAlignment = VerticalAlignment.Center;
                if (day == DateTime.Today) cell.Background = ColorUtil.Brush(_data.Settings.Accent);
                else if (day == _selected) cell.Background = new SolidColorBrush(Color.FromArgb(60, 79, 140, 255));
                cell.Child = t;
                // C#4 编译器：for 循环内局部被闭包共享，必须经由方法参数绑定
                cell.MouseLeftButtonUp += MakeMiniPick(day, d, onPick);
                Grid.SetRow(cell, i / 7);
                Grid.SetColumn(cell, i % 7);
                mg.Children.Add(cell);
            }
            // 右下角「确定」按钮（强调色实色圆角扁长方形）
            Border okWrap = new Border();
            okWrap.HorizontalAlignment = HorizontalAlignment.Right;
            okWrap.Margin = new Thickness(0, 8, 0, 0);
            okWrap.CornerRadius = new CornerRadius(8);
            okWrap.Background = ColorUtil.Brush(_data.Settings.Accent);
            okWrap.Padding = new Thickness(22, 5, 22, 5);
            Button okBtn = new Button();
            okBtn.Content = Ui.Lbl("确定", 12, Colors.White, true);
            okBtn.Background = Brushes.Transparent;
            okBtn.BorderThickness = new Thickness(0);
            okBtn.Cursor = Cursors.Hand;
            AutomationProperties.SetName(okBtn, "MiniOk");
            okBtn.Click += delegate { d.Close(); };
            okWrap.Child = okBtn;
            Grid col = new Grid();
            col.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1, GridUnitType.Star) });
            col.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
            Grid.SetRow(mg, 0);
            col.Children.Add(mg);
            Grid.SetRow(okWrap, 1);
            col.Children.Add(okWrap);
            d.Body.Children.Add(col);
            d.ShowDialog();
        }

        // C#4 编译器 for 循环闭包共享循环变量：把日期经方法参数绑定，各格子点击互不影响
        MouseButtonEventHandler MakeMiniPick(DateTime day, DialogHost dlg, Action<DateTime> onPick)
        {
            return delegate(object sender, MouseButtonEventArgs e)
            {
                if (onPick != null) onPick(day);
                else
                {
                    _selected = day;
                    _viewMonth = new DateTime(day.Year, day.Month, 1);
                    _dateKey = day.ToString(_dateFmt);
                    RefreshAll();
                    // 日视图：整块重建，保证日期标题、日程/待办列表、日历格子都跟着跳转
                    if (_data.Settings.ViewMode == "day") RebuildBody();
                }
                dlg.Close();
            };
        }

        // ================= 安排：开始日期 → 结束日期 → 重复设置（参考华为日历） =================
        // 必须点击两次：第一次选开始日期，第二次选结束日期；随后展开“重复”面板（不重复/每天/每周/每月/每年/农历每年 + 重复次数）。
        // 对话框按内容自动高度：重复面板出现时自然长高，不出现滚动条。
        void ShowArrangeCalendar(string title, Action<DateTime, DateTime, string, int> onDone)
        {
            DialogHost d = new DialogHost(this, title, 384, 540, false);

            DateTime viewMonth = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
            DateTime start = DateTime.MinValue;
            DateTime end = DateTime.MinValue;
            string repeat = ArrangePlan.RNone;

            Grid root = new Grid();
            for (int i = 0; i < 5; i++) root.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });

            // 月份导航
            Grid nav = new Grid();
            nav.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
            nav.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1, GridUnitType.Star) });
            nav.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
            Button prev = Ui.SmallButton("◀", "上个月");
            Button next = Ui.SmallButton("▶", "下个月");
            TextBlock monthLbl = Ui.Lbl("", 13, Colors.White, true);
            monthLbl.HorizontalAlignment = HorizontalAlignment.Center;
            monthLbl.VerticalAlignment = VerticalAlignment.Center;
            Grid.SetColumn(prev, 0); nav.Children.Add(prev);
            Grid.SetColumn(monthLbl, 1); nav.Children.Add(monthLbl);
            Grid.SetColumn(next, 2); nav.Children.Add(next);
            Grid.SetRow(nav, 0); root.Children.Add(nav);

            // 星期表头
            Grid week = new Grid();
            string[] wn = { "一", "二", "三", "四", "五", "六", "日" };
            for (int i = 0; i < 7; i++)
            {
                week.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1, GridUnitType.Star) });
                TextBlock w = Ui.Lbl(wn[i], 10.5, Color.FromArgb(140, 255, 255, 255));
                w.TextAlignment = TextAlignment.Center;
                w.Margin = new Thickness(0, 4, 0, 2);
                Grid.SetColumn(w, i);
                week.Children.Add(w);
            }
            Grid.SetRow(week, 1); root.Children.Add(week);

            // 日期格
            Grid dayGrid = new Grid();
            for (int i = 0; i < 7; i++) dayGrid.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1, GridUnitType.Star) });
            for (int i = 0; i < 6; i++) dayGrid.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(30) });
            Grid.SetRow(dayGrid, 2); root.Children.Add(dayGrid);

            // 状态行
            TextBlock status = Ui.Lbl("", 11, Color.FromArgb(180, 255, 255, 255));
            status.Margin = new Thickness(2, 6, 2, 0);
            status.TextWrapping = TextWrapping.Wrap;
            Grid.SetRow(status, 3); root.Children.Add(status);

            // 重复面板
            StackPanel repeatPanel = new StackPanel();
            repeatPanel.Margin = new Thickness(0, 8, 0, 0);
            repeatPanel.Visibility = Visibility.Visible;
            repeatPanel.Children.Add(Ui.Lbl("重复", 11.5, Color.FromArgb(200, 255, 255, 255), true));

            WrapPanel chips = new WrapPanel();
            chips.Margin = new Thickness(0, 2, 0, 0);
            string[] rNames = { "不重复", "每天", "每周", "每月", "每年", "农历每年" };
            string[] rVals = { ArrangePlan.RNone, ArrangePlan.RDay, ArrangePlan.RWeek, ArrangePlan.RMonth, ArrangePlan.RYear, ArrangePlan.RLunarYear };
            List<Action> chipRefresh = new List<Action>();
            for (int i = 0; i < rNames.Length; i++)
            {
                string val = rVals[i];
                Border chip = new Border();
                chip.CornerRadius = new CornerRadius(7);
                chip.Padding = new Thickness(10, 4, 10, 4);
                chip.Margin = new Thickness(0, 3, 6, 3);
                chip.Cursor = Cursors.Hand;
                chip.BorderThickness = new Thickness(1);
                TextBlock cl = Ui.Lbl(rNames[i], 11.5, Color.FromArgb(225, 255, 255, 255));
                chip.Child = cl;
                Action refresh = delegate
                {
                    bool sel = (repeat == val);
                    chip.Background = sel
                        ? new SolidColorBrush(Color.FromArgb(70, 79, 140, 255))
                        : new SolidColorBrush(Color.FromArgb(20, 255, 255, 255));
                    chip.BorderBrush = sel ? ColorUtil.Brush(_data.Settings.Accent) : Brushes.Transparent;
                };
                chipRefresh.Add(refresh);
                chip.MouseLeftButtonUp += delegate
                {
                    repeat = val;
                    for (int k = 0; k < chipRefresh.Count; k++) chipRefresh[k]();
                };
                chips.Children.Add(chip);
            }
            for (int k = 0; k < chipRefresh.Count; k++) chipRefresh[k]();
            repeatPanel.Children.Add(chips);

            Grid cntRow = new Grid();
            cntRow.Margin = new Thickness(0, 6, 0, 0);
            cntRow.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
            cntRow.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
            TextBlock cntLbl = Ui.Lbl("重复次数", 11.5, Color.FromArgb(190, 255, 255, 255));
            cntLbl.VerticalAlignment = VerticalAlignment.Center;
            cntLbl.Margin = new Thickness(0, 0, 8, 0);
            Grid.SetColumn(cntLbl, 0); cntRow.Children.Add(cntLbl);
            TextBox cntBox = Ui.TextInput("1", null, "ArrangeCount");
            cntBox.Text = "1";
            Border cntWrap = Ui.WrapInput(cntBox);
            cntWrap.Width = 72;
            cntWrap.VerticalAlignment = VerticalAlignment.Center;
            Grid.SetColumn(cntWrap, 1); cntRow.Children.Add(cntWrap);
            repeatPanel.Children.Add(cntRow);
            TextBlock cntHint = Ui.Lbl("重复次数为总发生次数（1-9999）；不重复时按日期范围每天安排。", 10, Color.FromArgb(130, 255, 255, 255));
            cntHint.TextWrapping = TextWrapping.Wrap;
            cntHint.Margin = new Thickness(2, 4, 2, 0);
            repeatPanel.Children.Add(cntHint);
            Grid.SetRow(repeatPanel, 4); root.Children.Add(repeatPanel);

            d.Body.Children.Add(root);

            Action updateStatus = null;
            Action render = null;
            Action<DateTime> pick = null;
            Button okBtn = null;

            updateStatus = delegate
            {
                if (start == DateTime.MinValue) status.Text = "第 1 步：点击开始日期";
                else if (end == DateTime.MinValue) status.Text = "开始：" + start.ToString("M月d日") + " " + WeekCn(start) + "　→　第 2 步：点击结束日期";
                else status.Text = "开始：" + start.ToString("M月d日") + "　结束：" + end.ToString("M月d日") + "（共 " + ((end - start).Days + 1) + " 天）";
            };

            render = delegate
            {
                monthLbl.Text = viewMonth.Year + "年" + viewMonth.Month + "月";
                dayGrid.Children.Clear();
                int lead = ((int)viewMonth.DayOfWeek + 6) % 7;
                DateTime gridStart = viewMonth.AddDays(-lead);
                Color acc = ColorUtil.Parse(_data.Settings.Accent, Color.FromArgb(255, 79, 140, 255));
                for (int i = 0; i < 42; i++)
                {
                    DateTime day = gridStart.AddDays(i);
                    bool inMonth = (day.Month == viewMonth.Month);
                    bool isStart = start != DateTime.MinValue && day.Date == start.Date;
                    bool isEnd = end != DateTime.MinValue && day.Date == end.Date;
                    bool inRange = start != DateTime.MinValue && end != DateTime.MinValue && day.Date > start.Date && day.Date < end.Date;
                    Border cell = new Border();
                    cell.Margin = new Thickness(1);
                    cell.CornerRadius = new CornerRadius(6);
                    cell.Cursor = Cursors.Hand;
                    if (isStart || isEnd) cell.Background = ColorUtil.Brush(_data.Settings.Accent);
                    else if (inRange) cell.Background = new SolidColorBrush(Color.FromArgb(60, acc.R, acc.G, acc.B));
                    else cell.Background = Brushes.Transparent;
                    if (day == DateTime.Today && !isStart && !isEnd)
                    {
                        cell.BorderBrush = new SolidColorBrush(Color.FromArgb(150, acc.R, acc.G, acc.B));
                        cell.BorderThickness = new Thickness(1);
                    }
                    TextBlock t = Ui.Lbl(day.Day.ToString(), 11.5,
                        (isStart || isEnd) ? Colors.White : (inMonth ? Color.FromArgb(235, 255, 255, 255) : Color.FromArgb(95, 255, 255, 255)),
                        isStart || isEnd);
                    t.HorizontalAlignment = HorizontalAlignment.Center;
                    t.VerticalAlignment = VerticalAlignment.Center;
                    cell.Child = t;
                    cell.MouseLeftButtonUp += MakeArrangePick(day, pick);
                    Grid.SetRow(cell, i / 7);
                    Grid.SetColumn(cell, i % 7);
                    dayGrid.Children.Add(cell);
                }
                updateStatus();
            };

            pick = delegate(DateTime day)
            {
                if (start == DateTime.MinValue)
                {
                    start = day.Date;
                    end = DateTime.MinValue;
                }
                else if (end == DateTime.MinValue)
                {
                    if (day.Date < start.Date) { start = day.Date; end = DateTime.MinValue; }
                    else end = day.Date;
                }
                else
                {
                    if (day.Date >= start.Date) end = day.Date;
                    else { start = day.Date; end = DateTime.MinValue; }
                }
                bool ready = (start != DateTime.MinValue && end != DateTime.MinValue);
                if (okBtn != null) okBtn.IsEnabled = ready;
                render();
            };

            prev.Click += delegate { viewMonth = viewMonth.AddMonths(-1); render(); };
            next.Click += delegate { viewMonth = viewMonth.AddMonths(1); render(); };

            Button cancelBtn = d.AddAction("取消", false);
            cancelBtn.Click += delegate { d.Close(); };
            okBtn = d.AddAction("确定", true);
            okBtn.IsEnabled = false;
            okBtn.Click += delegate
            {
                if (start == DateTime.MinValue || end == DateTime.MinValue) return;
                int cnt = 1;
                if (repeat != ArrangePlan.RNone)
                {
                    if (!int.TryParse(cntBox.Text.Trim(), out cnt) || cnt < 1 || cnt > 9999)
                    {
                        status.Text = "请填写重复次数（1-9999）";
                        return;
                    }
                }
                onDone(start, end, repeat, cnt);
                d.Close();
            };

            render();
            d.ShowDialog();
        }

        MouseButtonEventHandler MakeArrangePick(DateTime day, Action<DateTime> pick)
        {
            return delegate(object sender, MouseButtonEventArgs e) { pick(day); };
        }

        // 强调色竖向分隔线（样式随设置变化，长度=内容区 2/3 并垂直居中，可点击区域让给 GridSplitter）
        // 外层 Grid 行分布 1/4/1，内层 Border 置于中间 2/3 行
        Grid MakeDivider(out Border inner)
        {
            Grid wrap = new Grid();
            // 分隔线只是装饰：整层不参与命中测试，鼠标事件全部让给同一列里的 GridSplitter
            wrap.IsHitTestVisible = false;
            wrap.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1, GridUnitType.Star) });
            wrap.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(4, GridUnitType.Star) });
            wrap.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1, GridUnitType.Star) });

            Border b = new Border();
            b.Width = 6;
            b.HorizontalAlignment = HorizontalAlignment.Stretch;
            b.VerticalAlignment = VerticalAlignment.Stretch;
            b.Background = Ui.DividerBrush(ColorUtil.Parse(_data.Settings.Accent, Color.FromArgb(255, 79, 140, 255)), _data.Settings.DividerStyle);
            b.IsHitTestVisible = false;
            Grid.SetRow(b, 1);
            wrap.Children.Add(b);

            inner = b;
            return wrap;
        }

        // 可拖拽的竖向分隔条：直接调整相邻两列的宽度（比 GridSplitter 更可控，避免被同列分隔线挡住）
        Border MakeSplitter(int prevCol, int nextCol)
        {
            Border grip = new Border();
            grip.Width = 6;
            grip.HorizontalAlignment = HorizontalAlignment.Stretch;
            grip.VerticalAlignment = VerticalAlignment.Stretch;
            grip.Background = Brushes.Transparent;
            grip.Cursor = Cursors.SizeWE;
            grip.ToolTip = "拖动调整栏宽";
            AutomationProperties.SetName(grip, "ColSplitter" + prevCol + "_" + nextCol);
            double startX = 0, startCal = 0, startSched = 0, startTodo = 0;
            bool dragging = false;

            grip.MouseLeftButtonDown += delegate(object s, MouseButtonEventArgs e)
            {
                if (_body == null) return;
                startX = e.GetPosition(this).X;
                startCal = _body.ColumnDefinitions[0].ActualWidth;
                startSched = _body.ColumnDefinitions[2].ActualWidth;
                startTodo = _body.ColumnDefinitions[4].ActualWidth;
                dragging = true;
                grip.CaptureMouse();
                e.Handled = true;
            };
            grip.MouseMove += delegate(object s, MouseEventArgs e)
            {
                if (!dragging || _body == null) return;
                double dx = e.GetPosition(this).X - startX;
                double cal = startCal, sched = startSched, todo = startTodo;
                if (prevCol == 0)
                {
                    // 左分隔条：日历与日程互相让位，待办栏宽度不变
                    cal = startCal + dx;
                    sched = startSched - dx;
                }
                else
                {
                    // 右分隔条：日程与待办互相让位，日历不变
                    sched = startSched + dx;
                    todo = startTodo - dx;
                }
                ApplyMonthWeights(cal, sched, todo);
            };
            grip.MouseLeftButtonUp += delegate
            {
                if (!dragging) return;
                dragging = false;
                grip.ReleaseMouseCapture();
                if (_body != null && _body.ColumnDefinitions.Count > 4)
                {
                    // 分隔线位置也对齐 20px 网格后固定
                    double cal = _body.ColumnDefinitions[0].ActualWidth;
                    double sched = _body.ColumnDefinitions[2].ActualWidth;
                    double todo = _body.ColumnDefinitions[4].ActualWidth;
                    cal = Math.Round(cal / GridSize) * GridSize;
                    sched = Math.Round(sched / GridSize) * GridSize;
                    todo = Math.Round(todo / GridSize) * GridSize;
                    ApplyMonthWeights(cal, sched, todo);
                    _body.UpdateLayout();
                    _data.Settings.CalendarWidth = _body.ColumnDefinitions[0].ActualWidth;
                    if (_body.ColumnDefinitions[2].ActualWidth >= 260 && _body.ColumnDefinitions[4].ActualWidth >= 250)
                    {
                        _data.Settings.ScheduleWidth = _body.ColumnDefinitions[2].ActualWidth;
                        _data.Settings.TodoWidth = _body.ColumnDefinitions[4].ActualWidth;
                    }
                    SaveSoon();
                }
            };
            grip.MouseEnter += delegate { grip.Background = new SolidColorBrush(Color.FromArgb(40, 79, 140, 255)); };
            grip.MouseLeave += delegate { if (!dragging) grip.Background = Brushes.Transparent; };
            return grip;
        }

        void BuildTimers()
        {
            _saveTimer = new DispatcherTimer();
            _saveTimer.Interval = TimeSpan.FromMilliseconds(600);
            _saveTimer.Tick += delegate { _saveTimer.Stop(); SaveNow(); };

            _posTimer = new DispatcherTimer();
            _posTimer.Interval = TimeSpan.FromMilliseconds(700);
            _posTimer.Tick += delegate { _posTimer.Stop(); SaveNow(); };

            _edgeTimer = new DispatcherTimer();
            _edgeTimer.Interval = TimeSpan.FromMilliseconds(160);
            _edgeTimer.Tick += OnEdgeTick;
            _edgeTimer.Start();

            _statusTimer = new DispatcherTimer();
            _statusTimer.Interval = TimeSpan.FromSeconds(2.6);
            _statusTimer.Tick += delegate
            {
                _statusTimer.Stop();
                if (_statusLine != null) _statusLine.Text = "";
                UpdateWeekTarget(); // 周视图把临时提示显示在底部目标日期标签上，超时后恢复日期
            };

            // 自动月报：每分钟检查一次“当月第 3 个周一 10:30”
            _monthlyTimer = new DispatcherTimer();
            _monthlyTimer.Interval = TimeSpan.FromSeconds(60);
            _monthlyTimer.Tick += delegate { CheckMonthlyReport(); };
            _monthlyTimer.Start();
        }

        void OnLoaded(object sender, RoutedEventArgs e)
        {
            _loadedTick = Environment.TickCount;
            _hwnd = HwndSource.FromHwnd(new WindowInteropHelper(this).Handle);
            if (_hwnd != null) _hwnd.AddHook(WndProc);
            // 启动时按视图定位：日视图贴右，周/月视图相对桌面居中
            if (_data.Settings.ViewMode == "day")
            {
                DockDayNearMonthRight();
            }
            else
            {
                CenterOnDesktop();
            }
            RefreshAll();
            CheckMonthlyReport(); // 启动时立即检查一次（错过触发时刻也能补跑）
        }

        // 周/月视图：水平相对桌面居中，垂直保持上次记录的位置
        void CenterOnDesktop()
        {
            Rect wa = SystemParameters.WorkArea;
            Left = wa.Left + Math.Max(0, (wa.Width - Width) / 2);
            double top = _data.Settings.Top;
            if (top < wa.Top || top > wa.Bottom - 80) top = Top;
            top = Math.Min(Math.Max(top, wa.Top), Math.Max(wa.Top, wa.Bottom - Height));
            Top = top;
            EnsureOnScreen();
        }

        // 保证窗口始终完整可见（防止切换视图后跑到屏幕外导致“界面消失”）
        void EnsureOnScreen()
        {
            Rect wa = SystemParameters.WorkArea;
            if (double.IsNaN(Left) || double.IsNaN(Top)) { Left = wa.Left + 40; Top = wa.Top + 40; }
            double maxL = Math.Max(wa.Left, wa.Right - Math.Min(Width, wa.Width));
            double maxT = Math.Max(wa.Top, wa.Bottom - Math.Min(Height, wa.Height));
            if (Left > maxL) Left = maxL;
            if (Left < wa.Left) Left = wa.Left;
            if (Top > maxT) Top = maxT;
            if (Top < wa.Top) Top = wa.Top;
        }

        // 日视图贴边位置：月视图（水平居中）右侧边界的靠右位置
        void DockDayNearMonthRight()
        {
            Rect wa = SystemParameters.WorkArea;
            double monthW = _data.Settings.MonthWidth >= MinWinW ? _data.Settings.MonthWidth : _data.Settings.Width;
            double monthRight = wa.Left + (wa.Width + monthW) / 2;
            double left = monthRight - Width;
            left = Math.Min(Math.Max(left, wa.Left), Math.Max(wa.Left, wa.Right - Width));
            Left = left;
            double top = _data.Settings.Top;
            if (top < wa.Top || top > wa.Bottom - 80) top = Top;
            Top = Math.Min(Math.Max(top, wa.Top), Math.Max(wa.Top, wa.Bottom - Height));
            EnsureOnScreen();
        }

        void OnClosing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!_closingByExit)
            {
                e.Cancel = true;
                HideToTray();
                return;
            }
            SaveNow();
        }

        void HideToTray()
        {
            Hide();
        }

        // ================= 拖拽 / 缩放 / 贴边 =================
        void DragWindow()
        {
            if (_compact || _docked) return;
            _dragging = true;
            try { DragMove(); } catch { }
            _dragging = false;
            SnapWindowToGrid();
            UpdateDockState();
        }

        // 对齐桌面网格（20px）：拖动结束后把窗口位置吸附到网格线上
        public const int GridSize = 20;
        void SnapWindowToGrid()
        {
            Rect wa = SystemParameters.WorkArea;
            double x = Left - wa.Left;
            double y = Top - wa.Top;
            double sx = wa.Left + Math.Round(x / GridSize) * GridSize;
            double sy = wa.Top + Math.Round(y / GridSize) * GridSize;
            double maxX = Math.Max(wa.Left, wa.Right - Width);
            double maxY = Math.Max(wa.Top, wa.Bottom - Height);
            sx = Math.Min(Math.Max(sx, wa.Left), maxX);
            sy = Math.Min(Math.Max(sy, wa.Top), maxY);
            if (Math.Abs(sx - Left) > 0.5 || Math.Abs(sy - Top) > 0.5)
            {
                Left = sx;
                Top = sy;
            }
        }

        IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            if (msg == WM_EXITSIZEMOVE && !_compact)
            {
                // 原生拖动/缩放结束时对齐网格，并记录窗口位置与尺寸
                SnapWindowToGrid();
                if (_data != null && _data.Settings.ViewMode == "day" && _daySized)
                {
                    _data.Settings.DayLeft = Left;
                    _data.Settings.DayTop = Top;
                    _data.Settings.DayWidth = Width;
                    _data.Settings.DayHeight = Height;
                }
                SaveSoon();
            }
            if (msg == WM_NCHITTEST && !_compact && !_docked)
            {
                int x = (short)(lParam.ToInt64() & 0xFFFF);
                int y = (short)((lParam.ToInt64() >> 16) & 0xFFFF);
                int code = HitTestFor(hwnd, x, y);
                if (code != 0)
                {
                    handled = true;
                    return new IntPtr(code);
                }
            }
            else if (msg == WM_SETCURSOR && !_compact && !_docked)
            {
                POINT pt;
                GetCursorPos(out pt);
                int code = HitTestFor(hwnd, pt.X, pt.Y);
                int cur = 0;
                if (code == HTTOPLEFT || code == HTBOTTOMRIGHT) cur = IDC_SIZENWSE;
                else if (code == HTTOPRIGHT || code == HTBOTTOMLEFT) cur = IDC_SIZENESW;
                else if (code == HTLEFT || code == HTRIGHT) cur = IDC_SIZEWE;
                else if (code == HTTOP || code == HTBOTTOM) cur = IDC_SIZENS;
                if (cur != 0)
                {
                    SetCursor(LoadCursor(IntPtr.Zero, cur));
                    handled = true;
                    return IntPtr.Zero;
                }
            }
            else if (msg == WM_NCLBUTTONDOWN && !_compact && !_docked)
            {
                int ht = wParam.ToInt32();
                // 部分系统/DPI 组合下 wParam 可能不是热区值，用光标位置重新判定
                if (ht < HTLEFT || ht > HTBOTTOMRIGHT)
                {
                    POINT pt;
                    GetCursorPos(out pt);
                    ht = HitTestFor(hwnd, pt.X, pt.Y);
                }
                if (ht >= HTLEFT && ht <= HTBOTTOMRIGHT)
                {
                    _resizing = true;
                    _resizeEdge = ht;
                    GetWindowRect(hwnd, out _resizeStart);
                    GetCursorPos(out _resizeOrigin);
                    SetCapture(hwnd);
                    handled = true;
                    return IntPtr.Zero;
                }
            }
            else if ((msg == WM_MOUSEMOVE || msg == WM_NCMOUSEMOVE) && _resizing)
            {
                POINT pt;
                GetCursorPos(out pt);
                int dx = pt.X - _resizeOrigin.X;
                int dy = pt.Y - _resizeOrigin.Y;
                // 缩放下限用当前窗口最小宽高（日视图进入时临时放宽为 120，避免被 880x580 全局下限顶回）
                double minW = MinWidth > 0 ? MinWidth : MinWinW;
                double minH = MinHeight > 0 ? MinHeight : MinWinH;
                Point minPx = DipsToPx(new Point(minW, minH));
                double w0 = _resizeStart.Right - _resizeStart.Left;
                double h0 = _resizeStart.Bottom - _resizeStart.Top;
                if (w0 <= 0) w0 = MinWinW;
                if (h0 <= 0) h0 = MinWinH;

                // 四角：等比缩放（以拖拽中相对变化大的方向为准，宽高按同一比例变化）
                // 四边：只拉伸单方向
                double scX = 1.0, scY = 1.0;
                if (_resizeEdge == HTRIGHT || _resizeEdge == HTTOPRIGHT || _resizeEdge == HTBOTTOMRIGHT) scX = (w0 + dx) / w0;
                else if (_resizeEdge == HTLEFT || _resizeEdge == HTTOPLEFT || _resizeEdge == HTBOTTOMLEFT) scX = (w0 - dx) / w0;
                if (_resizeEdge == HTBOTTOM || _resizeEdge == HTBOTTOMLEFT || _resizeEdge == HTBOTTOMRIGHT) scY = (h0 + dy) / h0;
                else if (_resizeEdge == HTTOP || _resizeEdge == HTTOPLEFT || _resizeEdge == HTTOPRIGHT) scY = (h0 - dy) / h0;

                double sc;
                double minScaleX = minPx.X / w0;
                double minScaleY = minPx.Y / h0;
                if (_resizeEdge == HTLEFT || _resizeEdge == HTRIGHT) { sc = scX; if (sc < minScaleX) sc = minScaleX; }
                else if (_resizeEdge == HTTOP || _resizeEdge == HTBOTTOM) { sc = scY; if (sc < minScaleY) sc = minScaleY; }
                else { sc = Math.Max(scX, scY); double ms = Math.Max(minScaleX, minScaleY); if (sc < ms) sc = ms; }

                double nw = w0 * sc;
                double nh = h0 * sc;
                int iw = (int)Math.Round(nw);
                int ih = (int)Math.Round(nh);
                int l = _resizeStart.Left, t = _resizeStart.Top,
                    r = _resizeStart.Right, b = _resizeStart.Bottom;
                switch (_resizeEdge)
                {
                    case HTBOTTOMRIGHT: r = _resizeStart.Left + iw; b = _resizeStart.Top + ih; break;
                    case HTBOTTOMLEFT: l = _resizeStart.Right - iw; b = _resizeStart.Top + ih; break;
                    case HTTOPRIGHT: r = _resizeStart.Left + iw; t = _resizeStart.Bottom - ih; break;
                    case HTTOPLEFT: l = _resizeStart.Right - iw; t = _resizeStart.Bottom - ih; break;
                    case HTRIGHT: r = _resizeStart.Left + iw; break;
                    case HTLEFT: l = _resizeStart.Right - iw; break;
                    case HTBOTTOM: b = _resizeStart.Top + ih; break;
                    case HTTOP: t = _resizeStart.Bottom - ih; break;
                }
                MoveWindow(hwnd, l, t, r - l, b - t, true);
                handled = true;
                return IntPtr.Zero;
            }
            else if ((msg == WM_LBUTTONUP || msg == WM_NCLBUTTONUP) && _resizing)
            {
                _resizing = false;
                ReleaseCapture();
                RestartPosSave();
                SaveSoon();
                handled = true;
                return IntPtr.Zero;
            }
            return IntPtr.Zero;
        }

        // 判定屏幕坐标 (x,y) 落在窗口哪个缩放热区（0=非缩放区）。四角等比缩放，四边单方向拉伸。
        int HitTestFor(IntPtr hwnd, int x, int y)
        {
            RECT r;
            GetWindowRect(hwnd, out r);
            // 窗口四周有 18 DIP 的透明外框：圆角面板从 18 DIP 处才开始显示。
            // 热区必须从窗口物理边缘一直覆盖到可见面板边缘、再向内容里延伸一段，否则按在看得见的角/边上
            // 反而落在热区外（此前角仅 16px，全部落在透明外框里，且与可见区域有一段距离）。
            int margin = (int)Math.Round(DipsToPx(new Point(18, 0)).X);
            if (margin < 10) margin = 18;
            int z = margin + 14;    // 四角热区：透明外框 + 可见角内 14px
            int ez = margin + 4;    // 四边热区：透明外框 + 可见边内 4px
            bool l = x >= r.Left && x <= r.Left + z;
            bool rt = x >= r.Right - z && x <= r.Right;
            bool t = y >= r.Top && y <= r.Top + z;
            bool b = y >= r.Bottom - z && y <= r.Bottom;

            if (t && l) return HTTOPLEFT;
            if (t && rt) return HTTOPRIGHT;
            if (b && l) return HTBOTTOMLEFT;
            if (b && rt) return HTBOTTOMRIGHT;

            bool le = x >= r.Left && x <= r.Left + ez;
            bool re = x >= r.Right - ez && x <= r.Right;
            bool te = y >= r.Top && y <= r.Top + ez;
            bool be = y >= r.Bottom - ez && y <= r.Bottom;
            if (le) return HTLEFT;
            if (re) return HTRIGHT;
            if (te) return HTTOP;
            if (be) return HTBOTTOM;
            return 0;
        }

        void UpdateDockState()
        {
            if (_compact) return;
            if (!_data.Settings.EdgeDock) return;
            if (_docked) return;
            if (_dragging) return; // 拖动标题栏过程中不贴边：否则拖到边缘会立刻变成细条，随后卡住
            if (_resizing) return; // 缩放拖拽期间禁止贴边，避免左/上边缘贴近屏幕边缘时误触发收起
            // 启动后 3 秒内禁止自动贴边，避免窗口首次定位在屏幕边缘时被误收起
            if (_loadedTick < 0 || Environment.TickCount - _loadedTick < 3000) return;

            if (Width < 80 || Height < 60) return;
            Rect waPx = WorkAreaPx();
            Rect winPx = WindowPx();
            if (Math.Abs(winPx.Left - waPx.Left) < 6) DockToEdge(true, waPx);
            else if (Math.Abs(winPx.Right - waPx.Right) < 6) DockToEdge(false, waPx);
        }

        // 贴边收起为一条细条。必须临时解除 MinWidth/MinHeight，否则月视图 880 的最小宽度会把
        // 12px 细条顶成一条很宽的“分隔线”（既挡住桌面又几乎无法展开，即用户反馈的卡住问题）。
        void DockToEdge(bool left, Rect waPx)
        {
            _docked = true;
            _dockedLeft = left;
            _dockArmed = false;
            _fullBounds = new Rect(Left, Top, Width, Height);
            ShowDockBar();
            double w = 12;
            if (left) Left = PxToDip(waPx.Left);
            else Left = PxToDip(waPx.Right) - w;
            Width = w;
            // 垂直方向收进工作区，避免细条有一部分落在屏幕外
            double topDip = PxToDip(waPx.Top);
            double bottomDip = PxToDip(waPx.Bottom);
            if (Top < topDip) Top = topDip;
            if (Top + Height > bottomDip) Top = Math.Max(topDip, bottomDip - Height);
            SaveSoon();
        }

        void ShowDockBar()
        {
            _rootBorder.Margin = new Thickness(0);
            _rootBorder.CornerRadius = new CornerRadius(_dockedLeft ? 0 : 6, _dockedLeft ? 6 : 0, _dockedLeft ? 6 : 0, 0);
            MinWidth = 0;
            MinHeight = 0;
            _dockBar = new Border();
            _dockBar.Background = new SolidColorBrush(Color.FromArgb(64, 255, 255, 255));
            _dockBar.Cursor = Cursors.Hand;
            _dockBar.ToolTip = "点击或把鼠标移到边缘展开窗口";
            Border line = new Border();
            line.Width = 2;
            line.HorizontalAlignment = HorizontalAlignment.Center;
            line.VerticalAlignment = VerticalAlignment.Stretch;
            line.Background = ColorUtil.Brush(_data.Settings.Accent);
            _dockBar.Child = line;
            _dockBar.MouseLeftButtonUp += delegate { ExpandDock(); };
            _main.Visibility = Visibility.Collapsed;
            Content = _dockBar;
        }

        void HideDockBar()
        {
            _docked = false;
            _dockArmed = false;
            _rootBorder.Margin = new Thickness(18);
            _rootBorder.CornerRadius = new CornerRadius(14);
            _main.Visibility = Visibility.Visible;
            Content = _viewRoot;
            ApplyMinSizeForView();
        }

        // 恢复当前视图应有的最小尺寸（日视图比全局下限小）
        void ApplyMinSizeForView()
        {
            if (_data.Settings.ViewMode == "day")
            {
                MinWidth = 260;
                MinHeight = 320;
            }
            else
            {
                MinWidth = MinWinW;
                MinHeight = MinWinH;
            }
        }

        void ExpandDock()
        {
            if (!_docked) return;
            Rect fb = _fullBounds;
            Left = fb.X;
            Top = fb.Y;
            Width = fb.Width;
            Height = fb.Height;
            HideDockBar();
            RefreshAll();
            SaveSoon();
        }

        void OnEdgeTick(object sender, EventArgs e)
        {
            if (!_docked) return;
            POINT p;
            GetCursorPos(out p);
            RECT r;
            GetWindowRect(new WindowInteropHelper(this).Handle, out r);
            int edgeX = _dockedLeft ? r.Left : r.Right;
            int distX = _dockedLeft ? (p.X - edgeX) : (edgeX - p.X);
            bool inY = p.Y >= r.Top - 6 && p.Y <= r.Bottom + 6;
            if (!_dockArmed)
            {
                // 贴边后先把鼠标移开一段距离（或移出窗口上下范围），再移回边缘才展开；
                // 避免刚贴边就立即弹回，也避免拖动结束时鼠标停在线条上导致反复收起/展开。
                if (distX > 20 || !inY) _dockArmed = true;
                return;
            }
            if (inY && distX <= 16 && distX >= -4) ExpandDock();
        }

        void OnWindowMouseEnter(object sender, MouseEventArgs e)
        {
            if (_docked && _dockArmed) ExpandDock();
        }

        Rect WindowPx()
        {
            Point tl = DipsToPx(new Point(Left, Top));
            Point br = DipsToPx(new Point(Left + Width, Top + Height));
            return new Rect(tl.X, tl.Y, br.X - tl.X, br.Y - tl.Y);
        }

        Rect WorkAreaPx()
        {
            Rect win = WindowPx();
            var scr = System.Windows.Forms.Screen.FromPoint(new System.Drawing.Point((int)(win.X + win.Width / 2), (int)(win.Y + win.Height / 2)));
            var wa = scr.WorkingArea;
            return new Rect(wa.Left, wa.Top, wa.Width, wa.Height);
        }

        Point DipsToPx(Point p)
        {
            if (_hwnd == null) return p;
            System.Windows.Media.Matrix m = _hwnd.CompositionTarget.TransformToDevice;
            return m.Transform(p);
        }

        double PxToDip(double px)
        {
            if (_hwnd == null) return px;
            System.Windows.Media.Matrix m = _hwnd.CompositionTarget.TransformFromDevice;
            return m.Transform(new Point(px, 0)).X;
        }

        void RestartPosSave()
        {
            _posTimer.Stop();
            _posTimer.Start();
        }

        // ================= 紧凑模式 =================
        void EnterCompact()
        {
            if (_compact) return;
            _normalBounds = new Rect(Left, Top, Width, Height);
            _preCompactMinW = MinWidth;
            _preCompactMinH = MinHeight;
            _compact = true;
            // 解除最小尺寸约束：否则 104x44 会被 MinWidth/MinHeight 撑回 880x580，
            // 贴到屏幕边缘时就显示为粗条色块
            MinWidth = 0;
            MinHeight = 0;
            Rect waPx = WorkAreaPx();
            double dip = PxToDip(1);
            double w = 104;
            double h = 44;
            Left = PxToDip(waPx.Right) - w - 12 * dip;
            Top = PxToDip(waPx.Top) + 12 * dip;
            Width = w;
            Height = h;
            Topmost = true;

            _compactLabel = new Border();
            _compactLabel.CornerRadius = new CornerRadius(22);
            _compactLabel.Background = ColorUtil.Brush(_data.Settings.Accent);
            _compactLabel.Cursor = Cursors.Hand;
            TextBlock lbl = Ui.Lbl("待办", 14, Colors.White, true);
            lbl.HorizontalAlignment = HorizontalAlignment.Center;
            lbl.VerticalAlignment = VerticalAlignment.Center;
            AutomationProperties.SetName(lbl, "CompactLabel");
            _compactLabel.Child = lbl;
            _compactLabel.MouseLeftButtonUp += delegate { ExitCompact(); };
            Content = _compactLabel;
            Activate();
            Focus();
        }

        void ExitCompact()
        {
            if (!_compact) return;
            _compact = false;
            Rect nb = _normalBounds;
            // 恢复紧凑前的最小尺寸约束（日视图为月视图日历栏宽高，而非全局 880x580），
            // 保证恢复后尺寸不变且仍可继续拖拽缩放
            double minW = _preCompactMinW > 0 ? _preCompactMinW : MinWinW;
            double minH = _preCompactMinH > 0 ? _preCompactMinH : MinWinH;
            MinWidth = minW;
            MinHeight = minH;
            if (nb.Width < minW) nb.Width = minW;
            if (nb.Height < minH) nb.Height = minH;
            Left = nb.X;
            Top = nb.Y;
            Width = nb.Width;
            Height = nb.Height;
            Content = _viewRoot;
            _rootBorder.Margin = new Thickness(18);
            _rootBorder.CornerRadius = new CornerRadius(14);
            _main.Visibility = Visibility.Visible;
            ApplyTopmost();
            RefreshAll();
            SaveSoon();
        }

        void OnWindowKeyDown(object sender, KeyEventArgs e)
        {
            if (_compact && (e.Key == Key.Enter || e.Key == Key.Space))
            {
                e.Handled = true;
                ExitCompact();
            }
        }

        // ================= 外观 =================
        void ApplySettings()
        {
            AppSettings s = _data.Settings;
            if (s.Width >= MinWinW) Width = s.Width;
            if (s.Height >= MinWinH) Height = s.Height;
            if (s.Left != -1 && s.Top != -1)
            {
                Left = s.Left;
                Top = s.Top;
            }
            else
            {
                WindowStartupLocation = WindowStartupLocation.CenterScreen;
            }
            ApplyAppearance();
            ApplyTopmost();
        }

        void ApplyAppearance()
        {
            AppSettings s = _data.Settings;
            // 窗口样式切换：整体重建主体布局。日视图默认尺寸一律 = 月视图日历栏宽高（含窗口外框），
            // 切离后恢复进入前的尺寸；最小尺寸按日视图放宽，保证“—”收起后恢复不被 880 顶回、且仍可拖拽缩小。
            if (_lastViewMode != s.ViewMode)
            {
                string prev = _lastViewMode;
                RememberViewSize(prev);
                _lastViewMode = s.ViewMode;
                if (s.ViewMode == "day")
                {
                    SavePreDayBounds();
                    EnterDayView(prev);
                }
                else
                {
                    if (prev == "day") LeaveDayView();
                    RestoreViewSize(s.ViewMode);
                    if (s.ViewMode == "week")
                    {
                        SyncWeekToSelected();
                        NormalizeWeekTarget();
                    }
                    // 切到周/月视图：水平居中，垂直沿用上次位置（之后仍可自由拖动并记住）
                    CenterOnDesktop();
                }
                ClearCardSelection();
                RebuildBody();
            }
            else if (s.ViewMode == "day" && !_daySized)
            {
                // 启动即为日视图 / 首次应用设置：同样按月历栏尺寸定位
                SavePreDayBounds();
                EnterDayView("none");
            }
            Color bg = ColorUtil.Parse(s.Background, Color.FromArgb(230, 25, 26, 34));
            int alpha = (int)(bg.A * s.Opacity);
            if (alpha < 60) alpha = 60;
            if (alpha > 255) alpha = 255;
            _rootBorder.Background = new SolidColorBrush(Color.FromArgb((byte)alpha, bg.R, bg.G, bg.B));
            if (_todoFloatBorder != null) _todoFloatBorder.Background = Ui.ThemedBackground();
            UpdateAccentVisuals();
            RefreshAll();
        }

        // 记住/恢复各视图的窗口尺寸（月视图与周视图尺寸相互独立）
        void RememberViewSize(string view)
        {
            if (view == "month")
            {
                _data.Settings.MonthWidth = Width;
                _data.Settings.MonthHeight = Height;
            }
            else if (view == "week")
            {
                _data.Settings.WeekWidth = Width;
                _data.Settings.WeekHeight = Height;
            }
        }

        void RestoreViewSize(string view)
        {
            double w = 0, h = 0;
            if (view == "month") { w = _data.Settings.MonthWidth; h = _data.Settings.MonthHeight; }
            else if (view == "week") { w = _data.Settings.WeekWidth; h = _data.Settings.WeekHeight; }
            if (w >= MinWinW && h >= MinWinH)
            {
                Width = w;
                Height = h;
            }
        }

        // 月视图：窗口变窄时先收缩待办栏、再收缩日程栏，保证整栏跟随窗口而不是被裁掉
        void FitMonthLayout()
        {
            // 三栏已改为星号比例，窗口缩放时由 Grid 自动精确铺满，无需再手动收缩；
            // 仅在栏宽记录明显偏离当前实际宽度时同步一次比例（例如从日视图切回、窗口恢复尺寸）。
            if (_body == null || _data.Settings.ViewMode != "month" || _body.ColumnDefinitions.Count < 5) return;
            double cal = _body.ColumnDefinitions[0].ActualWidth;
            double sched = _body.ColumnDefinitions[2].ActualWidth;
            double todo = _body.ColumnDefinitions[4].ActualWidth;
            if (cal < 50 || sched < 50 || todo < 50) return;
            ApplyMonthWeights(cal, sched, todo);
        }

        // 按像素比例设置月视图三栏的星号宽度（保证总量恰好等于可用宽度，待办栏贴右边缘）
        void ApplyMonthWeights(double cal, double sched, double todo)
        {
            if (_body == null || _body.ColumnDefinitions.Count < 5) return;
            double minCal = double.IsNaN(_body.ColumnDefinitions[0].MinWidth) ? 0 : _body.ColumnDefinitions[0].MinWidth;
            if (cal < minCal) cal = minCal;
            if (sched < _body.ColumnDefinitions[2].MinWidth) sched = _body.ColumnDefinitions[2].MinWidth;
            if (todo < _body.ColumnDefinitions[4].MinWidth) todo = _body.ColumnDefinitions[4].MinWidth;
            double total = Math.Max(1, cal + sched + todo);
            _body.ColumnDefinitions[0].Width = new GridLength(cal / total, GridUnitType.Star);
            _body.ColumnDefinitions[2].Width = new GridLength(sched / total, GridUnitType.Star);
            _body.ColumnDefinitions[4].Width = new GridLength(todo / total, GridUnitType.Star);
        }

        // 新建自定义分类（名称 + 颜色），供分类选择弹窗调用
        public static List<string> CategoryList
        {
            get { return Instance != null ? Instance._data.Settings.Categories : new List<string>(); }
        }

        public static void AddCategory(string name, string color)
        {
            if (Instance == null || string.IsNullOrEmpty(name)) return;
            AppSettings s = Instance._data.Settings;
            if (!s.Categories.Contains(name)) s.Categories.Add(name);
            s.CategoryColors[name] = color;
            Cats.CustomColors[name] = color;
            Instance.SaveSoon();
            Instance.RefreshAll();
        }

        // 记录进入日视图前的窗口尺寸（离开日视图时原样恢复）
        void SavePreDayBounds()        {
            if (_preDayWidth > 0) return;
            double w = (double.IsNaN(Width) || Width <= 0) ? _data.Settings.Width : Width;
            double h = (double.IsNaN(Height) || Height <= 0) ? _data.Settings.Height : Height;
            if (w < MinWinW) w = MinWinW;
            if (h < MinWinH) h = MinWinH;
            _preDayWidth = w;
            _preDayHeight = h;
        }

        // 进入日视图：窗口尺寸一律 = 月视图日历栏宽高。
        // 宽度 = 日历列实际宽 + 左右各 18px 外框；高度 = 进入前窗口高度（内容区高度恰为月历栏高度）。
        // 缩放下限单独放宽到 260x320，避免紧凑恢复被全局 880x580 钳制、也保证宽度可以继续拖拽缩小。
        void EnterDayView(string prev)
        {
            if (prev == "month" && _body != null && _body.ColumnDefinitions.Count > 0
                && _body.ColumnDefinitions[0].ActualWidth > 10)
            {
                _monthCalW = _body.ColumnDefinitions[0].ActualWidth;
                _data.Settings.CalendarWidth = _monthCalW;
            }
            if (_monthCalW < 200) _monthCalW = 342;
            double calW = _monthCalW;
            double winH = _preDayHeight > 0 ? _preDayHeight : _data.Settings.Height;
            if (winH < MinWinH) winH = MinWinH;

            MinWidth = 260;
            MinHeight = 320;
            Width = Math.Max(MinWidth, calW + 36);
            Height = Math.Max(MinHeight, winH);
            // 切到日视图：优先恢复上次记录的位置与尺寸；首次则自动靠桌面右侧贴边
            Rect wa = SystemParameters.WorkArea;
            double dw = _data.Settings.DayWidth > 0 ? Math.Max(MinWidth, _data.Settings.DayWidth) : Math.Max(MinWidth, calW + 36);
            double dh = _data.Settings.DayHeight > 0 ? Math.Max(MinHeight, _data.Settings.DayHeight) : Math.Max(MinHeight, winH);
            Width = dw;
            Height = dh;
            // 每次切换到日视图都贴到「月视图居中位置的右侧边界」附近；之后仍可自由拖动，位置会被记住
            DockDayNearMonthRight();
            _daySized = true;
        }

        // 离开日视图：恢复进入前的窗口尺寸与全局最小尺寸
        void LeaveDayView()
        {
            _daySized = false;
            MinWidth = MinWinW;
            MinHeight = MinWinH;
            if (_preDayWidth > 0) Width = Math.Max(MinWinW, _preDayWidth);
            if (_preDayHeight > 0) Height = Math.Max(MinWinH, _preDayHeight);
            _preDayWidth = -1;
            _preDayHeight = -1;
        }

        // 周视图：让视图周跟随当前选中日期（从月视图切换过来时保持同一日期所在周）
        void SyncWeekToSelected()
        {
            DateTime ws = _selected.AddDays(-(((int)_selected.DayOfWeek + 6) % 7));
            if (_viewWeek.Date != ws.Date) _viewWeek = ws;
        }

        void ApplyTopmost()
        {
            Topmost = _data.Settings.Topmost;
            if (_pinBtn != null)
            {
                if (_data.Settings.Topmost)
                {
                    // 置顶激活：强调色半透明淡背景（非实色 hover 效果）+ 白字，悬停时加深
                    Color acc = ColorUtil.Parse(_data.Settings.Accent, Colors.White);
                    _pinBtn.Background = new SolidColorBrush(Color.FromArgb(52, acc.R, acc.G, acc.B));
                    _pinBtn.Foreground = Brushes.White;
                }
                else
                {
                    _pinBtn.Background = Brushes.Transparent;
                    _pinBtn.Foreground = new SolidColorBrush(Color.FromArgb(225, 255, 255, 255));
                }
                if (!_pinHoverWired)
                {
                    _pinHoverWired = true;
                    _pinBtn.MouseEnter += delegate
                    {
                        if (_data.Settings.Topmost)
                        {
                            Color a = ColorUtil.Parse(_data.Settings.Accent, Colors.White);
                            _pinBtn.Background = new SolidColorBrush(Color.FromArgb(96, a.R, a.G, a.B));
                        }
                        else _pinBtn.Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255));
                    };
                    _pinBtn.MouseLeave += delegate
                    {
                        if (_data.Settings.Topmost)
                        {
                            Color a = ColorUtil.Parse(_data.Settings.Accent, Colors.White);
                            _pinBtn.Background = new SolidColorBrush(Color.FromArgb(52, a.R, a.G, a.B));
                        }
                        else _pinBtn.Background = Brushes.Transparent;
                    };
                }
            }
        }

        // ================= 自动月报 =================
        void CheckMonthlyReport()
        {
            DateTime now = DateTime.Now;
            if (!Monthly.IsThirdMonday(now)) return;
            if (now.Hour < 10) return;
            if (now.Hour == 10 && now.Minute < 30) return;
            string key = now.ToString("yyyy-MM");
            if (_data.Settings.LastMonthlyReport == key) return; // 本月已生成
            RunMonthlyReportNow(now);
        }

        public void RunMonthlyReportNow(DateTime now)
        {
            int pending;
            string text = Monthly.Generate(_data, now, out pending);
            string path = Monthly.WriteReport(_dataDir, now, text);
            _data.Settings.LastMonthlyReport = now.ToString("yyyy-MM");
            SaveNow();
            RefreshAll();
            if (_tray != null)
            {
                try
                {
                    _tray.ShowBalloonTip(6000, "月度总结已生成",
                        (pending > 0 ? pending + " 项今天及以前的未完成日程待处理。" : "本月没有待处理的过期日程。")
                        + "\r\n" + path,
                        System.Windows.Forms.ToolTipIcon.Info);
                }
                catch { }
            }
            Flash("月度总结已生成：" + path);
            ShowReportLink(path);
            if (pending > 0) ShowMonthlyFollowup(now.Date);
        }

        // 月报生成后询问：一键回撤 / 一键顺延 / 否（默认否，绝不自动改动日程）
        void ShowMonthlyFollowup(DateTime today)
        {
            DateTime target = Monthly.NextWorkday(today);
            int count = CountUnfinishedUpTo(today);
            if (count <= 0) return;
            string choice = Dialogs.AskMonthlyAction(this, count, target);
            if (choice == "revert")
            {
                int n = RevertUnfinishedToTodos(today);
                RefreshAll();
                SaveSoon();
                Flash("已一键回撤 " + n + " 项到今天及以前的待办");
            }
            else if (choice == "defer")
            {
                int n = DeferUnfinishedTo(today, target);
                RefreshAll();
                SaveSoon();
                Flash("已一键顺延 " + n + " 项到 " + target.ToString("M月d日") + "（统一，不逐项后移）");
            }
        }

        int CountUnfinishedUpTo(DateTime today)
        {
            int n = 0;
            today = today.Date;
            foreach (KeyValuePair<string, List<ScheduleItem>> kv in _data.Schedules)
            {
                DateTime dt;
                if (!DateTime.TryParseExact(kv.Key, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture,
                        System.Globalization.DateTimeStyles.None, out dt)) continue;
                if (dt > today) continue;
                for (int i = 0; i < kv.Value.Count; i++)
                    if (kv.Value[i] != null && !kv.Value[i].Done) n++;
            }
            return n;
        }

        // 一键回撤：今天及以前所有未完成日程 -> 待办（保留分类、颜色、时间与完成状态）
        int RevertUnfinishedToTodos(DateTime today)
        {
            today = today.Date;
            List<string> keys = new List<string>();
            foreach (KeyValuePair<string, List<ScheduleItem>> kv in _data.Schedules)
            {
                DateTime dt;
                if (!DateTime.TryParseExact(kv.Key, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture,
                        System.Globalization.DateTimeStyles.None, out dt)) continue;
                if (dt <= today) keys.Add(kv.Key);
            }
            keys.Sort(StringComparer.Ordinal);
            int n = 0;
            for (int k = 0; k < keys.Count; k++)
            {
                string key = keys[k];
                List<ScheduleItem> list = _data.Schedules[key];
                List<ScheduleItem> rest = new List<ScheduleItem>();
                for (int i = 0; i < list.Count; i++)
                {
                    ScheduleItem it = list[i];
                    if (it == null) continue;
                    if (it.Done) { rest.Add(it); continue; }
                    TodoItem t = new TodoItem();
                    t.Id = Guid.NewGuid().ToString("N");
                    t.Text = it.Text;
                    t.Done = it.Done;
                    t.Category = it.Category;
                    t.CustomColor = it.CustomColor;
                    t.Date = key;
                    t.Time = it.Time;
                    t.EndTime = it.EndTime;
                    _data.Todos.Add(t);
                    n++;
                }
                list.Clear();
                for (int i = 0; i < rest.Count; i++) list.Add(rest[i]);
            }
            return n;
        }

        // 一键顺延：今天及以前所有未完成日程统一移到今天之后的第一个工作日（不逐项后移）
        int DeferUnfinishedTo(DateTime today, DateTime target)
        {
            today = today.Date;
            List<KeyValuePair<string, ScheduleItem>> move = new List<KeyValuePair<string, ScheduleItem>>();
            foreach (KeyValuePair<string, List<ScheduleItem>> kv in _data.Schedules)
            {
                DateTime dt;
                if (!DateTime.TryParseExact(kv.Key, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture,
                        System.Globalization.DateTimeStyles.None, out dt)) continue;
                if (dt > today) continue;
                for (int i = 0; i < kv.Value.Count; i++)
                {
                    ScheduleItem it = kv.Value[i];
                    if (it != null && !it.Done) move.Add(new KeyValuePair<string, ScheduleItem>(kv.Key, it));
                }
            }
            move.Sort(delegate(KeyValuePair<string, ScheduleItem> a, KeyValuePair<string, ScheduleItem> b)
            {
                int c = string.CompareOrdinal(a.Key, b.Key);
                if (c != 0) return c;
                return string.CompareOrdinal(a.Value.Time, b.Value.Time);
            });
            List<ScheduleItem> targetList = _data.DaySchedules(target);
            for (int i = 0; i < move.Count; i++)
            {
                List<ScheduleItem> oldList;
                if (_data.Schedules.TryGetValue(move[i].Key, out oldList)) oldList.Remove(move[i].Value);
                targetList.Add(move[i].Value);
            }
            return move.Count;
        }

        // ================= 保存 =================
        public void SaveSoon() { _saveTimer.Stop(); _saveTimer.Start(); }

        public void SaveNow()
        {
            AppSettings s = _data.Settings;
            Rect b = _docked ? _fullBounds : new Rect(Left, Top, Width, Height);
            if (_compact) b = _normalBounds;
            s.Left = b.X;
            s.Top = b.Y;
            s.Width = b.Width;
            s.Height = b.Height;
            s.CalendarWidth = _monthCalW;
            DataStore.Save(_dataDir, _data);
        }

        // 状态提示：月/日视图显示在日程栏标题下方；周视图（无该行·待办主体）显示在底部目标日期标签上
        void Flash(string msg)
        {
            _statusTimer.Stop();
            if (_statusLine != null) { _statusLine.Inlines.Clear(); _statusLine.Text = msg; }
            else if (_weekTargetLbl != null) _weekTargetLbl.Text = msg;
            _statusTimer.Start();
        }

        // 月报地址提示：可点击的超链接（打开所在文件夹），停留 5 秒后自动隐藏
        DispatcherTimer _reportTimer;
        void ShowReportLink(string path)
        {
            if (_statusLine == null) return;
            _statusTimer.Stop();
            _statusLine.Inlines.Clear();
            Hyperlink link = new Hyperlink(new Run("月报已生成：" + System.IO.Path.GetFileName(path) + "（点击打开文件夹）"));
            link.Foreground = ColorUtil.Brush(_data.Settings.Accent);
            link.TextDecorations = TextDecorations.Underline;
            string folder = System.IO.Path.GetDirectoryName(path);
            link.Click += delegate
            {
                try { System.Diagnostics.Process.Start("explorer.exe", "\"" + folder + "\""); } catch { }
            };
            _statusLine.Inlines.Add(link);
            if (_reportTimer != null) _reportTimer.Stop();
            _reportTimer = new DispatcherTimer();
            _reportTimer.Interval = TimeSpan.FromSeconds(5);
            _reportTimer.Tick += delegate
            {
                _reportTimer.Stop();
                if (_statusLine != null) { _statusLine.Inlines.Clear(); _statusLine.Text = ""; }
            };
            _reportTimer.Start();
        }

        // 供托盘回调
        public void ShowMain()
        {
            try
            {
                Show();
                if (WindowState == WindowState.Minimized) WindowState = WindowState.Normal;
                Activate();
            }
            catch (InvalidOperationException)
            {
                // 窗口已关闭（进程退出中）时忽略，避免双击残留托盘图标时报错
            }
        }

        public void ExitApp()
        {
            _closingByExit = true;
            // 必须显式 Shutdown：ShutdownMode=OnExplicitShutdown 下仅 Close() 窗口不会结束进程，
            // 会导致进程/托盘图标残留、单实例互斥锁不释放（再次双击 exe 无反应）。
            Application.Current.Shutdown();
        }
    }
}
