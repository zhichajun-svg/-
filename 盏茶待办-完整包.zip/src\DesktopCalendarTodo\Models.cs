using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows.Media;

namespace DesktopCalendarTodo
{
    // 分类定义：名称稳定存储，颜色一致；重要/紧急加粗。
    public static class Cats
    {
        public static readonly string[] Names = { "日常", "重要", "紧急", "工作", "生活", "自定义颜色" };

        static readonly string[] DefaultColors = {
            "#6B7280", // 日常 灰蓝
            "#F59E0B", // 重要 琥珀
            "#EF4444", // 紧急 红
            "#3B82F6", // 工作 蓝
            "#10B981", // 生活 绿
            "#8B5CF6"  // 自定义颜色默认 紫
        };

        public static string DefaultColor(string cat)
        {
            // 自定义/被改过颜色的分类优先（默认分类也能改色）
            string cc;
            if (CustomColors != null && CustomColors.TryGetValue(cat, out cc) && !string.IsNullOrEmpty(cc)) return cc;
            for (int i = 0; i < Names.Length; i++)
                if (Names[i] == cat) return DefaultColors[i];
            return "#8B5CF6";
        }

        // 用户自定义分类 -> 颜色（启动时从 settings.categoryColors 载入）
        public static Dictionary<string, string> CustomColors = new Dictionary<string, string>();

        public static void SetCustomColors(Dictionary<string, string> map)
        {
            CustomColors = map ?? new Dictionary<string, string>();
        }

        public static bool IsBold(string cat)
        {
            return cat == "重要" || cat == "紧急";
        }

        // 返回该项显示颜色（自定义取用户色）
        public static string ColorOf(string cat, string customColor)
        {
            if (cat == "自定义颜色" && !string.IsNullOrEmpty(customColor)) return customColor;
            return DefaultColor(cat);
        }
    }

    public class SubtaskItem
    {
        public string Id;
        public string Text;
        public bool Done;

        public SubtaskItem() { }
        public SubtaskItem(string id, string text)
        {
            Id = id;
            Text = text;
            Done = false;
        }

        // 深拷贝子任务列表（回撤/复制/安排时保留子任务，避免共享引用）
        public static List<SubtaskItem> CloneAll(List<SubtaskItem> src)
        {
            List<SubtaskItem> r = new List<SubtaskItem>();
            if (src == null) return r;
            for (int i = 0; i < src.Count; i++)
                r.Add(new SubtaskItem(src[i].Id, src[i].Text) { Done = src[i].Done });
            return r;
        }
    }

    public class ScheduleItem
    {
        public string Id;
        public string Text;
        public string Time;       // "HH:mm" 或空（开始时间）
        public string EndTime;    // "HH:mm" 或空（结束时间，显示为 开始-结束）
        public bool Done;
        public string Category;   // 中文分类名
        public string CustomColor;
        public List<SubtaskItem> Subtasks;

        public ScheduleItem()
        {
            Subtasks = new List<SubtaskItem>();
            EndTime = "";
        }

        public string Color { get { return Cats.ColorOf(Category, CustomColor); } }
        public bool Bold { get { return Cats.IsBold(Category); } }

        public ScheduleItem Clone()
        {
            ScheduleItem c = new ScheduleItem();
            c.Id = Id;
            c.Text = Text;
            c.Time = Time;
            c.EndTime = EndTime;
            c.Done = Done;
            c.Category = Category;
            c.CustomColor = CustomColor;
            c.Subtasks = new List<SubtaskItem>();
            for (int i = 0; i < Subtasks.Count; i++)
            {
                SubtaskItem s = Subtasks[i];
                c.Subtasks.Add(new SubtaskItem(s.Id, s.Text) { Done = s.Done });
            }
            return c;
        }
    }

    public class TodoItem
    {
        public string Id;
        public string Text;
        public bool Done;
        public string Category;
        public string CustomColor;
        public string Date = "";     // 回撤自日程时保留的原日程日期 "yyyy-MM-dd"；普通待办为空
        public string Time = "";     // 回撤自日程时保留的开始时间 "HH:mm"
        public string EndTime = "";  // 回撤自日程时保留的结束时间 "HH:mm"
        public List<SubtaskItem> Subtasks = new List<SubtaskItem>(); // 回撤自日程时一并保留的子任务

        public string Color { get { return Cats.ColorOf(Category, CustomColor); } }
        public bool Bold { get { return Cats.IsBold(Category); } }
    }

    public class AppSettings
    {
        public double Left = -1;
        public double Top = -1;
        public double Width = 1120;
        public double Height = 720;
        public double DayLeft = -1;   // 日视图窗口位置（-1 表示未记录，首次切日视图自动贴右）
        public double DayTop = -1;
        public double DayWidth = 0;   // 日视图窗口尺寸（0 表示用月历栏宽度）
        public double DayHeight = 0;
        public double ScheduleWidth = 400;
        public double TodoWidth = 330;
        public double CalendarWidth = 342; // 月视图日历栏最近一次实际宽度（日视图默认尺寸基准）
        public string Background = "#E6191A22"; // AARRGGBB
        public string Accent = "#4F8CFF";
        public double Opacity = 0.95;
        public bool Topmost = false;
        public bool EdgeDock = true;
        public string LastMonthlyReport = ""; // 已生成月报的月份键 "yyyy-MM"，防止重复触发
        public string DividerStyle = "dash";  // 竖向分隔线样式：solid/dash/double/star/dot
        public string ViewMode = "month";     // 窗口样式：month（月视图）/ week（周视图）/ day（日视图）
        public List<string> Categories = new List<string>(); // 用户自定义事项分类
        public List<string> DeletedCategories = new List<string>(); // 已删除的分类名（含默认分类），不再出现在选择列表
        public Dictionary<string, string> CategoryColors = new Dictionary<string, string>(); // 自定义分类 -> 颜色
        public List<string> BgHistory = new List<string>();     // 背景色自定义历史（新→旧）
        public List<string> AccentHistory = new List<string>(); // 强调色自定义历史（新→旧）
        public List<string> Skins = new List<string>();         // 我的皮肤：name|bg|accent|opacity|divider，最多 3 个
        public double MonthWidth = 1120;   // 月视图窗口尺寸（各视图独立记忆）
        public double MonthHeight = 720;
        public double WeekWidth = 1200;
        public double WeekHeight = 720;
    }

    public class PlannerData
    {
        public int Version = 2;
        public Dictionary<string, List<ScheduleItem>> Schedules; // key "yyyy-MM-dd"
        public List<TodoItem> Todos;
        public JVal LegacyNotes;   // 旧版便签原始数据，原样保留，界面不显示
        public string NotesTitle = ""; // 备忘录标题
        public string NotesBody = "";  // 备忘录正文
        public string NotesBodyRtf = ""; // 备忘录正文富文本（RTF），为空时用 NotesBody 纯文本
        public AppSettings Settings;

        public PlannerData()
        {
            Schedules = new Dictionary<string, List<ScheduleItem>>();
            Todos = new List<TodoItem>();
            Settings = new AppSettings();
        }

        public List<ScheduleItem> DaySchedules(DateTime day)
        {
            string key = day.ToString("yyyy-MM-dd");
            List<ScheduleItem> list;
            if (!Schedules.TryGetValue(key, out list))
            {
                list = new List<ScheduleItem>();
                Schedules[key] = list;
            }
            return list;
        }
    }

    // 待办“安排”弹窗的结果：开始/结束/重复，全部为纯逻辑，可被自检测试。
    public class ArrangePlan
    {
        public const string RNone = "none";
        public const string RDay = "day";
        public const string RWeek = "week";
        public const string RMonth = "month";
        public const string RYear = "year";
        public const string RLunarYear = "lunaryear";

        public DateTime StartDate;
        public string StartTime = "";   // "HH:mm" 或空
        public string EndTime = "";     // "HH:mm" 或空（仅展示参考）
        public DateTime EndDate;        // 结束日期（重复时的截止；<=StartDate 表示不设截止）
        public string RepeatType = RNone;
        public int RepeatCount = 1;     // 总发生次数；0 = 不限次数

        public string RepeatLabel
        {
            get
            {
                switch (RepeatType)
                {
                    case RDay: return "每天";
                    case RWeek: return "每周";
                    case RMonth: return "每月";
                    case RYear: return "每年";
                    case RLunarYear: return "农历每年";
                    default: return "不重复";
                }
            }
        }

        // 按开始/结束/重复规则展开所有发生日期（含开始日期本身）。
        public List<DateTime> GenerateDates()
        {
            List<DateTime> list = new List<DateTime>();
            DateTime start = StartDate.Date;
            list.Add(start);
            if (RepeatType == RNone) return list;

            bool capByCount = RepeatCount > 0;
            bool capByEnd = EndDate.Date > start;
            DateTime cur = start;
            int n = 1;
            while (true)
            {
                if (capByCount && n >= RepeatCount) break;
                DateTime next;
                if (!TryStep(cur, out next)) break; // 该周期没有下一个（如某闰月不存在的年份已超出范围）
                if (capByEnd && next > EndDate.Date) break;
                cur = next;
                list.Add(cur);
                n++;
                if (list.Count > 10000) break; // 防御性上限
            }
            return list;
        }

        bool TryStep(DateTime from, out DateTime next)
        {
            next = from;
            switch (RepeatType)
            {
                case RDay:
                    next = from.AddDays(1);
                    return true;
                case RWeek:
                    next = from.AddDays(7);
                    return true;
                case RMonth:
                    next = from.AddMonths(1);
                    return true;
                case RYear:
                    next = from.AddYears(1);
                    return true;
                case RLunarYear:
                    // 同一农历月日，跳到下一年（闰月不存在的年份自动顺延到下一可用年）
                    LunarDate lu = Lunar.FromSolar(from);
                    for (int y = lu.Year + 1; y <= 2100; y++)
                    {
                        DateTime? dt = Lunar.LunarToSolar(y, lu.Month, lu.Day, lu.IsLeap);
                        if (dt.HasValue) { next = dt.Value; return true; }
                    }
                    return false;
                default:
                    return false;
            }
        }
    }

    public static class ColorUtil
    {
        // 解析 #RRGGBB 或 #AARRGGBB；失败返回 fallback
        public static Color Parse(string hex, Color fallback)
        {
            try
            {
                if (string.IsNullOrEmpty(hex)) return fallback;
                string h = hex.Trim();
                if (h[0] == '#') h = h.Substring(1);
                if (h.Length == 6) h = "FF" + h;
                if (h.Length != 8) return fallback;
                uint v = uint.Parse(h, NumberStyles.HexNumber, CultureInfo.InvariantCulture);
                return Color.FromArgb((byte)(v >> 24), (byte)(v >> 16), (byte)(v >> 8), (byte)v);
            }
            catch { return fallback; }
        }

        public static string ToHex(Color c)
        {
            return "#" + c.A.ToString("x2") + c.R.ToString("x2") + c.G.ToString("x2") + c.B.ToString("x2");
        }

        public static SolidColorBrush Brush(string hex, double opacity = 1.0)
        {
            Color c = Parse(hex, Color.FromArgb(255, 0, 0, 0));
            c = Color.FromArgb((byte)Math.Max(0, Math.Min(255, (int)(c.A * opacity))), c.R, c.G, c.B);
            return new SolidColorBrush(c);
        }

        // 生成 12 色可选调色板（分类自定义/强调色共用）
        public static string[] Palette = {
            "#4F8CFF", "#2DD4BF", "#8B5CF6", "#EC4899", "#F97316", "#EF4444",
            "#22C55E", "#F59E0B", "#0EA5E9", "#14B8A6", "#A78BFA", "#F472B6"
        };

        // 背景深色预设
        public static string[] BgPresets = {
            "#E6191A22", "#E6222429", "#E6171F26", "#E6232020", "#E6142420", "#E61E1B28",
            "#EA141414", "#E61A202B"
        };
    }
}
