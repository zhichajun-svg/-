using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;

namespace DesktopCalendarTodo
{
    // 顺延与自动月报总结的核心逻辑（无界面依赖，可被自检/CLI/界面共用）
    public static class Monthly
    {
        // 下一个工作日：跳过周六、周日。离线实现，不识别法定节假日。
        public static DateTime NextWorkday(DateTime d)
        {
            DateTime n = d.AddDays(1);
            while (n.DayOfWeek == DayOfWeek.Saturday || n.DayOfWeek == DayOfWeek.Sunday)
                n = n.AddDays(1);
            return n;
        }

        // 是否当月第 3 个周一（触发月报的日期）
        public static bool IsThirdMonday(DateTime d)
        {
            if (d.DayOfWeek != DayOfWeek.Monday) return false;
            int mondays = 0;
            for (int day = 1; day <= d.Day; day++)
            {
                if (new DateTime(d.Year, d.Month, day).DayOfWeek == DayOfWeek.Monday)
                    mondays++;
            }
            return mondays == 3;
        }

        // 报告文件路径：{dataDir}\月度总结-{yyyy-MM}.txt
        public static string ReportPath(string dataDir, DateTime now)
        {
            return Path.Combine(dataDir, "月度总结-" + now.ToString("yyyy-MM") + ".txt");
        }

        // 分类紧急程度：紧急 > 重要 > 工作 > 生活 > 日常 > 自定义/其它（月报排序用）
        public static int CategoryRank(string cat)
        {
            if (cat == "紧急") return 0;
            if (cat == "重要") return 1;
            if (cat == "工作") return 2;
            if (cat == "生活") return 3;
            if (cat == "日常") return 4;
            return 5;
        }

        // 生成月度总结文本。本方法只读数据、绝不改动日程：
        //   1) 汇总当月（now 所在月份）全部日程；
        //   2) 已完成事项按日期/时间列出；
        //   3) 未完成且原定日期 <= 今天的单列，供生成后的弹窗选择“一键回撤 / 一键顺延 / 否”；
        //   4) 未完成但日期在今天之后的事项按原日期继续跟踪。
        // pendingPastCount 输出“今天及以前未完成”的条数（弹窗依据）。
        public static string Generate(PlannerData data, DateTime now, out int pendingPastCount)
        {
            DateTime today = now.Date;
            DateTime monthStart = new DateTime(now.Year, now.Month, 1);
            DateTime monthEnd = monthStart.AddMonths(1).AddDays(-1);

            List<ScheduleItem> done = new List<ScheduleItem>();
            List<KeyValuePair<DateTime, ScheduleItem>> pendingPast = new List<KeyValuePair<DateTime, ScheduleItem>>();
            List<KeyValuePair<DateTime, ScheduleItem>> pendingFuture = new List<KeyValuePair<DateTime, ScheduleItem>>();

            foreach (KeyValuePair<string, List<ScheduleItem>> kv in data.Schedules)
            {
                DateTime dt;
                if (!DateTime.TryParseExact(kv.Key, "yyyy-MM-dd", CultureInfo.InvariantCulture,
                        DateTimeStyles.None, out dt)) continue;
                if (dt < monthStart || dt > monthEnd) continue;
                for (int i = 0; i < kv.Value.Count; i++)
                {
                    ScheduleItem it = kv.Value[i];
                    if (it == null) continue;
                    if (it.Done) done.Add(it);
                    else if (dt <= today) pendingPast.Add(new KeyValuePair<DateTime, ScheduleItem>(dt, it));
                    else pendingFuture.Add(new KeyValuePair<DateTime, ScheduleItem>(dt, it));
                }
            }

            pendingPastCount = pendingPast.Count;

            // 排序：按分类紧急程度优先（紧急 > 重要 > 工作 > 生活 > 日常 > 其它），同级再按日期/时间
            done.Sort(delegate(ScheduleItem a, ScheduleItem b)
            {
                int r = CategoryRank(a.Category).CompareTo(CategoryRank(b.Category));
                if (r != 0) return r;
                DateTime da = FindDate(data, a);
                DateTime db = FindDate(data, b);
                int c = da.CompareTo(db);
                if (c != 0) return c;
                return string.CompareOrdinal(a.Time, b.Time);
            });
            pendingPast.Sort(delegate(KeyValuePair<DateTime, ScheduleItem> a, KeyValuePair<DateTime, ScheduleItem> b)
            {
                int r = CategoryRank(a.Value.Category).CompareTo(CategoryRank(b.Value.Category));
                if (r != 0) return r;
                int c = a.Key.CompareTo(b.Key);
                if (c != 0) return c;
                return string.CompareOrdinal(a.Value.Time, b.Value.Time);
            });
            pendingFuture.Sort(delegate(KeyValuePair<DateTime, ScheduleItem> a, KeyValuePair<DateTime, ScheduleItem> b)
            {
                int r = CategoryRank(a.Value.Category).CompareTo(CategoryRank(b.Value.Category));
                if (r != 0) return r;
                int c = a.Key.CompareTo(b.Key);
                if (c != 0) return c;
                return string.CompareOrdinal(a.Value.Time, b.Value.Time);
            });

            DateTime target = NextWorkday(today);
            StringBuilder sb = new StringBuilder();
            sb.Append(now.Year).Append("年").Append(now.Month).Append("月 月度总结\r\n");
            sb.Append("生成时间：").Append(now.ToString("yyyy-MM-dd HH:mm")).Append("\r\n");
            sb.Append("（本报告不自动改动日程；生成后可选择一键回撤、一键顺延或否）\r\n");
            sb.Append("\r\n");

            sb.Append("一、已完成事项（共 ").Append(done.Count).Append(" 项）\r\n");
            if (done.Count == 0) sb.Append("（本月暂无已完成事项）\r\n");
            for (int i = 0; i < done.Count; i++)
            {
                ScheduleItem it = done[i];
                DateTime dt = FindDate(data, it);
                sb.Append("• ").Append(it.Text)
                    .Append(string.IsNullOrEmpty(it.Category) ? "" : "〔" + it.Category + "〕")
                    .Append("（").Append(dt.ToString("M月d日"))
                    .Append(it.Time.Length > 0 ? " " + it.Time : "").Append("）\r\n");
            }
            sb.Append("\r\n");

            sb.Append("二、未完成 / 进行中事项（共 ").Append(pendingPast.Count + pendingFuture.Count).Append(" 项）\r\n");
            sb.Append("其中今天及以前 ").Append(pendingPast.Count).Append(" 项：\r\n");
            if (pendingPast.Count == 0) sb.Append("（无）\r\n");
            for (int i = 0; i < pendingPast.Count; i++)
            {
                sb.Append("• ").Append(pendingPast[i].Value.Text)
                    .Append(string.IsNullOrEmpty(pendingPast[i].Value.Category) ? "" : "〔" + pendingPast[i].Value.Category + "〕")
                    .Append("（")
                    .Append(pendingPast[i].Key.ToString("M月d日"))
                    .Append(pendingPast[i].Value.Time.Length > 0 ? " " + pendingPast[i].Value.Time : "")
                    .Append("）\r\n");
            }
            if (pendingFuture.Count > 0)
            {
                sb.Append("其余 ").Append(pendingFuture.Count).Append(" 项原定日期在今日之后，按原日期继续跟踪：\r\n");
                for (int i = 0; i < pendingFuture.Count; i++)
                {
                    sb.Append("• ").Append(pendingFuture[i].Value.Text)
                        .Append(string.IsNullOrEmpty(pendingFuture[i].Value.Category) ? "" : "〔" + pendingFuture[i].Value.Category + "〕")
                        .Append("（")
                        .Append(pendingFuture[i].Key.ToString("M月d日"))
                        .Append(pendingFuture[i].Value.Time.Length > 0 ? " " + pendingFuture[i].Value.Time : "")
                        .Append("）\r\n");
                }
            }
            sb.Append("\r\n");

            sb.Append("说明：一键顺延统一移到今天之后的第一个工作日（").Append(target.ToString("M月d日 dddd"))
                .Append("），不是逐项往后挪；一键回撤则移回待办箱；离线版不识别法定节假日。\r\n");
            sb.Append("事项可在「盏茶待办」中继续修改；数据保存在 planner-data.json。\r\n");
            return sb.ToString();
        }

        // 依据当前数据定位某事项所在日期（报告排序用）
        static DateTime FindDate(PlannerData data, ScheduleItem it)
        {
            foreach (KeyValuePair<string, List<ScheduleItem>> kv in data.Schedules)
            {
                for (int i = 0; i < kv.Value.Count; i++)
                    if (kv.Value[i] == it)
                    {
                        DateTime dt;
                        if (DateTime.TryParseExact(kv.Key, "yyyy-MM-dd", CultureInfo.InvariantCulture,
                                DateTimeStyles.None, out dt)) return dt;
                    }
            }
            return DateTime.MaxValue;
        }

        // 写报告文件（UTF-8 带 BOM，便于记事本/Excel 识别），返回路径
        public static string WriteReport(string dataDir, DateTime now, string text)
        {
            try
            {
                if (!Directory.Exists(dataDir)) Directory.CreateDirectory(dataDir);
                string path = ReportPath(dataDir, now);
                File.WriteAllText(path, text, new UTF8Encoding(true));
                return path;
            }
            catch { return ""; }
        }
    }
}
