using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace DesktopCalendarTodo
{
    // 备忘录界面：白底纸面 + 标题（方正小标宋_GBK 二号）+ 正文（方正仿宋_GBK 三号），
    // 界面内只有文本框；右下角可导出白底 PNG 或打开打印菜单。
    // 参考长便签类应用：单篇长文、纸张式排版、专注输入。
    public partial class MainWindow
    {
        const double NotesTitleSize = 29.33; // 二号 = 22pt
        const double NotesBodySize = 21.33;  // 三号 = 16pt
        // A4（210×297mm）：按 96 DPI 换算成 DIP，导出时以 300 DPI 渲染
        const double A4WidthDip = 210.0 / 25.4 * 96.0;
        const double A4HeightDip = 297.0 / 25.4 * 96.0;
        const double A4ExportDpi = 300.0;
        bool _notesMode;
        TextBox _notesTitleBox;
        RichTextBox _notesRtb;
        Border _notesPaper;

        static FontFamily NotesTitleFont()
        {
            // 未安装方正字体时自动回退到宋体/微软雅黑
            return new FontFamily("方正小标宋_GBK, 宋体, Microsoft YaHei UI");
        }

        static FontFamily NotesBodyFont()
        {
            return new FontFamily("方正仿宋_GBK, 仿宋, Microsoft YaHei UI");
        }

        // 强调色半透明圆角小标签（与日视图分类下拉同款）
        Border MakeModePill(string label, string tip, string autoId, Action onClick)
        {
            Color acc = ColorUtil.Parse(_data.Settings.Accent, Color.FromArgb(255, 79, 140, 255));
            Border pill = new Border();
            pill.CornerRadius = new CornerRadius(8);
            pill.Background = new SolidColorBrush(Color.FromArgb(64, acc.R, acc.G, acc.B));
            pill.BorderBrush = new SolidColorBrush(Color.FromArgb(150, acc.R, acc.G, acc.B));
            pill.BorderThickness = new Thickness(1);
            pill.Padding = new Thickness(10, 3, 10, 3);
            pill.Cursor = Cursors.Hand;
            pill.ToolTip = tip;
            TextBlock lbl = Ui.Lbl(label + " ▾", 11, Colors.White, true);
            lbl.VerticalAlignment = VerticalAlignment.Center;
            AutomationProperties.SetName(lbl, autoId);
            pill.Child = lbl;
            pill.MouseLeftButtonUp += delegate { onClick(); };
            return pill;
        }

        // 右上角按钮：直接切换 待办 / 备忘录，按钮文字显示当前界面
        void ToggleNotes()
        {
            _notesMode = !_notesMode;
            RebuildBody();
            RefreshAll();
            Flash(_notesMode ? "已切换：备忘录" : "已切换：待办");
        }

        // 备忘录面板：withHeader=true 时带“备忘录 + 待办▾”头部（月/周待办栏），false 时用于日视图主体
        Border BuildNotesPanel(bool withHeader)
        {
            Border panel = new Border();
            panel.Padding = new Thickness(12, 10, 12, 10);

            Grid g = new Grid();
            if (withHeader)
            {
                g.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
                Grid hdr = new Grid();
                hdr.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1, GridUnitType.Star) });
                hdr.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
                TextBlock h = Ui.Lbl("备忘录", 16, Colors.White, true);
                h.VerticalAlignment = VerticalAlignment.Center;
                Grid.SetColumn(h, 0);
                hdr.Children.Add(h);
                Border pillRef = null;
                Border pill = MakeModePill("备忘录", "事项分类：全部 / 待办 / 备忘录 / 分类", "TodoModePill", delegate
                {
                    ShowCatPicker(pillRef);
                });
                pillRef = pill;
                pill.Tag = "nodrag";
                pill.VerticalAlignment = VerticalAlignment.Center;
                Grid.SetColumn(pill, 1);
                hdr.Children.Add(pill);
                Grid.SetRow(hdr, 0);
                g.Children.Add(hdr);
            }
            g.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1, GridUnitType.Star) });
            g.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });

            // 白纸
            Border paper = new Border();
            paper.Background = Brushes.Transparent; // 输入界面底色与设置背景色一致（仅导出图片是白底）
            paper.CornerRadius = new CornerRadius(6);
            paper.BorderBrush = new SolidColorBrush(Color.FromArgb(40, 255, 255, 255));
            paper.BorderThickness = new Thickness(1);
            paper.Padding = new Thickness(24, 20, 24, 18);
            paper.Margin = new Thickness(0, 10, 0, 0);
            paper.ClipToBounds = true;
            Grid pg = new Grid();
            pg.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto }); // 工具条
            pg.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto }); // 标题
            pg.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1, GridUnitType.Star) }); // 正文

            _notesTitleBox = new TextBox();
            _notesTitleBox.Text = _data.NotesTitle;
            _notesTitleBox.FontFamily = NotesTitleFont();
            _notesTitleBox.FontSize = NotesTitleSize;
            _notesTitleBox.Foreground = new SolidColorBrush(Color.FromArgb(245, 255, 255, 255));
            _notesTitleBox.Background = Brushes.Transparent;
            _notesTitleBox.BorderThickness = new Thickness(0);
            _notesTitleBox.Padding = new Thickness(0, 0, 0, 6);
            _notesTitleBox.TextAlignment = TextAlignment.Center;
            _notesTitleBox.TextWrapping = TextWrapping.Wrap;
            _notesTitleBox.CaretBrush = Brushes.White;
            AutomationProperties.SetName(_notesTitleBox, "NotesTitle_box");
            _notesTitleBox.TextChanged += delegate { _data.NotesTitle = _notesTitleBox.Text; SaveSoon(); };
            Grid.SetRow(_notesTitleBox, 1);
            pg.Children.Add(_notesTitleBox);

            // 富文本工具条（圆形 icon）：字体 / 字号 / 加粗 / 倾斜 / 下划线 / 高亮，均作用于选中文字
            WrapPanel nbar = new WrapPanel() { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 0, 0, 4) };
            Border fontBtn = NoteBarIcon("字", "字体（加载本机字体）", delegate { });
            fontBtn.MouseLeftButtonUp += delegate { NotesPickFontWithState(fontBtn); };
            AutomationProperties.SetName(fontBtn, "NotesFontIcon");
            nbar.Children.Add(fontBtn);
            nbar.Children.Add(NoteBarIcon("A-", "减小字号", delegate { NotesStepSize(-1); }));
            nbar.Children.Add(NoteBarIcon("A+", "增大字号", delegate { NotesStepSize(1); }));
            nbar.Children.Add(NoteBarIcon("B", "加粗", delegate { NotesToggleBold(); }));
            nbar.Children.Add(NoteBarIcon("I", "倾斜", delegate { NotesToggleItalic(); }));
            nbar.Children.Add(NoteBarIcon("U", "下划线", delegate { NotesToggleUnderline(); }));
            nbar.Children.Add(NoteBarIcon("高", "高亮", delegate { NotesToggleHighlight(); }));
            Border brushBtn = NoteBarIcon("刷", "格式刷：先选中文字再点；单击刷一次，长按 1 秒进入连续刷，再点退出", delegate { });
            // 长按 1 秒进入连续刷；短按为单击（刷一次 / 退出）
            System.Windows.Threading.DispatcherTimer holdTimer = null;
            bool holdFired = false;
            brushBtn.MouseLeftButtonDown += delegate(object s2, MouseButtonEventArgs e2)
            {
                holdFired = false;
                if (holdTimer != null) holdTimer.Stop();
                holdTimer = new System.Windows.Threading.DispatcherTimer();
                holdTimer.Interval = TimeSpan.FromSeconds(1);
                holdTimer.Tick += delegate
                {
                    holdTimer.Stop();
                    holdFired = true;
                    if (!_fmtSticky) NotesToggleFormatBrush(true); // 进入连续刷
                };
                holdTimer.Start();
            };
            brushBtn.MouseLeftButtonUp += delegate(object s2, MouseButtonEventArgs e2)
            {
                if (holdTimer != null) { holdTimer.Stop(); holdTimer = null; }
                if (holdFired) return; // 长按已处理
                NotesToggleFormatBrush(false);
            };
            brushBtn.MouseLeave += delegate
            {
                if (holdTimer != null) { holdTimer.Stop(); holdTimer = null; }
            };
            AutomationProperties.SetName(brushBtn, "NotesFormatBrush");
            _brushIcon = brushBtn;
            nbar.Children.Add(brushBtn);
            Grid.SetRow(nbar, 0);
            pg.Children.Add(nbar);

            _notesRtb = new RichTextBox();
            _notesRtb.FontFamily = NotesBodyFont();
            _notesRtb.FontSize = NotesBodySize;
            _notesRtb.Foreground = new SolidColorBrush(Color.FromArgb(238, 255, 255, 255));
            _notesRtb.Background = Brushes.Transparent;
            _notesRtb.BorderThickness = new Thickness(0);
            _notesRtb.Padding = new Thickness(0);
            _notesRtb.Margin = new Thickness(0, 8, 0, 0);
            _notesRtb.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
            _notesRtb.CaretBrush = Brushes.White;
            AutomationProperties.SetName(_notesRtb, "NotesBody_box");
            LoadNotesDocument();
            _notesRtb.TextChanged += delegate { SyncNotesDocument(); };
            _notesRtb.SelectionChanged += delegate { NotesOnSelectionChanged(); };
            Grid.SetRow(_notesRtb, 2);
            pg.Children.Add(_notesRtb);

            paper.Child = pg;
            _notesPaper = paper;
            Grid.SetRow(paper, g.RowDefinitions.Count - 2);
            g.Children.Add(paper);

            // 右下角：导出图片 / 打印
            StackPanel btns = new StackPanel() { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
            btns.Margin = new Thickness(0, 8, 0, 0);
            Button exp = Ui.SmallButton("导出图片", "把备忘录内容导出为白底 PNG");
            exp.Padding = new Thickness(11, 4, 11, 4);
            AutomationProperties.SetName(exp, "NotesExport");
            exp.Click += delegate { ExportNotesPng(); };
            btns.Children.Add(exp);
            Button fileExp = Ui.SmallButton("导出文件", "导出为 Word（.docx）或 PDF（.pdf）");
            fileExp.Padding = new Thickness(11, 4, 11, 4);
            AutomationProperties.SetName(fileExp, "NotesExportFile");
            fileExp.Click += delegate { ShowExportFileMenu(fileExp); };
            btns.Children.Add(fileExp);
            Button pr = Ui.SmallButton("打印", "打开打印菜单");
            pr.Padding = new Thickness(11, 4, 11, 4);
            AutomationProperties.SetName(pr, "NotesPrint");
            pr.Click += delegate { PrintNotes(); };
            btns.Children.Add(pr);
            Grid.SetRow(btns, g.RowDefinitions.Count - 1);
            g.Children.Add(btns);

            panel.Child = g;
            return panel;
        }

        // 生成 A4 白底内容视图（仅标题+正文），按党政机关公文格式排版：
        // 两种导出模板：gongwen=公文（A4，固定行距 28 磅，字体字号取用户设置）；long=长图（手机阅读）
        FrameworkElement BuildNotesPage(string tpl, out double w, out double h)
        {
            bool gongwen = tpl != "long";
            double mm = 96.0 / 25.4;
            double padL = gongwen ? 28 * mm : 30;
            double padR = gongwen ? 26 * mm : 30;
            double padT = gongwen ? 37 * mm : 30;
            double padB = gongwen ? 35 * mm : 30;
            w = gongwen ? A4WidthDip : 750;
            double contentW = w - padL - padR;

            StackPanel sp = new StackPanel();
            sp.Width = contentW;

            TextBlock title = new TextBlock();
            title.Text = _data.NotesTitle == null ? "" : _data.NotesTitle;
            title.FontFamily = NotesTitleFont();
            title.FontSize = gongwen ? NotesTitleSize : 40;
            title.Foreground = new SolidColorBrush(Color.FromRgb(0, 0, 0));
            title.TextAlignment = TextAlignment.Center;
            title.TextWrapping = TextWrapping.Wrap;
            double lineH = gongwen ? (28.0 * 96.0 / 72.0) : 54.0; // 公文：固定 28 磅行距
            title.Margin = new Thickness(0, gongwen ? lineH : 0, 0, gongwen ? 18 : 26); // 公文：标题上空一行
            sp.Children.Add(title);
            double bodySize = gongwen ? NotesBodySize : 30;
            string bodyText = _data.NotesBody == null ? "" : _data.NotesBody;
            string[] paras = bodyText.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            for (int i = 0; i < paras.Length; i++)
            {
                string line = paras[i];
                if (line.Length > 0 && !line.StartsWith("　　")) line = "　　" + line;
                TextBlock p = new TextBlock();
                p.Text = line.Length == 0 ? " " : line;
                p.FontFamily = gongwen
                    ? new FontFamily("Times New Roman, 方正仿宋_GBK, 仿宋")
                    : NotesBodyFont(); // 公文：英文 Times New Roman、中文方正仿宋_GBK
                p.FontSize = bodySize;
                p.Foreground = new SolidColorBrush(Color.FromRgb(0, 0, 0));
                p.TextWrapping = TextWrapping.Wrap;
                p.LineHeight = lineH;
                p.LineStackingStrategy = LineStackingStrategy.BlockLineHeight;
                sp.Children.Add(p);
            }

            sp.Measure(new Size(contentW, double.PositiveInfinity));
            double bodyH = sp.DesiredSize.Height;
            h = gongwen ? A4HeightDip : (padT + bodyH + padB);

            Border b = new Border();
            b.Background = Brushes.White;
            b.Width = w;
            b.Height = h;
            b.Padding = new Thickness(padL, padT, padR, padB);
            b.Child = sp;
            b.Measure(new Size(w, h));
            b.Arrange(new Rect(0, 0, w, h));
            b.UpdateLayout();
            return b;
        }

        // 渲染成白底位图：公文 300DPI；长图 2 倍缩放保证手机端清晰
        RenderTargetBitmap RenderNotesBitmap(string tpl)
        {
            double w, h;
            FrameworkElement vis = BuildNotesPage(tpl, out w, out h);
            double dpi = tpl == "long" ? 192.0 : A4ExportDpi;
            int pw = (int)Math.Round(w * dpi / 96.0);
            int ph = (int)Math.Round(h * dpi / 96.0);
            RenderTargetBitmap rtb = new RenderTargetBitmap(pw, ph, dpi, dpi, PixelFormats.Pbgra32);
            rtb.Render(vis);
            return rtb;
        }

        // ===== 备忘录富文本：工具条与格式化 =====
        Border NoteBarIcon(string glyph, string tip, Action onClick)
        {
            Border b = new Border();
            b.Width = 26;
            b.Height = 26;
            b.CornerRadius = new CornerRadius(13);
            b.Margin = new Thickness(0, 0, 4, 0);
            b.Background = new SolidColorBrush(Color.FromArgb(26, 255, 255, 255));
            b.BorderBrush = new SolidColorBrush(Color.FromArgb(70, 255, 255, 255));
            b.BorderThickness = new Thickness(1);
            b.Cursor = Cursors.Hand;
            b.ToolTip = tip;
            b.Focusable = false; // 点图标不抢焦点，保证正文始终可选中文字
            TextBlock t = Ui.Lbl(glyph, 11, Color.FromArgb(235, 255, 255, 255), true);
            t.HorizontalAlignment = HorizontalAlignment.Center;
            t.VerticalAlignment = VerticalAlignment.Center;
            b.Child = t;
            b.MouseLeftButtonUp += delegate { onClick(); };
            return b;
        }

        void LoadNotesDocument()
        {
            if (_notesRtb == null) return;
            _notesLoading = true;
            try
            {
                _notesRtb.Document.Blocks.Clear();
                if (!string.IsNullOrEmpty(_data.NotesBodyRtf))
                {
                    try
                    {
                        TextRange tr = new TextRange(_notesRtb.Document.ContentStart, _notesRtb.Document.ContentEnd);
                        byte[] rtfBytes = Convert.FromBase64String(_data.NotesBodyRtf);
                        using (MemoryStream ms = new MemoryStream(rtfBytes))
                        {
                            tr.Load(ms, DataFormats.Rtf);
                        }
                    }
                    catch { }
                }
                if (_notesRtb.Document.Blocks.Count == 0 || string.IsNullOrEmpty(_data.NotesBodyRtf))
                {
                    string body = _data.NotesBody ?? "";
                    string[] lines = body.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
                    for (int k = 0; k < lines.Length; k++)
                    {
                        Paragraph p = new Paragraph(new Run(lines[k]));
                        p.Margin = new Thickness(0, 0, 0, 2);
                        p.TextIndent = NotesBodySize * 2; // 正文首行缩进 2 字符
                        _notesRtb.Document.Blocks.Add(p);
                    }
                }
            }
            finally
            {
                _notesLoading = false;
            }
        }

        bool _notesLoading;

        void SyncNotesDocument()
        {
            if (_notesRtb == null || _notesLoading) return;
            try
            {
                TextRange tr0 = new TextRange(_notesRtb.Document.ContentStart, _notesRtb.Document.ContentEnd);
                _data.NotesBody = tr0.Text.TrimEnd('\r', '\n');
                using (MemoryStream ms = new MemoryStream())
                {
                    tr0.Save(ms, DataFormats.Rtf);
                    _data.NotesBodyRtf = Convert.ToBase64String(ms.ToArray());
                }
                SaveSoon();
            }
            catch { }
        }

        void NotesApply(DependencyProperty prop, object value)
        {
            if (_notesRtb == null) return;
            if (_notesRtb.Selection.IsEmpty) return; // 只对选中文字生效
            _notesRtb.Selection.ApplyPropertyValue(prop, value);
            _notesRtb.Focus();
        }

        void NotesToggleBold()
        {
            if (_notesRtb == null) return;
            object cur = _notesRtb.Selection.GetPropertyValue(TextElement.FontWeightProperty);
            bool bold = cur != null && cur != DependencyProperty.UnsetValue && ((FontWeight)cur) == FontWeights.Bold;
            NotesApply(TextElement.FontWeightProperty, bold ? FontWeights.Normal : FontWeights.Bold);
        }

        void NotesToggleItalic()
        {
            if (_notesRtb == null) return;
            object cur = _notesRtb.Selection.GetPropertyValue(TextElement.FontStyleProperty);
            bool it = cur != null && cur != DependencyProperty.UnsetValue && ((FontStyle)cur) == FontStyles.Italic;
            NotesApply(TextElement.FontStyleProperty, it ? FontStyles.Normal : FontStyles.Italic);
        }

        void NotesToggleUnderline()
        {
            if (_notesRtb == null) return;
            object cur = _notesRtb.Selection.GetPropertyValue(Inline.TextDecorationsProperty);
            bool has = false;
            if (cur != null && cur != DependencyProperty.UnsetValue)
            {
                TextDecorationCollection td = cur as TextDecorationCollection;
                has = td != null && td.Count > 0;
            }
            NotesApply(Inline.TextDecorationsProperty, has ? null : TextDecorations.Underline);
        }

        bool _hlOn;
        void NotesToggleHighlight()
        {
            _hlOn = !_hlOn;
            NotesApply(TextElement.BackgroundProperty, _hlOn ? new SolidColorBrush(Color.FromArgb(140, 255, 235, 59)) : null);
        }

        void NotesStepSize(int delta)
        {
            if (_notesRtb == null) return;
            object cur = _notesRtb.Selection.GetPropertyValue(TextElement.FontSizeProperty);
            double size = NotesBodySize;
            if (cur != null && cur != DependencyProperty.UnsetValue) size = (double)cur;
            size = Math.Max(9, Math.Min(48, size + delta * 2));
            NotesApply(TextElement.FontSizeProperty, size);
        }

        // 字体显示名：优先用中文本地化名称（如“微软雅黑”而不是 Microsoft YaHei）
        static string FontDisplayName(FontFamily ff)
        {
            try
            {
                foreach (System.Windows.Markup.XmlLanguage lang in ff.FamilyNames.Keys)
                {
                    string tag = lang.IetfLanguageTag;
                    if (tag.StartsWith("zh", StringComparison.OrdinalIgnoreCase))
                        return ff.FamilyNames[lang];
                }
            }
            catch { }
            return ff.Source;
        }

        void NotesPickFont()
        {
            DialogHost d = new DialogHost(this, "选择字体", 380, 460);
            // 搜索栏（输入即过滤，自动联想）
            TextBox search = Ui.TextInput("搜索字体…", null, "FontSearch");
            search.Height = 30;
            AutomationProperties.SetName(search, "FontSearch_box");
            d.Body.Children.Add(Ui.WrapInput(search));

            ListBox lb = new ListBox();
            lb.Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255));
            lb.Foreground = new SolidColorBrush(Color.FromArgb(230, 255, 255, 255));
            lb.BorderThickness = new Thickness(0);
            lb.Margin = new Thickness(0, 8, 0, 0);
            // 显示名（中文优先）与实际字体名成对保存，搜索时两者都参与匹配
            List<string> displays = new List<string>();
            Dictionary<string, string> sourceOf = new Dictionary<string, string>();
            foreach (FontFamily ff in Fonts.SystemFontFamilies)
            {
                string disp = FontDisplayName(ff);
                string key = disp;
                int n = 2;
                while (sourceOf.ContainsKey(key)) key = disp + " (" + (n++) + ")";
                displays.Add(key);
                sourceOf[key] = ff.Source;
            }
            displays.Sort(StringComparer.CurrentCulture);
            for (int i = 0; i < displays.Count; i++) lb.Items.Add(displays[i]);
            AutomationProperties.SetName(lb, "FontList");
            d.Body.Children.Add(lb);

            search.TextChanged += delegate
            {
                string q = (search.Text ?? "").Trim();
                lb.Items.Clear();
                for (int i = 0; i < displays.Count; i++)
                {
                    string disp = displays[i];
                    string src = sourceOf.ContainsKey(disp) ? sourceOf[disp] : disp;
                    bool hit = q.Length == 0
                        || disp.IndexOf(q, StringComparison.CurrentCultureIgnoreCase) >= 0
                        || src.IndexOf(q, StringComparison.CurrentCultureIgnoreCase) >= 0;
                    if (hit) lb.Items.Add(disp);
                }
                if (lb.Items.Count > 0) lb.SelectedIndex = 0;
            };
            string picked = null;
            Button ok = d.AddAction("确定", true);
            Button cancel = d.AddAction("取消", false);
            ok.Click += delegate
            {
                if (lb.SelectedItem != null) { picked = lb.SelectedItem.ToString(); d.Close(); }
            };
            cancel.Click += delegate { d.Close(); };
            lb.MouseDoubleClick += delegate
            {
                if (lb.SelectedItem != null) { picked = lb.SelectedItem.ToString(); d.Close(); }
            };
            d.Loaded += delegate { search.Focus(); };
            d.ShowDialog();
            if (!string.IsNullOrEmpty(picked))
            {
                string src = sourceOf.ContainsKey(picked) ? sourceOf[picked] : picked;
                NotesApply(TextElement.FontFamilyProperty, new FontFamily(src));
            }
        }

        // ===== 格式刷：单击刷一次；双击进入连续刷；再点一次退出 =====
        class NotesFmt
        {
            public object Family, Size, Weight, Style, Deco, Bg;
        }
        NotesFmt _fmt;
        bool _fmtSticky;

        NotesFmt CaptureFormat()
        {
            NotesFmt f = new NotesFmt();
            if (_notesRtb == null) return f;
            // 取光标处（若未选中则取前一个字符）的格式；取不到则回退到编辑器默认样式
            TextSelection sel = _notesRtb.Selection;
            TextRange range = sel;
            if (range.IsEmpty)
            {
                TextPointer p = _notesRtb.CaretPosition;
                TextPointer prev = p.GetPositionAtOffset(-1);
                if (prev != null) range = new TextRange(prev, p);
            }
            f.Family = range.GetPropertyValue(TextElement.FontFamilyProperty);
            f.Size = range.GetPropertyValue(TextElement.FontSizeProperty);
            f.Weight = range.GetPropertyValue(TextElement.FontWeightProperty);
            f.Style = range.GetPropertyValue(TextElement.FontStyleProperty);
            f.Deco = range.GetPropertyValue(Inline.TextDecorationsProperty);
            f.Bg = range.GetPropertyValue(TextElement.BackgroundProperty);
            if (!(f.Family is FontFamily)) f.Family = _notesRtb.FontFamily;
            if (!(f.Size is double)) f.Size = _notesRtb.FontSize;
            if (!(f.Weight is FontWeight)) f.Weight = _notesRtb.FontWeight;
            if (!(f.Style is FontStyle)) f.Style = _notesRtb.FontStyle;
            return f;
        }

        void ApplyFormat(TextSelection sel, NotesFmt f)
        {
            if (sel == null || f == null) return;
            if (f.Family != null && !(f.Family is DependencyProperty)) sel.ApplyPropertyValue(TextElement.FontFamilyProperty, f.Family);
            if (f.Size is double) sel.ApplyPropertyValue(TextElement.FontSizeProperty, f.Size);
            if (f.Weight is FontWeight) sel.ApplyPropertyValue(TextElement.FontWeightProperty, f.Weight);
            if (f.Style is FontStyle) sel.ApplyPropertyValue(TextElement.FontStyleProperty, f.Style);
            if (f.Deco is TextDecorationCollection) sel.ApplyPropertyValue(Inline.TextDecorationsProperty, f.Deco);
            if (f.Bg is Brush) sel.ApplyPropertyValue(TextElement.BackgroundProperty, f.Bg);
        }

        void NotesToggleFormatBrush(bool sticky)
        {
            // 已处于格式刷状态 → 再点一次退出
            if (_fmt != null || _fmtSticky)
            {
                _fmt = null;
                _fmtSticky = false;
                SetIconActive(_brushIcon, false);
                Flash("已退出格式刷");
                return;
            }
            // 必须先选中文字才能复制格式
            if (_notesRtb == null || _notesRtb.Selection.IsEmpty)
            {
                Flash("请先选中要复制格式的文字，再点格式刷");
                return;
            }
            _fmt = CaptureFormat();
            _fmtSticky = sticky;
            SetIconActive(_brushIcon, true);
            Flash(sticky ? "格式刷：连续模式（可反复刷，再点一次退出）" : "格式刷：已复制格式，选中文字即应用一次");
        }

        // 图标激活态：进入弹窗/模式时显示强调色，退出后恢复
        Border _brushIcon;
        void SetIconActive(Border b, bool on)
        {
            if (b == null) return;
            if (on)
            {
                Color acc = ColorUtil.Parse(_data.Settings.Accent, Color.FromArgb(255, 79, 140, 255));
                b.Background = new SolidColorBrush(Color.FromArgb(110, acc.R, acc.G, acc.B));
                b.BorderBrush = ColorUtil.Brush(_data.Settings.Accent);
            }
            else
            {
                b.Background = new SolidColorBrush(Color.FromArgb(26, 255, 255, 255));
                b.BorderBrush = new SolidColorBrush(Color.FromArgb(70, 255, 255, 255));
            }
        }

        void NotesPickFontWithState(Border icon)
        {
            SetIconActive(icon, true);
            // 先把强调色真正渲染出来，再打开模态弹窗（否则弹窗期间看不到变色）
            try
            {
                icon.UpdateLayout();
                icon.Dispatcher.Invoke(new Action(delegate { }), System.Windows.Threading.DispatcherPriority.Render);
            }
            catch { }
            try { NotesPickFont(); }
            finally
            {
                SetIconActive(icon, false);
                try { icon.UpdateLayout(); } catch { }
            }
        }

        bool _fmtApplying;
        void NotesOnSelectionChanged()
        {
            if (_fmt == null || _notesRtb == null || _fmtApplying) return;
            if (_notesRtb.Selection.IsEmpty) return;
            _fmtApplying = true;
            // 放到选区事件之后再套格式，避免在 SelectionChanged 里改选区导致选不中文字
            Dispatcher.BeginInvoke(new Action(delegate
            {
                try { if (_fmt != null) ApplyFormat(_notesRtb.Selection, _fmt); }
                catch { }
                _fmtApplying = false;
                if (!_fmtSticky) { _fmt = null; SetIconActive(_brushIcon, false); }
            }), System.Windows.Threading.DispatcherPriority.Background);
        }

        // 选择导出模板：公文 / 长图
        string AskNotesTemplate()
        {
            DialogHost d = new DialogHost(this, "选择导出模板", 380, 190);
            string tpl = null;
            TextBlock tip = Ui.Lbl("请选择导出模板", 12, Color.FromArgb(210, 255, 255, 255));
            tip.HorizontalAlignment = HorizontalAlignment.Center;
            d.Body.Children.Add(tip);
            StackPanel row = new StackPanel() { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 14, 0, 0) };
            Button g = Ui.SmallButton("公文", "A4、页边距 37/35/28/26mm、固定行距 28 磅，字体字号取当前设置");
            g.Padding = new Thickness(20, 8, 20, 8);
            AutomationProperties.SetName(g, "TplGongwen");
            g.Click += delegate { tpl = "gongwen"; d.Close(); };
            Button l = Ui.SmallButton("长图", "手机阅读长图：宽 750px、自动高度、2 倍清晰度");
            l.Padding = new Thickness(20, 8, 20, 8);
            l.Margin = new Thickness(12, 0, 0, 0);
            AutomationProperties.SetName(l, "TplLong");
            l.Click += delegate { tpl = "long"; d.Close(); };
            row.Children.Add(g);
            row.Children.Add(l);
            d.Body.Children.Add(row);
            Button cancel = d.AddAction("取消", false);
            cancel.Click += delegate { d.Close(); };
            d.ShowDialog();
            return tpl;
        }

        void ExportNotesPng()
        {
            if (string.IsNullOrEmpty(_data.NotesTitle) && string.IsNullOrEmpty(_data.NotesBody))
            {
                Flash("备忘录内容为空");
                return;
            }
            // 先选模板：公文（A4 公文格式）/ 长图（手机阅读）
            string tpl = AskNotesTemplate();
            if (tpl == null) return;
            RenderTargetBitmap rtb = RenderNotesBitmap(tpl);

            // 先预览，确认后再保存
            DialogHost d = new DialogHost(this, "导出预览", 520, 700);
            Border frame = new Border();
            frame.Background = Brushes.White;
            frame.CornerRadius = new CornerRadius(4);
            frame.Padding = new Thickness(6);
            frame.HorizontalAlignment = HorizontalAlignment.Center;
            Image img = new Image();
            img.Source = rtb;
            img.Stretch = Stretch.Uniform;
            img.MaxWidth = 456;
            img.MaxHeight = 520;
            img.HorizontalAlignment = HorizontalAlignment.Center;
            frame.Child = img;
            d.Body.Children.Add(frame);
            TextBlock tip = Ui.Lbl(tpl == "long"
                ? "长图模板：宽 750px、2 倍缩放，适合手机竖屏阅读；确认后保存为 PNG。"
                : "公文模板：A4 白底、页边距 37/35/28/26mm、固定行距 28 磅；确认后保存为 PNG。",
                11, Color.FromArgb(165, 255, 255, 255));
            tip.Margin = new Thickness(0, 9, 0, 0);
            tip.HorizontalAlignment = HorizontalAlignment.Center;
            d.Body.Children.Add(tip);
            Button cancel = d.AddAction("取消", false);
            cancel.Click += delegate { d.Close(); };
            Button save = d.AddAction("保存图片", true);
            save.Click += delegate
            {
                d.Close();
                SaveNotesPng(rtb);
            };
            d.ShowDialog();
        }

        void SaveNotesPng(RenderTargetBitmap rtb)
        {
            Microsoft.Win32.SaveFileDialog sfd = new Microsoft.Win32.SaveFileDialog();
            sfd.Title = "导出备忘录图片";
            sfd.Filter = "PNG 图片|*.png";
            sfd.FileName = "备忘录-" + DateTime.Now.ToString("yyyyMMdd-HHmm") + ".png";
            sfd.InitialDirectory = _dataDir;
            if (sfd.ShowDialog() != true) return;
            try
            {
                PngBitmapEncoder enc = new PngBitmapEncoder();
                enc.Frames.Add(BitmapFrame.Create(rtb));
                using (FileStream fs = new FileStream(sfd.FileName, FileMode.Create))
                {
                    enc.Save(fs);
                }
                Flash("已导出：" + sfd.FileName);
            }
            catch (Exception ex)
            {
                Flash("导出失败：" + ex.Message);
            }
        }

        void PrintNotes()
        {
            PrintDialog pd = new PrintDialog();
            if (pd.ShowDialog() != true) return;
            try
            {
                double pw0, ph0;
                FrameworkElement vis = BuildNotesPage("gongwen", out pw0, out ph0);
                pd.PrintVisual(vis, "备忘录");
                Flash("已发送到打印机");
            }
            catch (Exception ex)
            {
                Flash("打印失败：" + ex.Message);
            }
        }
    }
}
