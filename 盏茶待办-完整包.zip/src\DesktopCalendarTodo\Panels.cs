using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;

namespace DesktopCalendarTodo
{
    public partial class MainWindow
    {
        string _dateKey = "";
        // 月/日/周视图通用：日程与待办的选中集合（Ctrl 多选）
        readonly HashSet<string> _selSched = new HashSet<string>();
        readonly HashSet<string> _selTodo = new HashSet<string>();
        string _selSubId;   // 当前选中的子任务（可单独选中，配合底部操作行）
        readonly string[] _weekLabels = { "周一", "周二", "周三", "周四", "周五", "周六", "周日" };
        const string _dateFmt = "yyyy-MM-dd";

        // ================= 月历面板 =================
        Border BuildCalendarPanel()
        {
            Border panel = new Border();
            panel.Padding = new Thickness(10, 8, 10, 8);

            Grid g = new Grid();
            g.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(24) });
            g.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1, GridUnitType.Star) });

            Grid head = new Grid();
            for (int i = 0; i < 7; i++) head.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1, GridUnitType.Star) });
            for (int i = 0; i < 7; i++)
            {
                TextBlock w = Ui.Lbl(_weekLabels[i], 11, Color.FromArgb(150, 255, 255, 255));
                w.TextAlignment = TextAlignment.Center;
                w.VerticalAlignment = VerticalAlignment.Center;
                if (i >= 5) w.Foreground = new SolidColorBrush(Color.FromArgb(110, 255, 255, 255));
                Grid.SetColumn(w, i);
                head.Children.Add(w);
            }
            Grid.SetRow(head, 0);
            g.Children.Add(head);

            _calendarGrid = new Grid();
            for (int i = 0; i < 7; i++) _calendarGrid.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1, GridUnitType.Star) });
            for (int i = 0; i < 6; i++) _calendarGrid.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1, GridUnitType.Star) });
            Grid.SetRow(_calendarGrid, 1);
            g.Children.Add(_calendarGrid);

            panel.Child = g;
            return panel;
        }

        // ================= 周视图一周面板 =================
        Border BuildWeekCalendarPanel()
        {
            Border panel = new Border();
            panel.Padding = new Thickness(10, 8, 10, 8);

            Grid g = new Grid();
            g.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(26) });
            g.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(24) });
            g.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1, GridUnitType.Star) });

            // 行0：周范围 + 左右切换
            Grid nav = new Grid();
            nav.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
            nav.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1, GridUnitType.Star) });
            nav.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
            Button wPrev = Ui.ToolButton("◀", "上一周");
            AutomationProperties.SetName(wPrev, "BtnWeekPrev");
            wPrev.Click += delegate { PrevPeriod(); };
            Grid.SetColumn(wPrev, 0);
            nav.Children.Add(wPrev);
            _weekRangeLabel = Ui.Lbl("", 13, Colors.White, true);
            _weekRangeLabel.HorizontalAlignment = HorizontalAlignment.Center;
            _weekRangeLabel.VerticalAlignment = VerticalAlignment.Center;
            Grid.SetColumn(_weekRangeLabel, 1);
            nav.Children.Add(_weekRangeLabel);
            Button wNext = Ui.ToolButton("▶", "下一周");
            AutomationProperties.SetName(wNext, "BtnWeekNext");
            wNext.Click += delegate { NextPeriod(); };
            Grid.SetColumn(wNext, 2);
            nav.Children.Add(wNext);
            Grid.SetRow(nav, 0);
            g.Children.Add(nav);

            // 行1：星期头
            Grid head = new Grid();
            for (int i = 0; i < 7; i++) head.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1, GridUnitType.Star) });
            for (int i = 0; i < 7; i++)
            {
                TextBlock w = Ui.Lbl(_weekLabels[i], 11, Color.FromArgb(150, 255, 255, 255));
                w.TextAlignment = TextAlignment.Center;
                w.VerticalAlignment = VerticalAlignment.Center;
                if (i >= 5) w.Foreground = new SolidColorBrush(Color.FromArgb(110, 255, 255, 255));
                Grid.SetColumn(w, i);
                head.Children.Add(w);
            }
            Grid.SetRow(head, 1);
            g.Children.Add(head);

            // 行2：7 格周历（每格约 3 倍月视图格宽）
            _weekGrid = new Grid();
            for (int i = 0; i < 7; i++) _weekGrid.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1, GridUnitType.Star) });
            Grid.SetRow(_weekGrid, 2);
            g.Children.Add(_weekGrid);

            panel.Child = g;
            return panel;
        }

        void RebuildWeekCalendar()
        {
            if (_weekGrid == null) return;
            _weekGrid.Children.Clear();
            DateTime start = _viewWeek;
            if (_weekRangeLabel != null)
            {
                DateTime end = start.AddDays(6);
                _weekRangeLabel.Text = start.ToString("yyyy年M月d日") + " – " + end.ToString("M月d日");
            }
            double cellW = _weekGrid.ActualWidth > 10 ? _weekGrid.ActualWidth / 7.0 : 120;
            double avail = cellW - 10;
            for (int i = 0; i < 7; i++)
            {
                DateTime day = start.AddDays(i);
                double cellH = _weekGrid.ActualHeight > 10 ? _weekGrid.ActualHeight / 6.0 : 60;
                Border cell = BuildDayCell(day, cellW, avail, cellH);
                Grid.SetColumn(cell, i);
                _weekGrid.Children.Add(cell);
            }
        }

        // ================= 周视图下方：7 列日程竖格（列内只有日期头 + 日程卡片，操作按钮统一放到窗口底部一行） =================
        Border BuildWeekColumnsPanel()
        {
            Border panel = new Border();
            panel.Padding = new Thickness(10, 8, 10, 2);

            Grid g = new Grid();
            // 单行 star：日期与日程格子填满窗口高度（不留上下大空白），分隔线内置 2/3 高居中
            g.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1, GridUnitType.Star) });
            // 列：7 个日程列 + 6 条 6px 分隔线槽
            for (int i = 0; i < 7; i++)
            {
                g.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1, GridUnitType.Star) });
                if (i < 6) g.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(6) });
            }

            _weekColStacks = new StackPanel[7];
            _weekColHeads = new Border[7];
            _weekDividers = new Border[6];

            for (int i = 0; i < 7; i++)
            {
                Border col = new Border();
                col.Margin = new Thickness(2, 0, 2, 0);
                col.CornerRadius = new CornerRadius(8);
                col.Background = new SolidColorBrush(Color.FromArgb(14, 255, 255, 255));
                col.Padding = new Thickness(4, 5, 4, 5);
                AutomationProperties.SetName(col, "WeekCol" + i);

                Grid cg = new Grid();
                cg.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
                cg.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1, GridUnitType.Star) });

                // 日期头（可点击：底部“添加日程/+”的目标日期）
                Border head = new Border();
                head.CornerRadius = new CornerRadius(6);
                head.Background = Brushes.Transparent;
                head.Padding = new Thickness(2, 2, 2, 2);
                head.Margin = new Thickness(0, 0, 0, 4);
                head.Cursor = Cursors.Hand;
                head.ToolTip = "点击选中该日期：底部“添加日程 / 安排”的目标日期";
                TextBlock ht = Ui.Lbl("", 11.5, Colors.White, true);
                ht.HorizontalAlignment = HorizontalAlignment.Center;
                head.Child = ht;
                head.Tag = "weekhead";
                _weekColHeads[i] = head;
                head.MouseLeftButtonUp += MakeWeekHeadSelect(i);
                Grid.SetRow(head, 0);
                cg.Children.Add(head);

                // 日程列表
                ScrollViewer sv = new ScrollViewer();
                sv.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
                sv.HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
                StackPanel list = new StackPanel();
                _weekColStacks[i] = list;
                sv.Content = list;
                Grid.SetRow(sv, 1);
                cg.Children.Add(sv);

                col.Child = cg;
                col.MouseLeftButtonDown += MakeWeekBlankClick();
                Grid.SetColumn(col, i * 2);
                Grid.SetRow(col, 0);
                g.Children.Add(col);

                // 列间强调色分隔线：外层 1/4/1 槽保证内层分隔线长度 = 窗口高度 2/3 且垂直居中
                if (i < 6)
                {
                    Grid dWrap = new Grid();
                    dWrap.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1, GridUnitType.Star) });
                    dWrap.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(4, GridUnitType.Star) });
                    dWrap.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1, GridUnitType.Star) });
                    Border dv = new Border();
                    dv.Width = 6; // 与分隔线画笔的 6px 平铺单元同宽：星星/圆点/双线等样式才完整显示
                    dv.HorizontalAlignment = HorizontalAlignment.Center;
                    dv.VerticalAlignment = VerticalAlignment.Stretch;
                    dv.Background = Ui.DividerBrush(ColorUtil.Brush(_data.Settings.Accent).Color, _data.Settings.DividerStyle);
                    _weekDividers[i] = dv;
                    Grid.SetRow(dv, 1);
                    dWrap.Children.Add(dv);
                    Grid.SetColumn(dWrap, i * 2 + 1);
                    Grid.SetRow(dWrap, 0);
                    g.Children.Add(dWrap);
                }
            }

            panel.Child = g;
            return panel;
        }

        MouseButtonEventHandler MakeWeekHeadSelect(int idx)
        {
            return delegate(object sender, MouseButtonEventArgs e) { SelectWeekDate(_viewWeek.AddDays(idx)); };
        }

        // 点击周视图空白处（不在日程卡片/日期头上）= 取消所有选中
        MouseButtonEventHandler MakeWeekBlankClick()
        {
            return delegate(object sender, MouseButtonEventArgs e)
            {
                if (IsWeekChrome(e.OriginalSource as DependencyObject)) return;
                ClearWeekSelection();
            };
        }

        bool IsWeekChrome(DependencyObject src)
        {
            FrameworkElement fe = src as FrameworkElement;
            int guard = 0;
            while (fe != null && guard++ < 40)
            {
                string tag = fe.Tag as string;
                if (tag == "weekcard" || tag == "weekhead") return true;
                fe = VisualTreeHelper.GetParent(fe) as FrameworkElement;
            }
            return false;
        }

        // ================= 周视图底部：一条独立操作行（不在日期/日程格子里；全窗口仅此一份） =================
        Border BuildWeekActionBar()
        {
            Border panel = new Border();
            panel.Padding = new Thickness(10, 0, 10, 8);

            Grid g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });                       // 目标日期
            g.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });                       // 安排
            g.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1, GridUnitType.Star) });  // 添加日程
            g.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(74) });                    // 时间
            g.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(34) });                    // +
            g.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });                       // 月视图日程栏的全部按钮

            _weekTargetLbl = Ui.Lbl("", 11, ColorUtil.Parse(_data.Settings.Accent, Colors.White), true);
            _weekTargetLbl.VerticalAlignment = VerticalAlignment.Center;
            _weekTargetLbl.Margin = new Thickness(2, 0, 8, 0);
            _weekTargetLbl.ToolTip = "底部“添加日程 / +”将加到该日期（点击列上的日期头可切换）";
            AutomationProperties.SetName(_weekTargetLbl, "WeekTarget");
            Grid.SetColumn(_weekTargetLbl, 0);
            g.Children.Add(_weekTargetLbl);

            Button arrange = Ui.SmallButton("安排", "弹出与日视图一致的月历：把输入的日程安排到所选日期；未输入内容时，把选中的日程移到所选日期");
            arrange.Foreground = ColorUtil.Brush(_data.Settings.Accent);
            arrange.Padding = new Thickness(9, 4, 9, 4);
            arrange.VerticalAlignment = VerticalAlignment.Center;
            AutomationProperties.SetName(arrange, "WeekArrange");
            arrange.Click += delegate { OnWeekArrange(); };
            Grid.SetColumn(arrange, 1);
            g.Children.Add(arrange);

            _weekText = Ui.TextInput("添加日程", OnWeekBarEnter, "WeekText");
            if (_draftSchedText.Length > 0) _weekText.Text = _draftSchedText;
            Border wtx = Ui.WrapInput(_weekText);
            wtx.Margin = new Thickness(6, 0, 6, 0);
            wtx.VerticalAlignment = VerticalAlignment.Center;
            Grid.SetColumn(wtx, 2);
            g.Children.Add(wtx);

            _weekTime = Ui.TextInput("时间", OnWeekBarEnter, "WeekTime");
            if (_draftSchedTime.Length > 0) _weekTime.Text = _draftSchedTime;
            Border wtm = Ui.WrapInput(_weekTime);
            wtm.Margin = new Thickness(0, 0, 6, 0);
            wtm.VerticalAlignment = VerticalAlignment.Center;
            Grid.SetColumn(wtm, 3);
            g.Children.Add(wtm);

            Border add = MakeRoundPlus("+", "添加到选中的日期", delegate { AddWeekBarSchedule(); }, "WeekAdd");
            add.Margin = new Thickness(0, 1, 0, 1);
            Grid.SetColumn(add, 4);
            g.Children.Add(add);

            WrapPanel acts = new WrapPanel();
            acts.Margin = new Thickness(8, 0, 0, 0);
            acts.VerticalAlignment = VerticalAlignment.Center;
            acts.Children.Add(MakeWeekAct("回撤", "WeekActBack", "移回待办栏（保留完成状态、分类、颜色与时间）",
                delegate(ScheduleItem it, List<ScheduleItem> l, int i) { DoRevertSchedule(it, i, l); }));
            acts.Children.Add(MakeWeekAct("复制", "WeekActCopy", "整体复制为新日程或新待办",
                delegate(ScheduleItem it, List<ScheduleItem> l, int i) { DoCopySchedule(it, i, l); }));
            _weekColorBtn = MakeWeekAct("●", "WeekActColor", "分类颜色",
                delegate(ScheduleItem it, List<ScheduleItem> l, int i) { DoPickScheduleColor(it); });
            acts.Children.Add(_weekColorBtn);
            acts.Children.Add(MakeWeekAct("子任务", "WeekActSub", "添加/管理子任务",
                delegate(ScheduleItem it, List<ScheduleItem> l, int i) { ToggleSubtask(it.Id); }));
            acts.Children.Add(MakeWeekAct("▲", "WeekActUp", "上移",
                delegate(ScheduleItem it, List<ScheduleItem> l, int i) { MoveSchedule(l, i, -1); }));
            acts.Children.Add(MakeWeekAct("▼", "WeekActDown", "下移",
                delegate(ScheduleItem it, List<ScheduleItem> l, int i) { MoveSchedule(l, i, 1); }));
            acts.Children.Add(MakeWeekAct("顺延", "WeekActDefer", "顺延到下一个工作日（可反复顺延）",
                delegate(ScheduleItem it, List<ScheduleItem> l, int i) { DoDeferSchedule(it, i, l); }));
            acts.Children.Add(MakeWeekAct("改", "WeekActEdit", "修改内容/时间（已选中子任务时改子任务）",
                delegate(ScheduleItem it, List<ScheduleItem> l, int i) { if (!TryEditSelectedSubtask(it)) DoEditSchedule(it); }));
            acts.Children.Add(MakeWeekAct("删", "WeekActDelete", "删除该日程（已选中子任务时删子任务）",
                delegate(ScheduleItem it, List<ScheduleItem> l, int i) { if (!TryDeleteSelectedSubtask(it)) DoDeleteSchedule(l, i); }));
            Grid.SetColumn(acts, 5);
            g.Children.Add(acts);

            panel.Child = g;
            return panel;
        }

        // 底部操作行按钮：先解析当前选中的日程，再执行与月视图日程栏一致的动作
        Button MakeWeekAct(string label, string autoId, string tip, Action<ScheduleItem, List<ScheduleItem>, int> act)
        {
            Button b = Ui.SmallButton(label, tip);
            b.Padding = new Thickness(5, 3, 5, 3);
            b.VerticalAlignment = VerticalAlignment.Center;
            AutomationProperties.SetName(b, autoId);
            b.Click += delegate
            {
                ScheduleItem it;
                List<ScheduleItem> list;
                int index;
                if (!ResolveWeekSelection(out it, out list, out index))
                {
                    Flash("请先点选一条日程（点击列中的日程卡片）");
                    return;
                }
                act(it, list, index);
            };
            return b;
        }

        Button _weekColorBtn;
        TextBox _weekText;
        TextBox _weekTime;
        TextBlock _weekTargetLbl;
        string _weekSelId;
        bool _weekDateSel; // 周视图日期是否处于选中状态（再次点击/点空白取消）
        bool _buildingTodoFloat; // 正在构建周视图「待办」浮窗（其分类下拉只作用于浮窗本身）
        string _schedCatFilter = "全部"; // 日程栏专属分类筛选（与待办栏的 _catFilterVal 互不影响）
        TextBlock _schedCatLabel;        // 日程栏分类按钮文字（选择后同步更新）
        Dictionary<string, Border> _weekCards = new Dictionary<string, Border>();

        bool ResolveWeekSelection(out ScheduleItem it, out List<ScheduleItem> list, out int index)
        {
            it = null; list = null; index = -1;
            if (string.IsNullOrEmpty(_weekSelId)) return false;
            foreach (KeyValuePair<string, List<ScheduleItem>> kv in _data.Schedules)
            {
                List<ScheduleItem> l = kv.Value;
                for (int i = 0; i < l.Count; i++)
                {
                    if (l[i].Id == _weekSelId) { it = l[i]; list = l; index = i; return true; }
                }
            }
            _weekSelId = null;
            return false;
        }

        MouseButtonEventHandler MakeWeekCardSelect(string id)
        {
            return delegate(object sender, MouseButtonEventArgs e) { SelectWeekItem(id); };
        }

        void SelectWeekItem(string id)
        {
            // 再次点击同一项 -> 取消选中
            if (id == _weekSelId)
            {
                _weekSelId = null;
                UpdateWeekSelectionVisuals();
                return;
            }
            _weekSelId = id;
            ScheduleItem it;
            List<ScheduleItem> list;
            int index;
            if (ResolveWeekSelection(out it, out list, out index))
            {
                DateTime d = DateOfSchedule(it);
                _selected = d.Date;
                _weekDateSel = true;
                UpdateWeekHeadStyles();
            }
            UpdateWeekTarget();
            UpdateWeekSelectionVisuals();
        }

        void SelectWeekDate(DateTime day)
        {
            // 再次点击同一日期 -> 取消日期选中（目标日期回退到“今天/周一”）
            if (_weekDateSel && _selected.Date == day.Date)
            {
                _weekDateSel = false;
                UpdateWeekHeadStyles();
                UpdateWeekTarget();
                return;
            }
            _selected = day.Date;
            _weekDateSel = true;
            UpdateWeekHeadStyles();
            UpdateWeekTarget();
        }

        // 点击周视图空白处：取消所有选中
        void ClearWeekSelection()
        {
            if (_weekSelId == null && !_weekDateSel) return;
            _weekSelId = null;
            _weekDateSel = false;
            UpdateWeekHeadStyles();
            UpdateWeekTarget();
            UpdateWeekSelectionVisuals();
        }

        void UpdateWeekTarget()
        {
            if (_weekTargetLbl == null) return;
            _weekTargetLbl.Text = _selected.ToString("M月d日") + " " + WeekCn(_selected);
        }

        // 周视图日期头样式（今天 = 强调色；选中日期 = 半透明强调色 + 描边）
        void UpdateWeekHeadStyles()
        {
            if (_weekColHeads == null) return;
            for (int i = 0; i < 7; i++)
            {
                Border head = _weekColHeads[i];
                if (head == null) continue;
                DateTime day = _viewWeek.AddDays(i);
                TextBlock ht = head.Child as TextBlock;
                if (ht != null)
                {
                    ht.Text = day.Day + " " + WeekCn(day).Replace("周", "");
                    ht.Foreground = new SolidColorBrush(Color.FromArgb(235, 255, 255, 255));
                }
                if (day == DateTime.Today)
                {
                    head.Background = ColorUtil.Brush(_data.Settings.Accent);
                    if (ht != null) ht.Foreground = Brushes.White;
                    head.BorderThickness = new Thickness(0);
                }
                else if (_weekDateSel && day == _selected)
                {
                    head.Background = new SolidColorBrush(Color.FromArgb(60, 79, 140, 255));
                    head.BorderBrush = ColorUtil.Brush(_data.Settings.Accent);
                    head.BorderThickness = new Thickness(1);
                }
                else
                {
                    head.Background = Brushes.Transparent;
                    head.BorderThickness = new Thickness(0);
                }
            }
        }

        // 选中卡片高亮 + 底部“●”颜色同步（不重建列表，避免打断文字选中）
        void UpdateWeekSelectionVisuals()
        {
            Brush acc = ColorUtil.Brush(_data.Settings.Accent);
            Color accC = ColorUtil.Parse(_data.Settings.Accent, Colors.White);
            ScheduleItem selIt;
            List<ScheduleItem> selList;
            int selIdx;
            bool hasSel = ResolveWeekSelection(out selIt, out selList, out selIdx);
            foreach (KeyValuePair<string, Border> kv in _weekCards)
            {
                Border card = kv.Value;
                if (card == null) continue;
                bool sel = hasSel && kv.Key == _weekSelId;
                // 未选中时保持“事项分类颜色”，选中时用强调色高亮
                Color cc = Color.FromArgb(255, 79, 140, 255);
                ScheduleItem ci = ScheduleById(kv.Key);
                if (ci != null) cc = ColorUtil.Parse(ci.Color, cc);
                card.BorderBrush = sel ? acc : new SolidColorBrush(Color.FromArgb(120, cc.R, cc.G, cc.B));
                card.BorderThickness = new Thickness(sel ? 1.5 : 1);
                card.Background = sel
                    ? new SolidColorBrush(Color.FromArgb(46, accC.R, accC.G, accC.B))
                    : new SolidColorBrush(Color.FromArgb(44, cc.R, cc.G, cc.B));
            }
            if (_weekColorBtn != null)
            {
                _weekColorBtn.Foreground = hasSel
                    ? ColorUtil.Brush(selIt.Color)
                    : new SolidColorBrush(Color.FromArgb(150, 255, 255, 255));
            }
        }

        void OnWeekBarEnter(object sender, RoutedEventArgs e)
        {
            AddWeekBarSchedule();
        }

        // 底部“添加日程/+”的目标日期：选中日期；未选中时回退到今天（本周内）或周一
        DateTime WeekTargetDate()
        {
            DateTime ws = _viewWeek.Date;
            if (!_weekDateSel)
            {
                DateTime today = DateTime.Today;
                if (today >= ws && today <= ws.AddDays(6)) return today;
                return ws;
            }
            DateTime d = _selected.Date;
            if (d < ws || d > ws.AddDays(6)) return ws;
            return d;
        }

        ScheduleItem ScheduleById(string id)
        {
            if (string.IsNullOrEmpty(id)) return null;
            foreach (KeyValuePair<string, List<ScheduleItem>> kv in _data.Schedules)
            {
                List<ScheduleItem> l = kv.Value;
                for (int i = 0; i < l.Count; i++)
                    if (l[i] != null && l[i].Id == id) return l[i];
            }
            return null;
        }

        ScheduleItem MakeNewSchedule(string text, string time)
        {
            ScheduleItem it = new ScheduleItem();
            it.Id = Guid.NewGuid().ToString("N");
            it.Text = text;
            it.Time = time;
            it.EndTime = "";
            it.Done = false;
            it.Category = "日常";
            it.CustomColor = "";
            it.Subtasks = new List<SubtaskItem>();
            return it;
        }

        void AddWeekBarSchedule()
        {
            string text = _weekText.Text.Trim();
            string time = _weekTime.Text.Trim();
            if (text.Length == 0) { if (time.Length > 0) Flash("内容不能为空"); return; }
            if (time.Length > 0 && !Dialogs.IsValidTime(time))
            {
                Flash("时间格式应为 HH:mm（如 09:30）");
                return;
            }
            DateTime day = WeekTargetDate();
            _data.DaySchedules(day).Add(MakeNewSchedule(text, time));
            _weekText.Clear();
            _weekTime.Clear();
            RefreshAll();
            SaveSoon();
            _weekText.Focus();
        }

        // “安排”：先选开始日期、再选结束日期，然后选重复方式与次数；有输入则新增，无输入则把选中日程安排成系列
        void OnWeekArrange()
        {
            string time = _weekTime.Text.Trim();
            if (time.Length > 0 && !Dialogs.IsValidTime(time))
            {
                Flash("时间格式应为 HH:mm（如 09:30）");
                return;
            }
            ScheduleItem it;
            List<ScheduleItem> list;
            int index;
            bool hasSel = ResolveWeekSelection(out it, out list, out index);
            if (_weekText.Text.Trim().Length == 0 && !hasSel)
            {
                Flash("请先输入日程内容，或点选一条日程再安排");
                return;
            }
            ShowArrangeCalendar("安排日程", delegate(DateTime start, DateTime end, string repeat, int count)
            {
                WeekArrangeToDates(start, end, repeat, count);
            });
        }

        void WeekArrangeToDates(DateTime start, DateTime end, string repeat, int count)
        {
            List<DateTime> dates = BuildArrangeDates(start, end, repeat, count);
            if (dates.Count == 0) return;
            string text = _weekText.Text.Trim();
            string time = _weekTime.Text.Trim();
            if (text.Length > 0)
            {
                for (int i = 0; i < dates.Count; i++)
                    _data.DaySchedules(dates[i]).Add(MakeNewSchedule(text, time));
                _weekText.Clear();
                _weekTime.Clear();
            }
            else
            {
                ScheduleItem it;
                List<ScheduleItem> list;
                int index;
                if (!ResolveWeekSelection(out it, out list, out index)) return;
                list.RemoveAt(index);
                for (int i = 0; i < dates.Count; i++)
                {
                    ScheduleItem c = it.Clone();
                    c.Id = Guid.NewGuid().ToString("N");
                    _data.DaySchedules(dates[i]).Add(c);
                }
            }
            _selected = start.Date;
            SyncWeekToSelected();
            RefreshAll();
            SaveSoon();
            Flash("已安排 " + dates.Count + " 天（" + start.ToString("M月d日") + " 起）"); // 放在刷新之后：周视图的提示显示在底部目标日期标签上
        }

        // 按“开始日期 + 结束日期 + 重复方式 + 重复次数”展开需要安排的日期（去重并排序）。
        // 日期范围表示每次发生持续的天数；重复次数表示发生次数（1-9999）。
        List<DateTime> BuildArrangeDates(DateTime start, DateTime end, string repeat, int count)
        {
            if (end.Date < start.Date) { DateTime tmp = start; start = end; end = tmp; }
            start = start.Date;
            end = end.Date;
            int span = (end - start).Days;
            List<DateTime> starts = new List<DateTime>();
            if (repeat == ArrangePlan.RNone)
            {
                starts.Add(start);
            }
            else
            {
                ArrangePlan plan = new ArrangePlan();
                plan.StartDate = start;
                plan.EndDate = start; // 只用重复次数控制次数；结束日期仅表示单次持续范围
                plan.RepeatType = repeat;
                plan.RepeatCount = Math.Max(1, count);
                starts = plan.GenerateDates();
            }
            HashSet<string> seen = new HashSet<string>();
            List<DateTime> res = new List<DateTime>();
            for (int i = 0; i < starts.Count; i++)
            {
                for (int k = 0; k <= span; k++)
                {
                    DateTime day = starts[i].AddDays(k);
                    if (seen.Add(day.ToString("yyyy-MM-dd"))) res.Add(day);
                }
            }
            res.Sort();
            return res;
        }

        // 选中日期越出当前周时，把目标日期收回到本周（避免“添加日程”加到看不见的日期）
        void NormalizeWeekTarget()
        {
            DateTime ws = _viewWeek.Date;
            DateTime d = _selected.Date;
            if (d < ws || d > ws.AddDays(6))
            {
                DateTime today = DateTime.Today;
                _selected = (today >= ws && today <= ws.AddDays(6)) ? today : ws;
            }
            UpdateWeekTarget();
        }

        // 刷新周视图列间分隔线样式（设置面板改「竖向分隔线样式 / 强调色」后立即生效）
        void UpdateWeekDividers()
        {
            if (_weekDividers == null) return;
            SolidColorBrush acc = ColorUtil.Brush(_data.Settings.Accent);
            Brush dv = Ui.DividerBrush(acc.Color, _data.Settings.DividerStyle);
            for (int i = 0; i < _weekDividers.Length; i++)
            {
                if (_weekDividers[i] != null) _weekDividers[i].Background = dv;
            }
        }

        TextBlock _weekRangeLabel;
        StackPanel[] _weekColStacks;   // 周视图 7 列日程列表
        Border[] _weekColHeads;        // 周视图 7 列日期头
        Border[] _weekDividers;        // 周视图 6 条列间分隔线

        // 周视图列卡片：每列只放日期头 + 日程卡片（卡片上不再重复操作按钮，全部操作由底部一行统一完成）
        void RebuildWeekColumns()
        {
            if (_weekColStacks == null || _weekColHeads == null) return;
            _weekCards.Clear();
            UpdateWeekHeadStyles();
            for (int i = 0; i < 7; i++)
            {
                DateTime day = _viewWeek.AddDays(i);
                StackPanel list = _weekColStacks[i];
                if (list == null) continue;
                list.Children.Clear();
                List<ScheduleItem> lst = _data.DaySchedules(day);
                for (int j = 0; j < lst.Count; j++)
                {
                    Border card = MakeScheduleCard(lst[j], j, lst, true); // 周视图窄列：有时间安排时文字置于其下方
                    card.Tag = "weekcard";
                    _weekCards[lst[j].Id] = card;
                    list.Children.Add(card);
                }
                if (lst.Count == 0)
                {
                    TextBlock empty = Ui.Lbl("无日程", 10.5, Color.FromArgb(110, 255, 255, 255));
                    empty.Margin = new Thickness(2, 8, 2, 2);
                    empty.TextAlignment = TextAlignment.Center;
                    empty.HorizontalAlignment = HorizontalAlignment.Center;
                    list.Children.Add(empty);
                }
            }
            UpdateWeekTarget();
            UpdateWeekSelectionVisuals();
        }

        void RebuildCalendar()
        {
            if (_calendarGrid == null) return;
            _calendarGrid.Children.Clear();

            DateTime first = _viewMonth;
            int lead = ((int)first.DayOfWeek + 6) % 7; // 周一=0
            DateTime start = first.AddDays(-lead);
            double cellW = _calendarGrid.ActualWidth > 10 ? _calendarGrid.ActualWidth / 7.0 : 46;
            double cellH = _calendarGrid.ActualHeight > 10 ? _calendarGrid.ActualHeight / 6.0 : 64;
            double avail = cellW - 10;

            for (int i = 0; i < 42; i++)
            {
                DateTime day = start.AddDays(i);
                Border cell = BuildDayCell(day, cellW, avail, cellH);
                Grid.SetRow(cell, i / 7);
                Grid.SetColumn(cell, i % 7);
                _calendarGrid.Children.Add(cell);
            }
        }

        Border BuildDayCell(DateTime day, double cellW, double avail, double cellH)
        {
            bool inMonth = (day.Year == _viewMonth.Year && day.Month == _viewMonth.Month);
            bool isToday = (day == DateTime.Today);
            bool isSelected = (day == _selected);
            string key = day.ToString(_dateFmt);
            List<ScheduleItem> items;
            _data.Schedules.TryGetValue(key, out items);

            Border cell = new Border();
            cell.Margin = new Thickness(1);
            cell.CornerRadius = new CornerRadius(8);
            cell.Cursor = Cursors.Hand;
            cell.Padding = new Thickness(4, 3, 4, 2);
            cell.Background = Brushes.Transparent;
            cell.MouseEnter += delegate { if (!isSelected) cell.Background = new SolidColorBrush(Color.FromArgb(16, 255, 255, 255)); };
            cell.MouseLeave += delegate { if (!isSelected) cell.Background = Brushes.Transparent; };
            string dstr = day.ToString("M月d日");
            cell.ToolTip = dstr;

            Grid g = new Grid();
            g.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(20) });
            g.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(15) });
            g.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1, GridUnitType.Star) });

            // 行0：日期数字（今天有强调底色）
            Grid numRow = new Grid();
            if (isToday)
            {
                Border numBg = new Border();
                numBg.Width = 22;
                numBg.Height = 20;
                numBg.HorizontalAlignment = HorizontalAlignment.Left;
                numBg.CornerRadius = new CornerRadius(10);
                numBg.Background = ColorUtil.Brush(_data.Settings.Accent);
                numRow.Children.Add(numBg);
            }
            TextBlock num = Ui.Lbl(day.Day.ToString(), 12,
                inMonth ? (isToday ? Colors.White : Color.FromArgb(235, 255, 255, 255))
                        : Color.FromArgb(110, 255, 255, 255),
                isSelected || isToday);
            num.HorizontalAlignment = HorizontalAlignment.Left;
            num.VerticalAlignment = VerticalAlignment.Center;
            if (isToday) num.Margin = new Thickness(3, 0, 0, 0);
            numRow.Children.Add(num);
            Grid.SetRow(numRow, 0);
            g.Children.Add(numRow);

            // 行1：农历
            LunarDate lu = Lunar.FromSolar(day);
            string luText = (lu.Day == 1 ? lu.MonthName : lu.DayName);
            if (isToday) luText = "今 " + luText;
            TextBlock lun = Ui.Lbl(luText, 9.5, Color.FromArgb(150, 255, 255, 255));
            lun.HorizontalAlignment = HorizontalAlignment.Left;
            lun.TextTrimming = TextTrimming.CharacterEllipsis;
            lun.MaxWidth = Math.Max(20, cellW - 8);
            Grid.SetRow(lun, 1);
            g.Children.Add(lun);

            // 行2：日程摘要（竖向排列；放不下时最后一个用强调色「…」）
            StackPanel chipRow = new StackPanel() { Orientation = Orientation.Vertical };
            chipRow.VerticalAlignment = VerticalAlignment.Top;
            if (items != null && items.Count > 0)
            {
                double chipH = 15;
                int maxRows = (int)Math.Max(1, Math.Floor((cellH - 42) / chipH));
                int shown = items.Count;
                bool more = false;
                if (items.Count > maxRows)
                {
                    shown = Math.Max(0, maxRows - 1);
                    more = true;
                }
                for (int k = 0; k < shown; k++)
                    chipRow.Children.Add(MakeChip(items[k], Math.Max(24, avail - 6)));
                if (more)
                {
                    Border m = new Border();
                    m.CornerRadius = new CornerRadius(6);
                    m.Height = 13;
                    m.Margin = new Thickness(0, 0, 0, 1);
                    m.Background = ColorUtil.Brush(_data.Settings.Accent);
                    TextBlock ml = Ui.Lbl("…", 9, Colors.White, true);
                    ml.TextAlignment = TextAlignment.Center;
                    ml.HorizontalAlignment = HorizontalAlignment.Center;
                    ml.VerticalAlignment = VerticalAlignment.Center;
                    m.Child = ml;
                    chipRow.Children.Add(m);
                }
                // 工具提示：该日完整日程
                string tip = "";
                foreach (ScheduleItem it in items)
                    tip += (string.IsNullOrEmpty(it.Time) ? "" : it.Time + "  ") + it.Text + "\n";
                cell.ToolTip = dstr + "\n" + tip.TrimEnd('\n');
            }
            Grid.SetRow(chipRow, 2);
            g.Children.Add(chipRow);

            cell.Child = g;

            // 选中高亮
            if (isSelected)
            {
                cell.Background = new SolidColorBrush(Color.FromArgb(30, 79, 140, 255));
                cell.BorderBrush = ColorUtil.Brush(_data.Settings.Accent);
                cell.BorderThickness = new Thickness(1.5);
            }

            DateTime selDay = day;
            cell.MouseLeftButtonUp += delegate { SelectDate(selDay); };
            return cell;
        }

        double ChipWidth(string text)
        {
            double ppd = VisualTreeHelper.GetDpi(this).PixelsPerDip;
            FormattedText ft = new FormattedText(
                Truncate(text, 6), CultureInfo.InvariantCulture,
                FlowDirection.LeftToRight, new Typeface(Ui.Font, FontStyles.Normal, FontWeights.Normal, FontStretches.Normal),
                10, Brushes.White, ppd);
            return ft.Width + 8;
        }

        string Truncate(string s, int max)
        {
            if (s == null) return "";
            if (s.Length <= max) return s;
            return s.Substring(0, max) + "…";
        }

        Border MakeChip(ScheduleItem it, double width)
        {
            Border b = new Border();
            b.CornerRadius = new CornerRadius(6);
            b.Background = ColorUtil.Brush(it.Color);
            b.Padding = new Thickness(4, 0, 4, 0);
            b.Height = 13;
            b.Margin = new Thickness(0, 0, 0, 1);
            b.HorizontalAlignment = HorizontalAlignment.Stretch;
            if (it.Done) b.Opacity = 0.42;
            TextBlock t = Ui.Lbl(Truncate(it.Text, 8), 9, Colors.White);
            t.TextTrimming = TextTrimming.CharacterEllipsis;
            t.MaxWidth = Math.Max(20, width);
            t.HorizontalAlignment = HorizontalAlignment.Left;
            t.VerticalAlignment = VerticalAlignment.Center;
            b.Child = t;
            return b;
        }

        void SelectDate(DateTime day)
        {
            _selected = day;
            _dateKey = day.ToString(_dateFmt);
            ClearCardSelection();
            RefreshAll();
        }

        // 清空日程/待办选中（切换日期或视图时调用）
        void ClearCardSelection()
        {
            _selSched.Clear();
            _selTodo.Clear();
            _selSubId = null;
        }

        // ================= 日程面板 =================
        Border BuildSchedulePanel()
        {
            Border panel = new Border();
            panel.Padding = new Thickness(12, 10, 12, 10);

            Grid g = new Grid();
            g.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
            g.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
            g.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1, GridUnitType.Star) });
            g.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });

            // 头部（与待办栏同高，保证两栏标题/列表水平对齐）
            StackPanel head = new StackPanel();
            head.Height = 66;
            head.VerticalAlignment = VerticalAlignment.Top;
            Grid hRow = new Grid();
            hRow.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1, GridUnitType.Star) });
            hRow.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
            StackPanel h1 = new StackPanel() { Orientation = Orientation.Horizontal };
            _scheduleTitle = Ui.Lbl("", 16, Colors.White, true);
            h1.Children.Add(_scheduleTitle);
            Border todayBadge = new Border();
            todayBadge.CornerRadius = new CornerRadius(8);
            todayBadge.Background = ColorUtil.Brush(_data.Settings.Accent);
            todayBadge.Padding = new Thickness(7, 1, 7, 1);
            todayBadge.Margin = new Thickness(10, 0, 0, 0);
            TextBlock tb = Ui.Lbl("今天", 10.5, Colors.White, true);
            tb.VerticalAlignment = VerticalAlignment.Center;
            todayBadge.Child = tb;
            todayBadge.VerticalAlignment = VerticalAlignment.Center;
            _todayBadge = todayBadge;
            h1.Children.Add(todayBadge);
            Grid.SetColumn(h1, 0);
            hRow.Children.Add(h1);
            // 日程栏专属「事项分类」下拉：只切换本栏列表，与待办栏互不影响
            Color sacc = ColorUtil.Parse(_data.Settings.Accent, Color.FromArgb(255, 79, 140, 255));
            Border schedPill = new Border();
            schedPill.CornerRadius = new CornerRadius(8);
            schedPill.Background = new SolidColorBrush(Color.FromArgb(64, sacc.R, sacc.G, sacc.B));
            schedPill.BorderBrush = new SolidColorBrush(Color.FromArgb(150, sacc.R, sacc.G, sacc.B));
            schedPill.BorderThickness = new Thickness(1);
            schedPill.Padding = new Thickness(12, 3, 12, 3);
            schedPill.Cursor = Cursors.Hand;
            schedPill.ToolTip = "日程分类筛选";
            TextBlock schedLbl = Ui.Lbl(_schedCatFilter, 11, Colors.White, true);
            AutomationProperties.SetName(schedLbl, "SchedCatPicker");
            schedPill.Child = schedLbl;
            schedPill.MouseLeftButtonUp += delegate
            {
                if (_data.Settings.ViewMode == "day") ShowCatPicker(schedPill);
                else ShowSchedCatPicker(schedPill);
            };
            _schedCatLabel = schedLbl;
            schedPill.VerticalAlignment = VerticalAlignment.Center;
            Grid.SetColumn(schedPill, 1);
            hRow.Children.Add(schedPill);
            head.Children.Add(hRow);

            _scheduleSub = Ui.Lbl("", 11, Color.FromArgb(150, 255, 255, 255));
            _scheduleSub.Margin = new Thickness(0, 3, 0, 0);
            head.Children.Add(_scheduleSub);

            _statusLine = Ui.Lbl("", 11.5, Color.FromArgb(210, 79, 140, 255));
            _statusLine.Margin = new Thickness(0, 2, 0, 0);
            head.Children.Add(_statusLine);
            Grid.SetRow(head, 0);
            g.Children.Add(head);

            // 列表
            ScrollViewer sv = new ScrollViewer();
            sv.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
            sv.HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
            sv.Margin = new Thickness(0, 6, 0, 0);
            _schedStack = new StackPanel();
            AutomationProperties.SetName(_schedStack, "SchedList");
            _schedStack.Background = Brushes.Transparent;
            _schedStack.MouseLeftButtonDown += delegate
            {
                if (_selSched.Count == 0) return;
                ClearCardSelection();
                RefreshAll();
            };
            sv.Content = _schedStack;
            Grid.SetRow(sv, 2);
            g.Children.Add(sv);

            // 输入区
            Grid input = new Grid();
            input.Margin = new Thickness(0, 8, 0, 0);
            input.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(76) });
            input.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1, GridUnitType.Star) });
            input.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(40) });

            _schedTime = Ui.TextInput("时间", OnSchedEnter, "SchedTime");
            if (_draftSchedTime.Length > 0) _schedTime.Text = _draftSchedTime; // 切换视图后保留未提交的时刻
            Grid.SetColumn(_schedTime, 0);
            Border tb1 = Ui.WrapInput(_schedTime);
            tb1.Margin = new Thickness(0, 0, 6, 0);
            Grid.SetColumn(tb1, 0);
            input.Children.Add(tb1);

            _schedText = Ui.TextInput("日程内容", OnSchedEnter, "SchedText");
            if (_draftSchedText.Length > 0) _schedText.Text = _draftSchedText; // 切换视图后保留未提交的文字
            Grid.SetColumn(_schedText, 1);
            Border tb2 = Ui.WrapInput(_schedText);
            tb2.Margin = new Thickness(0, 0, 6, 0);
            Grid.SetColumn(tb2, 1);
            input.Children.Add(tb2);

            Border add = MakeRoundPlus("+", "新增日程", delegate { AddSchedule(); }, "SchedAdd");
            Grid.SetColumn(add, 2);
            input.Children.Add(add);
            Grid.SetRow(input, 3);
            g.Children.Add(input);

            panel.Child = g;
            return panel;
        }

        TextBlock _scheduleTitle;
        TextBlock _scheduleSub;
        Border _todayBadge;

        void OnSchedEnter(object sender, RoutedEventArgs e)
        {
            AddSchedule();
        }

        void AddSchedule()
        {
            string text = _schedText.Text.Trim();
            string time = _schedTime.Text.Trim();
            if (text.Length == 0) { Flash("内容不能为空"); return; }
            if (time.Length > 0 && !Dialogs.IsValidTime(time))
            {
                Flash("时间格式应为 HH:mm（如 09:30）");
                return;
            }
            List<ScheduleItem> list = _data.DaySchedules(_selected);
            ScheduleItem it = new ScheduleItem();
            it.Id = Guid.NewGuid().ToString("N");
            it.Text = text;
            it.Time = time;
            it.Category = "日常";
            it.CustomColor = "";
            list.Add(it);
            _schedText.Clear();
            _schedTime.Clear();
            // 若选中日期不在当前显示的月份（点到上月/下月的格子），切到该月，保证新增日程能在日历中看到
            if (_selected.Year != _viewMonth.Year || _selected.Month != _viewMonth.Month)
                _viewMonth = new DateTime(_selected.Year, _selected.Month, 1);
            RefreshAll();
            RebuildCalendar();
            SaveSoon();
            _schedText.Focus();
        }

        void RebuildSchedule()
        {
            _dateKey = _selected.ToString(_dateFmt);
            bool isDay = (_data.Settings.ViewMode == "day");
            _scheduleTitle.Text = isDay
                ? _selected.ToString("yyyy年M月d日 ") + WeekCn(_selected)
                : _selected.ToString("M月d日 ") + WeekCn(_selected);
            _todayBadge.Visibility = (_selected == DateTime.Today) ? Visibility.Visible : Visibility.Collapsed;
            LunarDate lu = Lunar.FromSolar(_selected);
            _scheduleSub.Text = "农历 " + lu.Header;

            _schedStack.Children.Clear();
            List<ScheduleItem> list = _data.DaySchedules(_selected);
            if (_schedCatFilter != "全部")
            {
                List<ScheduleItem> flt = new List<ScheduleItem>();
                for (int i = 0; i < list.Count; i++)
                    if (list[i].Category == _schedCatFilter) flt.Add(list[i]);
                list = flt;
            }
            for (int i = 0; i < list.Count; i++)
            {
                _schedStack.Children.Add(MakeScheduleCard(list[i], i, list));
            }
            if (list.Count == 0)
            {
                TextBlock empty = Ui.Lbl("这一天还没有日程，输入内容并回车即可添加。", 12, Color.FromArgb(120, 255, 255, 255));
                empty.Margin = new Thickness(4, 14, 4, 4);
                _schedStack.Children.Add(empty);
            }
        }

        string WeekCn(DateTime d)
        {
            return new[] { "周日", "周一", "周二", "周三", "周四", "周五", "周六" }[(int)d.DayOfWeek];
        }

        // 点击卡片本体（非按钮/输入框）时选中；Ctrl 切换多选
        static bool IsWithinElement(DependencyObject src, DependencyObject target)
        {
            while (src != null)
            {
                if (ReferenceEquals(src, target)) return true;
                src = VisualTreeHelper.GetParent(src);
            }
            return false;
        }

        static bool IsCardControlSource(DependencyObject d)
        {
            int guard = 0;
            while (d != null && guard++ < 30)
            {
                TextBox tb = d as TextBox;
                if (tb != null) return !tb.IsReadOnly; // 只读文本（卡片标题）也能点中卡片
                if (d is ButtonBase || d is ScrollBar || d is Thumb) return true;
                d = VisualTreeHelper.GetParent(d);
            }
            return false;
        }

        void SelectScheduleCard(ScheduleItem it, bool ctrl)
        {
            if (!ctrl) _selSched.Clear();
            if (_selSched.Contains(it.Id)) { if (ctrl) _selSched.Remove(it.Id); }
            else _selSched.Add(it.Id);
            RebuildSchedule();
        }

        void SelectTodoCard(TodoItem it, bool ctrl)
        {
            if (!ctrl) _selTodo.Clear();
            if (_selTodo.Contains(it.Id)) { if (ctrl) _selTodo.Remove(it.Id); }
            else _selTodo.Add(it.Id);
            RebuildTodo();
        }

        Border MakeScheduleCard(ScheduleItem it, int index, List<ScheduleItem> list, bool weekCompact = false)
        {
            Border card = new Border();
            card.Margin = new Thickness(0, 4, 0, 4);
            card.CornerRadius = new CornerRadius(9);
            // 日程格子按事项分类颜色着色（与月视图日历彩色条目一致）
            Color cardCat = ColorUtil.Parse(it.Color, Color.FromArgb(255, 79, 140, 255));
            card.Background = new SolidColorBrush(Color.FromArgb((byte)(weekCompact ? 44 : 32), cardCat.R, cardCat.G, cardCat.B));
            card.BorderBrush = new SolidColorBrush(Color.FromArgb((byte)(weekCompact ? 120 : 95), cardCat.R, cardCat.G, cardCat.B));
            card.BorderThickness = new Thickness(1);
            card.Padding = new Thickness(9, 7, 7, 7);
            AutomationProperties.SetName(card, "SchedCard_" + it.Id);
            bool schedSel = _selSched.Contains(it.Id);
            if (schedSel)
            {
                card.BorderBrush = ColorUtil.Brush(_data.Settings.Accent);
                card.BorderThickness = new Thickness(2);
            }
            card.MouseLeftButtonDown += delegate(object s2, MouseButtonEventArgs e2)
            {
                if (IsCardControlSource(e2.OriginalSource as DependencyObject)) return;
                e2.Handled = true;
                SelectScheduleCard(it, (Keyboard.Modifiers & ModifierKeys.Control) != 0);
            };

            Grid g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(24) });
            g.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
            g.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1, GridUnitType.Star) });

            // 勾选
            Border chk = MakeCheck(it.Done, ColorUtil.Brush(_data.Settings.Accent));
            chk.VerticalAlignment = VerticalAlignment.Top;
            chk.Margin = new Thickness(0, 2, 0, 0);
            Grid.SetColumn(chk, 0);
            g.Children.Add(chk);

            // 时间（可含结束时间，显示为 开始–结束）；周视图（timeAbove）时置于文字上方而非左列
            Border tchip = null;
            if (!string.IsNullOrEmpty(it.Time))
            {
                tchip = new Border();
                tchip.CornerRadius = new CornerRadius(5);
                tchip.Background = new SolidColorBrush(Color.FromArgb(40, 79, 140, 255));
                tchip.Padding = new Thickness(5, 1, 5, 1);
                tchip.Margin = new Thickness(0, 1, 6, 0);
                tchip.VerticalAlignment = VerticalAlignment.Top;
                string t = it.Time;
                if (!string.IsNullOrEmpty(it.EndTime)) t += (weekCompact ? "–" : " – ") + it.EndTime;
                TextBox tl = Ui.SelectableText(t, weekCompact ? 10 : 11, Color.FromArgb(235, 180, 210, 255));
                if (weekCompact)
                {
                    // 周视图窄列：时间保持一行并收紧内边距，避免末位被裁掉
                    tl.TextWrapping = TextWrapping.NoWrap;
                    tchip.Padding = new Thickness(4, 1, 4, 1);
                }
                tchip.Child = tl;
                if (!weekCompact)
                {
                    Grid.SetColumn(tchip, 1);
                    g.Children.Add(tchip);
                }
            }

            // 文本（周视图窄列：有时间安排时，文字置于时间下方）
            StackPanel mid = new StackPanel();
            if (weekCompact && tchip != null)
            {
                tchip.HorizontalAlignment = HorizontalAlignment.Left;
                tchip.Margin = new Thickness(0, 0, 0, 4);
                mid.Children.Add(tchip);
            }
            TextBox txt = Ui.SelectableText(it.Text, 13, Colors.White, it.Bold);
            txt.Margin = new Thickness(0, 0, 0, it.Subtasks.Count > 0 ? 5 : 0);
            if (it.Done) txt.Opacity = 0.55;
            mid.Children.Add(txt);

            if (it.Subtasks.Count > 0)
            {
                for (int si = 0; si < it.Subtasks.Count; si++)
                    mid.Children.Add(MakeSubtaskRow(it, it.Subtasks[si], si, card, weekCompact));
            }
            if (_expandedSubs.Contains(it.Id))
                mid.Children.Add(SubtaskInputRow(it));

            Grid.SetColumn(mid, 2);
            g.Children.Add(mid);

            // 按钮行置于文字内容下方（回撤/复制/标签/子任务/移动/顺延/改/删）；周视图由底部统一操作行替代
            if (!weekCompact)
            {
                WrapPanel btns = new WrapPanel() { VerticalAlignment = VerticalAlignment.Top, HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 4, 0, 0) };
                btns.Children.Add(MakeRevertButton(it, index, list));
                btns.Children.Add(MakeCopyButton(it, index, list));
                btns.Children.Add(SmallColorDot(it, card));
                btns.Children.Add(MakeSubtaskButton(it));
                btns.Children.Add(MakeMoveButton(list, index, -1));
                btns.Children.Add(MakeMoveButton(list, index, 1));
                btns.Children.Add(MakeDeferButton(it, index, list));
                btns.Children.Add(MakeEditButton(it));
                btns.Children.Add(MakeDeleteButton(list, index));
                // 按钮行插入到文字内容下方（子任务之前）
                mid.Children.Insert(1, btns);
            }

            card.Child = g;

            // 事件
            chk.MouseLeftButtonUp += delegate
            {
                it.Done = !it.Done;
                RefreshAll();
                SaveSoon();
            };
            if (weekCompact) card.PreviewMouseLeftButtonDown += MakeWeekCardSelect(it.Id);
            return card;
        }

        // ---- 日程卡片操作按钮（月/日视图卡片与周视图底部操作行共用同一套逻辑） ----
        Button MakeRevertButton(ScheduleItem it, int index, List<ScheduleItem> list)
        {
            Button b = Ui.SmallButton("回撤", "移回待办栏（保留完成状态、分类、颜色与时间信息）");
            AutomationProperties.SetName(b, "BtnRevert" + it.Id);
            b.Click += delegate { DoRevertSchedule(it, index, list); };
            return b;
        }

        Button MakeCopyButton(ScheduleItem it, int index, List<ScheduleItem> list)
        {
            Button b = Ui.SmallButton("复制", "整体复制为新日程或新待办");
            AutomationProperties.SetName(b, "BtnCopy" + it.Id);
            b.Click += delegate { DoCopySchedule(it, index, list); };
            return b;
        }

        Button MakeSubtaskButton(ScheduleItem it)
        {
            Button b = Ui.SmallButton(it.Subtasks.Count > 0 ? "子任务(" + it.Subtasks.Count + ")" : "子任务", "添加/管理子任务");
            b.Click += delegate { ToggleSubtask(it.Id); };
            return b;
        }

        Button MakeMoveButton(List<ScheduleItem> list, int index, int dir)
        {
            Button b = Ui.SmallButton(dir < 0 ? "▲" : "▼", dir < 0 ? "上移" : "下移");
            b.Click += delegate { MoveSchedule(list, index, dir); };
            return b;
        }

        Button MakeDeferButton(ScheduleItem it, int index, List<ScheduleItem> list)
        {
            Button b = Ui.SmallButton("顺延", "顺延到下一个工作日（可反复顺延）");
            b.Click += delegate { DoDeferSchedule(it, index, list); };
            return b;
        }

        Button MakeEditButton(ScheduleItem it)
        {
            Button b = Ui.SmallButton("改", "修改内容/时间");
            b.Click += delegate { DoEditSchedule(it); };
            return b;
        }

        Button MakeDeleteButton(List<ScheduleItem> list, int index)
        {
            Button b = Ui.SmallButton("删", "删除该日程");
            b.Click += delegate { DoDeleteSchedule(list, index); };
            return b;
        }

        void DoRevertSchedule(ScheduleItem it, int index, List<ScheduleItem> list)
        {
            RevertSchedule(it, index, list);
        }

        void DoCopySchedule(ScheduleItem it, int index, List<ScheduleItem> list)
        {
            CopySchedule(it, index, list);
        }

        void DoDeferSchedule(ScheduleItem it, int index, List<ScheduleItem> list)
        {
            DateTime baseDate = DateOfSchedule(it);
            if (baseDate < DateTime.Today) baseDate = DateTime.Today;
            DateTime target = Monthly.NextWorkday(baseDate);
            List<ScheduleItem> targets = BatchSched(it, list);
            string msg = targets.Count > 1
                ? ("将选中的 " + targets.Count + " 条日程顺延到 " + target.ToString("M月d日 dddd") + "（下个工作日）？")
                : ("将「" + it.Text + "」从 " + baseDate.ToString("M月d日") + " 顺延到 " + target.ToString("M月d日 dddd") + "（下个工作日）？完成状态、分类、颜色、时间与子任务将保留。");
            if (Dialogs.Confirm(this, "顺延", msg))
            {
                for (int i = 0; i < targets.Count; i++)
                {
                    ScheduleItem t = targets[i];
                    foreach (KeyValuePair<string, List<ScheduleItem>> kv in _data.Schedules)
                    {
                        if (kv.Value.Remove(t))
                        {
                            if (kv.Value.Count == 0) { /* 保留空日期列表不影响显示 */ }
                            break;
                        }
                    }
                    _data.DaySchedules(target).Add(t);
                }
                ClearCardSelection();
                RefreshAll();
                SaveSoon();
                Flash("已顺延 " + targets.Count + " 条到 " + target.ToString("M月d日"));
            }
        }

        // 批量操作目标：若有多选则对所有选中的同列表项生效，否则只作用于当前项
        List<ScheduleItem> BatchSched(ScheduleItem it, List<ScheduleItem> list)
        {
            List<ScheduleItem> r = new List<ScheduleItem>();
            if (list != null)
                for (int i = 0; i < list.Count; i++)
                    if (list[i] != null && _selSched.Contains(list[i].Id)) r.Add(list[i]);
            if (r.Count == 0) r.Add(it);
            return r;
        }

        void DoEditSchedule(ScheduleItem it)
        {
            string t, tm;
            if (Dialogs.EditSchedule(this, "修改日程", it.Text, it.Time, out t, out tm))
            {
                List<ScheduleItem> targets = BatchSched(it, _data.DaySchedules(_selected));
                for (int i = 0; i < targets.Count; i++) { targets[i].Text = t; targets[i].Time = tm; }
                RefreshAll();
                SaveSoon();
            }
        }

        void DoDeleteSchedule(List<ScheduleItem> list, int index)
        {
            List<ScheduleItem> targets = BatchSched(list[index], list);
            string msg = targets.Count > 1 ? ("确定删除选中的 " + targets.Count + " 条日程吗？") : "确定删除该日程吗？";
            if (Dialogs.Confirm(this, "删除日程", msg))
            {
                for (int i = 0; i < targets.Count; i++) list.Remove(targets[i]);
                _selSched.Clear();
                RefreshAll();
                SaveSoon();
            }
        }

        void DoPickScheduleColor(ScheduleItem it)
        {
            string cat = Dialogs.PickCategory(this, it.Category, it.CustomColor);
            if (cat == null) return;
            if (cat == "自定义颜色" && !string.IsNullOrEmpty(Dialogs.CustomColorCache))
                it.CustomColor = Dialogs.CustomColorCache;
            it.Category = cat;
            RefreshAll();
            SaveSoon();
        }

        Border MakeCheck(bool done, Brush accent)
        {
            Border b = new Border();
            b.Width = 16;
            b.Height = 16;
            b.CornerRadius = new CornerRadius(5);
            b.BorderBrush = accent;
            b.BorderThickness = new Thickness(1.5);
            b.Cursor = Cursors.Hand;
            b.HorizontalAlignment = HorizontalAlignment.Left;
            // 未完成时也铺透明背景：Border 背景为 null 时内部不可命中，只有 1.5px 边框能点，
            // 导致复选框极难点中（用户反馈“勾选不灵”）。
            b.Background = Brushes.Transparent;
            if (done)
            {
                b.Background = accent;
                TextBlock v = Ui.Lbl("✓", 10.5, Colors.White, true);
                v.TextAlignment = TextAlignment.Center;
                v.HorizontalAlignment = HorizontalAlignment.Center;
                v.VerticalAlignment = VerticalAlignment.Center;
                b.Child = v;
            }
            return b;
        }

        Button SmallColorDot(ScheduleItem it, Border card)
        {
            Button b = Ui.SmallButton("●", "分类颜色：" + it.Category);
            b.Foreground = ColorUtil.Brush(it.Color);
            b.Click += delegate { DoPickScheduleColor(it); };
            return b;
        }

        void ToggleSubtask(string id)
        {
            if (_expandedSubs.Contains(id)) _expandedSubs.Remove(id);
            else _expandedSubs.Add(id);
            RefreshAll();
        }

        // 子任务选中时，底部「改 / 删」作用于该子任务
        bool TryEditSelectedSubtask(ScheduleItem it)
        {
            if (string.IsNullOrEmpty(_selSubId) || it == null || it.Subtasks == null) return false;
            for (int i = 0; i < it.Subtasks.Count; i++)
            {
                if (it.Subtasks[i].Id != _selSubId) continue;
                string r;
                if (Dialogs.EditText(this, "修改子任务", it.Subtasks[i].Text, out r))
                {
                    it.Subtasks[i].Text = r;
                    SaveSoon();
                    RefreshAll();
                }
                return true;
            }
            return false;
        }

        bool TryDeleteSelectedSubtask(ScheduleItem it)
        {
            if (string.IsNullOrEmpty(_selSubId) || it == null || it.Subtasks == null) return false;
            for (int i = 0; i < it.Subtasks.Count; i++)
            {
                if (it.Subtasks[i].Id != _selSubId) continue;
                if (Dialogs.Confirm(this, "删除子任务", "确定删除该子任务吗？"))
                {
                    it.Subtasks.RemoveAt(i);
                    _selSubId = null;
                    SaveSoon();
                    RefreshAll();
                }
                return true;
            }
            return false;
        }

        Border MakeSubtaskRow(ScheduleItem parent, SubtaskItem st, int index, Border card, bool weekCompact = false)
        {
            Border row = new Border();
            row.Margin = new Thickness(0, 2, 0, 2);
            row.Padding = new Thickness(6, 4, 4, 4);
            row.MinHeight = 24;
            row.CornerRadius = new CornerRadius(6);
            row.Background = new SolidColorBrush(Color.FromArgb(14, 255, 255, 255));
            if (_selSubId == st.Id)
            {
                row.BorderBrush = ColorUtil.Brush(_data.Settings.Accent);
                row.BorderThickness = new Thickness(1.5);
            }

            Grid g = new Grid();
            g.Background = Brushes.Transparent;
            g.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(20) });
            g.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });

            Border chk = MakeCheck(st.Done, ColorUtil.Brush(_data.Settings.Accent));
            chk.Width = 13;
            chk.Height = 13;
            chk.HorizontalAlignment = HorizontalAlignment.Left;
            chk.VerticalAlignment = VerticalAlignment.Center;
            Grid.SetColumn(chk, 0);
            g.Children.Add(chk);

            // 整行都是选中热区：用 Preview 事件，文字框与空白处都能点中
            row.PreviewMouseLeftButtonDown += delegate(object s2, MouseButtonEventArgs e2)
            {
                if (IsWithinElement(e2.OriginalSource as DependencyObject, chk)) return;
                if (IsCardControlSource(e2.OriginalSource as DependencyObject)) return;
                e2.Handled = true;
                _selSubId = (_selSubId == st.Id) ? null : st.Id;
                _selSched.Clear();
                _selSched.Add(parent.Id);
                RefreshAll();
            };

            TextBox txt = Ui.SelectableText(st.Text, 12, Color.FromArgb(225, 255, 255, 255));
            if (st.Done) txt.Opacity = 0.5;
            txt.VerticalAlignment = VerticalAlignment.Center;
            Grid.SetColumn(txt, 1);
            g.Children.Add(txt);

            // 周视图卡片不显示子任务的上移/下移/改/删（统一由底部操作行 + 子任务选中处理）
            if (!weekCompact)
            {
                StackPanel btns = new StackPanel() { Orientation = Orientation.Horizontal };
                Button up = Ui.SmallButton("▲", "上移");
                up.Click += delegate { MoveSubtask(parent, index, -1); };
                btns.Children.Add(up);
                Button down = Ui.SmallButton("▼", "下移");
                down.Click += delegate { MoveSubtask(parent, index, 1); };
                btns.Children.Add(down);
                Button edit = Ui.SmallButton("改", "修改子任务");
                edit.Click += delegate
                {
                    string r;
                    if (Dialogs.EditText(this, "修改子任务", st.Text, out r))
                    {
                        st.Text = r;
                        RefreshAll();
                        SaveSoon();
                    }
                };
                btns.Children.Add(edit);
                Button del = Ui.SmallButton("删", "删除子任务");
                del.Click += delegate
                {
                    parent.Subtasks.RemoveAt(index);
                    RefreshAll();
                    SaveSoon();
                };
                btns.Children.Add(del);
                Grid.SetColumn(btns, 2);
                g.Children.Add(btns);
            }

            row.Child = g;
            chk.MouseLeftButtonUp += delegate
            {
                st.Done = !st.Done;
                RefreshAll();
                SaveSoon();
            };
            return row;
        }

        Border SubtaskInputRow(ScheduleItem parent)
        {
            Grid g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(20) });
            g.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(28) });

            TextBox box = Ui.TextInput("添加子任务…", null, "SubInput");
            box.Height = 26;
            Border wrap = Ui.WrapInput(box);
            wrap.Margin = new Thickness(0, 2, 0, 2);
            Grid.SetColumn(wrap, 1);
            g.Children.Add(wrap);

            Border add = new Border();
            add.Background = ColorUtil.Brush(_data.Settings.Accent);
            add.CornerRadius = new CornerRadius(5);
            add.ClipToBounds = true;
            add.Cursor = Cursors.Hand;
            TextBlock addTxt = Ui.Lbl("+", 13, Colors.White, true);
            addTxt.HorizontalAlignment = HorizontalAlignment.Center;
            addTxt.VerticalAlignment = VerticalAlignment.Center;
            addTxt.Margin = new Thickness(0, 0, 0, 2);
            add.Child = addTxt;
            Grid.SetColumn(add, 2);
            g.Children.Add(add);

            Border row = new Border();
            row.Child = g;

            Action addSub = delegate
            {
                string t = box.Text.Trim();
                if (t.Length == 0) return;
                parent.Subtasks.Add(new SubtaskItem(Guid.NewGuid().ToString("N"), t));
                RefreshAll();
                SaveSoon();
            };
            add.MouseLeftButtonUp += delegate { addSub(); };
            box.KeyDown += delegate(object s, KeyEventArgs e)
            {
                if (e.Key == Key.Enter) { e.Handled = true; addSub(); }
            };
            return row;
        }

        void MoveSchedule(List<ScheduleItem> list, int index, int dir)
        {
            int target = index + dir;
            if (target < 0 || target >= list.Count) return;
            ScheduleItem tmp = list[index];
            list[index] = list[target];
            list[target] = tmp;
            RefreshAll();
            SaveSoon();
        }

        void MoveSubtask(ScheduleItem parent, int index, int dir)
        {
            int target = index + dir;
            if (target < 0 || target >= parent.Subtasks.Count) return;
            SubtaskItem tmp = parent.Subtasks[index];
            parent.Subtasks[index] = parent.Subtasks[target];
            parent.Subtasks[target] = tmp;
            RefreshAll();
            SaveSoon();
        }

        // ================= 待办面板 =================
        Border BuildTodoPanel()
        {
            if (_notesMode) return BuildNotesPanel(true); // 月/周待办箱切到备忘录
            Border panel = new Border();
            panel.Padding = new Thickness(12, 10, 6, 10); // 右侧留白收窄，待办卡片尽量贴右边缘

            Grid g = new Grid();
            g.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
            g.RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1, GridUnitType.Star) });
            g.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });

            Grid head = new Grid();
            head.Height = 66; // 与日程栏同高，保证两栏标题/列表水平对齐
            head.VerticalAlignment = VerticalAlignment.Top;
            head.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1, GridUnitType.Star) });
            head.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
            StackPanel hsp = new StackPanel();
            StackPanel hrow = new StackPanel() { Orientation = Orientation.Horizontal };
            _todoHeader = Ui.Lbl("待办", 16, Colors.White, true);
            AutomationProperties.SetName(_todoHeader, "TodoHeader");
            hrow.Children.Add(_todoHeader);
            _todoCount = Ui.Lbl("0", 16, Colors.White, true);
            _todoCount.Margin = new Thickness(6, 0, 0, 0);
            _todoCount.Foreground = ColorUtil.Brush(_data.Settings.Accent);
            AutomationProperties.SetName(_todoCount, "TodoCount");
            hrow.Children.Add(_todoCount);
            hsp.Children.Add(hrow);
            _todoHint = Ui.Lbl("安排到：--", 11, Color.FromArgb(150, 255, 255, 255));
            _todoHint.Margin = new Thickness(0, 3, 0, 0);
            hsp.Children.Add(_todoHint);
            Grid.SetColumn(hsp, 0);
            head.Children.Add(hsp);
            // 事项分类下拉（全部/待办/备忘录/分类…）：月/周/日视图统一使用，日视图仅此一个入口
            if (true)
            {
                Color acc = ColorUtil.Parse(_data.Settings.Accent, Color.FromArgb(255, 79, 140, 255));
                Border pill = new Border();
                pill.CornerRadius = new CornerRadius(8);
                pill.Background = new SolidColorBrush(Color.FromArgb(64, acc.R, acc.G, acc.B));
                pill.BorderBrush = new SolidColorBrush(Color.FromArgb(150, acc.R, acc.G, acc.B));
                pill.BorderThickness = new Thickness(1);
                pill.Padding = new Thickness(12, 3, 12, 3);
                pill.Cursor = Cursors.Hand;
                pill.ToolTip = "事项分类：待办 / 备忘录 / 分类筛选";
                pill.Tag = "nodrag";
                TextBlock pillLbl = Ui.Lbl(_notesMode ? "备忘录" : _catFilterVal, 11, Colors.White, true);
                AutomationProperties.SetName(pillLbl, "TodoCatPicker");
                pill.Child = pillLbl;
                pill.MouseLeftButtonUp += delegate
                {
                    ShowCatPicker(pill);
                };
                pill.VerticalAlignment = VerticalAlignment.Top;
                Grid.SetColumn(pill, 1);
                head.Children.Add(pill);
            }
            Grid.SetRow(head, 0);
            g.Children.Add(head);

            ScrollViewer sv = new ScrollViewer();
            sv.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
            sv.HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
            sv.Margin = new Thickness(0, 6, 0, 0);
            _todoStack = new StackPanel();
            AutomationProperties.SetName(_todoStack, "TodoList");
            _todoStack.Background = Brushes.Transparent;
            _todoStack.MouseLeftButtonDown += delegate
            {
                if (_selTodo.Count == 0) return;
                ClearCardSelection();
                RefreshAll();
            };
            sv.Content = _todoStack;
            Grid.SetRow(sv, 1);
            g.Children.Add(sv);

            Grid input = new Grid();
            input.Margin = new Thickness(0, 8, 0, 0);
            input.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1, GridUnitType.Star) });
            input.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(40) });

            _todoText = Ui.TextInput("添加待办", OnTodoEnter, "TodoText");
            if (_draftTodoText.Length > 0) _todoText.Text = _draftTodoText; // 切换视图后保留未提交的文字
            Grid.SetColumn(_todoText, 0);
            Border tb = Ui.WrapInput(_todoText);
            tb.Margin = new Thickness(0, 0, 6, 0);
            Grid.SetColumn(tb, 0);
            input.Children.Add(tb);

            Border add = MakeRoundPlus("+", "新增待办", delegate { AddTodo(); }, "TodoAdd");
            Grid.SetColumn(add, 1);
            input.Children.Add(add);
            Grid.SetRow(input, 2);
            g.Children.Add(input);

            panel.Child = g;
            return panel;
        }

        void OnTodoEnter(object sender, RoutedEventArgs e)
        {
            AddTodo();
        }

        void AddTodo()
        {
            string text = _todoText.Text.Trim();
            if (text.Length == 0) { Flash("内容不能为空"); return; }
            TodoItem t = new TodoItem();
            t.Id = Guid.NewGuid().ToString("N");
            t.Text = text;
            t.Category = "日常";
            t.CustomColor = "";
            _data.Todos.Add(t);
            _todoText.Clear();
            RefreshAll();
            SaveSoon();
            _todoText.Focus();
        }

        void RebuildTodo()
        {
            if (_todoStack == null || _todoHeader == null) return; // 周视图无待办面板时安全跳过
            // 待办数量用强调色显示（按当前分类筛选后的数量）
            List<TodoItem> shown = new List<TodoItem>();
            for (int i = 0; i < _data.Todos.Count; i++)
            {
                TodoItem t = _data.Todos[i];
                if (_catFilterVal != "全部" && _catFilterVal != "待办" && t.Category != _catFilterVal) continue;
                shown.Add(t);
            }
            _todoCount.Text = shown.Count.ToString();
            string hint = "安排到：" + _selected.ToString("M月d日") + " " + WeekCn(_selected);
            _todoHint.Text = hint;

            _todoStack.Children.Clear();
            for (int i = 0; i < _data.Todos.Count; i++)
            {
                TodoItem t = _data.Todos[i];
                if (_catFilterVal != "全部" && _catFilterVal != "待办" && t.Category != _catFilterVal) continue;
                _todoStack.Children.Add(MakeTodoCard(t, i));
            }
            if (shown.Count == 0)
            {
                TextBlock empty = Ui.Lbl(_catFilterVal != "全部" && _catFilterVal != "待办"
                    ? "该分类下暂无待办。"
                    : "暂无待办。输入内容回车添加；点“安排”弹出日历选择日期并安排为日程。", 12, Color.FromArgb(120, 255, 255, 255));
                empty.Margin = new Thickness(4, 14, 4, 4);
                empty.TextWrapping = TextWrapping.Wrap;
                _todoStack.Children.Add(empty);
            }
        }

        // 日程栏专属分类下拉：只重建日程列表，不影响待办栏；弹窗贴着按钮显示
        void ShowSchedCatPicker(FrameworkElement anchor)
        {
            List<string> items = new List<string>();
            items.Add("全部");
            for (int i = 0; i < Cats.Names.Length - 1; i++)
                if (CategoryVisible(Cats.Names[i])) items.Add(Cats.Names[i]);
            for (int i = 0; i < _data.Settings.Categories.Count; i++)
                if (CategoryVisible(_data.Settings.Categories[i]) && !items.Contains(_data.Settings.Categories[i]))
                    items.Add(_data.Settings.Categories[i]);
            int shownRows = Math.Min(items.Count, 10);
            DialogHost d = new DialogHost(this, "日程分类", 240, shownRows * 38 + 96);
            if (anchor != null) d.PlaceNear(anchor);
            StackPanel sp = new StackPanel();
            for (int i = 0; i < items.Count; i++)
            {
                string it = items[i];
                Border rb = new Border();
                rb.Padding = new Thickness(12, 7, 12, 7);
                rb.Cursor = Cursors.Hand;
                rb.Margin = new Thickness(0, 1, 0, 1);
                bool cur = it == _schedCatFilter;
                if (cur) rb.Background = new SolidColorBrush(Color.FromArgb(36, 79, 140, 255));
                StackPanel rowSp = new StackPanel() { Orientation = Orientation.Horizontal };
                Border dot = new Border();
                dot.Width = 10; dot.Height = 10; dot.CornerRadius = new CornerRadius(5);
                dot.Margin = new Thickness(0, 0, 8, 0);
                dot.VerticalAlignment = VerticalAlignment.Center;
                dot.Background = (it == "全部")
                    ? new SolidColorBrush(Color.FromArgb(90, 255, 255, 255))
                    : ColorUtil.Brush(Cats.ColorOf(it, ""));
                rowSp.Children.Add(dot);
                TextBlock t = Ui.Lbl(it, 12, cur ? Color.FromArgb(255, 120, 180, 255) : Color.FromArgb(230, 255, 255, 255));
                rowSp.Children.Add(t);
                rb.Child = rowSp;
                string sel = it;
                // 单击=筛选（延时可让双击生效）；双击=重命名分类
                System.Windows.Threading.DispatcherTimer stimer = null;
                rb.MouseLeftButtonUp += delegate(object s2, MouseButtonEventArgs e2)
                {
                    if (e2.ClickCount > 1) return;
                    if (stimer != null) stimer.Stop();
                    string picked = sel;
                    stimer = new System.Windows.Threading.DispatcherTimer();
                    stimer.Interval = TimeSpan.FromMilliseconds(240);
                    stimer.Tick += delegate(object s3, EventArgs e3)
                    {
                        stimer.Stop();
                        _schedCatFilter = picked;
                        if (_schedCatLabel != null) _schedCatLabel.Text = picked;
                        d.Close();
                        RebuildSchedule();
                    };
                    stimer.Start();
                };
                rb.MouseLeftButtonDown += delegate(object s2, MouseButtonEventArgs e2)
                {
                    if (e2.ClickCount != 2) return;
                    if (stimer != null) stimer.Stop();
                    e2.Handled = true;
                    _pendingRename = sel;
                    d.Close();
                };
                sp.Children.Add(rb);
            }
            d.Body.Children.Add(sp);
            d.ShowDialog();
            if (_pendingRename != null)
            {
                string pending = _pendingRename;
                _pendingRename = null;
                RenameCategory(pending);
            }
        }

        // 周视图待办浮窗专属分类下拉：只重建浮窗内容，不触碰主窗口
        void ShowFloatCatPicker(FrameworkElement anchor)
        {
            List<string> items = new List<string>();
            items.Add("全部");
            items.Add("待办");
            items.Add("备忘录");
            for (int i = 0; i < _data.Settings.Categories.Count; i++)
                if (!items.Contains(_data.Settings.Categories[i])) items.Add(_data.Settings.Categories[i]);
            int shownRows = Math.Min(items.Count, 10);
            DialogHost d;
            try
            {
                d = new DialogHost(_todoFloatWin != null ? (Window)_todoFloatWin : (Window)this, "待办分类", 240, shownRows * 38 + 96);
                if (anchor != null) d.PlaceNear(anchor);
            }
            catch (Exception)
            {
                return;
            }
            StackPanel sp = new StackPanel();
            for (int i = 0; i < items.Count; i++)
            {
                string it = items[i];
                Border rb = new Border();
                rb.Padding = new Thickness(12, 7, 12, 7);
                rb.Cursor = Cursors.Hand;
                rb.Margin = new Thickness(0, 1, 0, 1);
                bool cur = _notesMode ? (it == "备忘录") : (it == _catFilterVal);
                if (cur) rb.Background = new SolidColorBrush(Color.FromArgb(36, 79, 140, 255));
                StackPanel rowSp = new StackPanel() { Orientation = Orientation.Horizontal };
                Border dot = new Border();
                dot.Width = 10; dot.Height = 10; dot.CornerRadius = new CornerRadius(5);
                dot.Margin = new Thickness(0, 0, 8, 0);
                dot.VerticalAlignment = VerticalAlignment.Center;
                dot.Background = (it == "全部" || it == "待办" || it == "备忘录")
                    ? new SolidColorBrush(Color.FromArgb(90, 255, 255, 255))
                    : ColorUtil.Brush(Cats.ColorOf(it, ""));
                rowSp.Children.Add(dot);
                TextBlock t = Ui.Lbl(it, 12, cur ? Color.FromArgb(255, 120, 180, 255) : Color.FromArgb(230, 255, 255, 255));
                rowSp.Children.Add(t);
                rb.Child = rowSp;
                string sel = it;
                rb.MouseLeftButtonUp += delegate
                {
                    _notesMode = (sel == "备忘录");
                    if (!_notesMode) _catFilterVal = sel;
                    d.Close();
                    RefreshTodoFloat();
                };
                sp.Children.Add(rb);
            }
            d.Body.Children.Add(sp);
            d.ShowDialog();
        }

        void RefreshTodoFloat()
        {
            if (_todoFloatBorder == null) return;
            _buildingTodoFloat = true;
            _todoFloatBorder.Child = BuildTodoPanel();
            _buildingTodoFloat = false;
            RebuildTodo();
        }

        Border MakeTodoCard(TodoItem it, int index)
        {
            Border card = new Border();
            card.Margin = new Thickness(0, 4, 0, 4);
            card.CornerRadius = new CornerRadius(9);
            // 待办格子与日程一致，按事项分类颜色着色
            Color tc = ColorUtil.Parse(it.Color, Color.FromArgb(255, 79, 140, 255));
            card.Background = new SolidColorBrush(Color.FromArgb(30, tc.R, tc.G, tc.B));
            card.BorderBrush = new SolidColorBrush(Color.FromArgb(90, tc.R, tc.G, tc.B));
            card.BorderThickness = new Thickness(1);
            card.Padding = new Thickness(9, 7, 7, 7);
            AutomationProperties.SetName(card, "TodoCard_" + it.Id);
            if (_selTodo.Contains(it.Id))
            {
                card.BorderBrush = ColorUtil.Brush(_data.Settings.Accent);
                card.BorderThickness = new Thickness(2);
            }
            card.MouseLeftButtonDown += delegate(object s2, MouseButtonEventArgs e2)
            {
                if (IsCardControlSource(e2.OriginalSource as DependencyObject)) return;
                e2.Handled = true;
                SelectTodoCard(it, (Keyboard.Modifiers & ModifierKeys.Control) != 0);
            };

            Grid g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(24) });
            g.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1, GridUnitType.Star) });

            Border chk = MakeCheck(it.Done, ColorUtil.Brush(_data.Settings.Accent));
            chk.VerticalAlignment = VerticalAlignment.Top;
            chk.Margin = new Thickness(0, 2, 0, 0);
            Grid.SetColumn(chk, 0);
            g.Children.Add(chk);

            StackPanel mid = new StackPanel();
            TextBox txt = Ui.SelectableText(it.Text, 13, Colors.White, it.Bold);
            txt.TextWrapping = TextWrapping.Wrap; // 长文本换行，避免把卡片撑出待办栏
            txt.VerticalAlignment = VerticalAlignment.Top;
            if (it.Done) txt.Opacity = 0.55;
            mid.Children.Add(txt);
            // 回撤自日程的待办显示原安排日期/时间
            if (!string.IsNullOrEmpty(it.Date))
            {
                string hintTxt = "";
                DateTime dt;
                if (DateTime.TryParseExact(it.Date, "yyyy-MM-dd", CultureInfo.InvariantCulture,
                        DateTimeStyles.None, out dt))
                {
                    hintTxt = "安排于 " + dt.ToString("M月d日");
                    if (!string.IsNullOrEmpty(it.Time))
                    {
                        hintTxt += " " + it.Time;
                        if (!string.IsNullOrEmpty(it.EndTime)) hintTxt += " – " + it.EndTime;
                    }
                }
                if (hintTxt.Length > 0)
                {
                    TextBox hint = Ui.SelectableText(hintTxt, 10.5, Color.FromArgb(150, 180, 210, 255));
                    hint.Margin = new Thickness(0, 2, 0, 0);
                    mid.Children.Add(hint);
                }
            }
            // 回撤自日程的待办保留子任务时，显示进度提示
            if (it.Subtasks != null && it.Subtasks.Count > 0)
            {
                int subDone = 0;
                for (int si = 0; si < it.Subtasks.Count; si++) if (it.Subtasks[si].Done) subDone++;
                TextBox subHint = Ui.SelectableText("子任务 " + subDone + "/" + it.Subtasks.Count, 10.5, Color.FromArgb(150, 180, 210, 255));
                subHint.Margin = new Thickness(0, 2, 0, 0);
                mid.Children.Add(subHint);
            }
            Grid.SetColumn(mid, 1);
            g.Children.Add(mid);

            // 按钮行置于文字内容下方（复制/安排/标签/移动/改/删）
            WrapPanel btns = new WrapPanel() { VerticalAlignment = VerticalAlignment.Top, HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 4, 0, 0) };
            Button copy = Ui.SmallButton("复制", "整体复制为新待办或新日程");
            AutomationProperties.SetName(copy, "BtnCopyTodo" + it.Id);
            copy.Click += delegate { CopyTodo(it, index); };
            btns.Children.Add(copy);
            Button arrange = Ui.SmallButton("安排", "弹出日历选择日期，将该待办安排为日程");
            arrange.Foreground = ColorUtil.Brush(_data.Settings.Accent);
            arrange.Click += delegate { ArrangeTodo(it, index); };
            btns.Children.Add(arrange);
            Button catBtn = TodoColorDot(it, card);
            btns.Children.Add(catBtn);
            Button up = Ui.SmallButton("▲", "上移");
            up.Click += delegate { MoveTodo(index, -1); };
            btns.Children.Add(up);
            Button down = Ui.SmallButton("▼", "下移");
            down.Click += delegate { MoveTodo(index, 1); };
            btns.Children.Add(down);
            Button edit = Ui.SmallButton("改", "修改内容");
            edit.Click += delegate
            {
                string r;
                if (Dialogs.EditText(this, "修改待办", it.Text, out r))
                {
                    List<TodoItem> targets = new List<TodoItem>();
                    for (int i = 0; i < _data.Todos.Count; i++)
                        if (_data.Todos[i] != null && _selTodo.Contains(_data.Todos[i].Id)) targets.Add(_data.Todos[i]);
                    if (targets.Count == 0) targets.Add(it);
                    for (int i = 0; i < targets.Count; i++) targets[i].Text = r;
                    RefreshAll();
                    SaveSoon();
                }
            };
            btns.Children.Add(edit);
            Button del = Ui.SmallButton("删", "删除待办");
            del.Click += delegate
            {
                List<TodoItem> targets = new List<TodoItem>();
                for (int i = 0; i < _data.Todos.Count; i++)
                    if (_data.Todos[i] != null && _selTodo.Contains(_data.Todos[i].Id)) targets.Add(_data.Todos[i]);
                if (targets.Count == 0) targets.Add(it);
                string msg = targets.Count > 1 ? ("确定删除选中的 " + targets.Count + " 项待办吗？") : "确定删除该待办吗？";
                if (Dialogs.Confirm(this, "删除待办", msg))
                {
                    for (int i = 0; i < targets.Count; i++) _data.Todos.Remove(targets[i]);
                    ClearCardSelection();
                    RefreshAll();
                    SaveSoon();
                }
            };
            btns.Children.Add(del);
            mid.Children.Add(btns);

            card.Child = g;
            chk.MouseLeftButtonUp += delegate
            {
                it.Done = !it.Done;
                RefreshAll();
                SaveSoon();
            };
            return card;
        }

        Button TodoColorDot(TodoItem it, Border card)
        {
            Button b = Ui.SmallButton("●", "分类颜色：" + it.Category);
            b.Foreground = ColorUtil.Brush(it.Color);
            b.Click += delegate
            {
                string cat = Dialogs.PickCategory(this, it.Category, it.CustomColor);
                if (cat == null) return;
                if (cat == "自定义颜色" && !string.IsNullOrEmpty(Dialogs.CustomColorCache))
                    it.CustomColor = Dialogs.CustomColorCache;
                it.Category = cat;
                RefreshAll();
                SaveSoon();
            };
            return b;
        }

        void MoveTodo(int index, int dir)
        {
            int target = index + dir;
            if (target < 0 || target >= _data.Todos.Count) return;
            TodoItem tmp = _data.Todos[index];
            _data.Todos[index] = _data.Todos[target];
            _data.Todos[target] = tmp;
            RefreshAll();
            SaveSoon();
        }

        // 安排：待办 -> 先选开始/结束日期，再选重复方式与次数，把待办展开到这些日期（与周视图“安排”能力一致）
        void ArrangeTodo(TodoItem it, int index)
        {
            ShowArrangeCalendar("安排待办", delegate(DateTime start, DateTime end, string repeat, int count)
            {
                ArrangeTodoToDates(it, index, BuildArrangeDates(start, end, repeat, count));
            });
        }

        void ArrangeTodoToDates(TodoItem it, int index, List<DateTime> dates)
        {
            if (dates == null || dates.Count == 0) return;
            // 多选时把同一套安排应用到所有选中的待办
            List<TodoItem> targets = new List<TodoItem>();
            for (int i = 0; i < _data.Todos.Count; i++)
                if (_data.Todos[i] != null && _selTodo.Contains(_data.Todos[i].Id)) targets.Add(_data.Todos[i]);
            if (targets.Count == 0) targets.Add(it);
            for (int t = 0; t < targets.Count; t++)
            {
                TodoItem todo = targets[t];
                for (int i = 0; i < dates.Count; i++)
                {
                    ScheduleItem s = new ScheduleItem();
                    s.Id = Guid.NewGuid().ToString("N");
                    s.Text = todo.Text;
                    s.Time = string.IsNullOrEmpty(todo.Time) ? "" : todo.Time;
                    s.EndTime = string.IsNullOrEmpty(todo.EndTime) ? "" : todo.EndTime;
                    s.Done = todo.Done;
                    s.Category = todo.Category;
                    s.CustomColor = todo.CustomColor;
                    s.Subtasks = SubtaskItem.CloneAll(todo.Subtasks);
                    _data.DaySchedules(dates[i]).Add(s);
                }
                _data.Todos.Remove(todo);
            }
            ClearCardSelection();
            RefreshAll();
            SaveSoon();
            Flash("已安排 " + targets.Count + " 项 × " + dates.Count + " 天（" + dates[0].ToString("M月d日") + " 起）");
        }

        // 定位某日程当前所在日期（跨日期列表安全查找）
        DateTime DateOfSchedule(ScheduleItem it)
        {
            foreach (KeyValuePair<string, List<ScheduleItem>> kv in _data.Schedules)
                for (int i = 0; i < kv.Value.Count; i++)
                    if (kv.Value[i] == it)
                    {
                        DateTime dt;
                        if (DateTime.TryParseExact(kv.Key, "yyyy-MM-dd", CultureInfo.InvariantCulture,
                                DateTimeStyles.None, out dt))
                            return dt;
                    }
            return _selected;
        }

        // 回撤：日程 -> 待办栏（保留文字、完成状态、分类、颜色、原日期与时间）
        void RevertSchedule(ScheduleItem it, int index, List<ScheduleItem> list)
        {
            DateTime srcDate = DateOfSchedule(it);
            List<ScheduleItem> targets = BatchSched(it, list);
            string msg = targets.Count > 1
                ? ("将选中的 " + targets.Count + " 条日程移回待办栏？完成状态、分类、颜色与时间信息将保留。")
                : ("将「" + it.Text + "」从 " + srcDate.ToString("M月d日") + " 移回待办栏？完成状态、分类、颜色与时间信息将保留。");
            if (!Dialogs.Confirm(this, "回撤为待办", msg)) return;
            for (int k = 0; k < targets.Count; k++)
            {
                ScheduleItem s = targets[k];
                DateTime d = DateOfSchedule(s);
                foreach (KeyValuePair<string, List<ScheduleItem>> kv in _data.Schedules)
                    if (kv.Value.Remove(s)) break;
                TodoItem t = new TodoItem();
                t.Id = Guid.NewGuid().ToString("N");
                t.Text = s.Text;
                t.Done = s.Done;
                t.Category = s.Category;
                t.CustomColor = s.CustomColor;
                t.Date = d.ToString("yyyy-MM-dd");
                t.Time = s.Time;
                t.EndTime = s.EndTime;
                t.Subtasks = SubtaskItem.CloneAll(s.Subtasks);
                _data.Todos.Add(t);
            }
            ClearCardSelection();
            RefreshAll();
            SaveSoon();
            Flash("已回撤 " + targets.Count + " 条到待办栏");
        }

        // 复制：日程 -> 新日程（同日期）或 新待办（含日期/时间标签）
        void CopySchedule(ScheduleItem it, int index, List<ScheduleItem> list)
        {
            string target;
            if (!Dialogs.PickCopyTarget(this, "复制日程", out target)) return;
            List<ScheduleItem> targets = BatchSched(it, list);
            for (int k = 0; k < targets.Count; k++)
            {
                ScheduleItem src = targets[k];
                if (target == "todo")
                {
                    TodoItem t = new TodoItem();
                    t.Id = Guid.NewGuid().ToString("N");
                    t.Text = src.Text;
                    t.Done = src.Done;
                    t.Category = src.Category;
                    t.CustomColor = src.CustomColor;
                    t.Date = DateOfSchedule(src).ToString("yyyy-MM-dd");
                    t.Time = src.Time;
                    t.EndTime = src.EndTime;
                    t.Subtasks = SubtaskItem.CloneAll(src.Subtasks);
                    _data.Todos.Add(t);
                }
                else
                {
                    ScheduleItem c = src.Clone();
                    c.Id = Guid.NewGuid().ToString("N");
                    List<ScheduleItem> dl = _data.DaySchedules(DateOfSchedule(src));
                    dl.Add(c);
                }
            }
            RefreshAll();
            SaveSoon();
            Flash("已复制 " + targets.Count + " 条为" + (target == "todo" ? "待办" : "新日程"));
        }

        // 复制：待办 -> 新待办 或 新日程（到当前选中日期，携带时间标签）
        void CopyTodo(TodoItem it, int index)
        {
            string target;
            if (!Dialogs.PickCopyTarget(this, "复制待办", out target)) return;
            List<TodoItem> targets = new List<TodoItem>();
            for (int i = 0; i < _data.Todos.Count; i++)
                if (_data.Todos[i] != null && _selTodo.Contains(_data.Todos[i].Id)) targets.Add(_data.Todos[i]);
            if (targets.Count == 0) targets.Add(it);
            for (int k = 0; k < targets.Count; k++)
            {
                TodoItem src = targets[k];
                if (target == "todo")
                {
                    TodoItem c = new TodoItem();
                    c.Id = Guid.NewGuid().ToString("N");
                    c.Text = src.Text;
                    c.Done = src.Done;
                    c.Category = src.Category;
                    c.CustomColor = src.CustomColor;
                    c.Date = src.Date;
                    c.Time = src.Time;
                    c.EndTime = src.EndTime;
                    c.Subtasks = SubtaskItem.CloneAll(src.Subtasks);
                    _data.Todos.Add(c);
                }
                else
                {
                    ScheduleItem s = new ScheduleItem();
                    s.Id = Guid.NewGuid().ToString("N");
                    s.Text = src.Text;
                    s.Time = src.Time;
                    s.EndTime = src.EndTime;
                    s.Done = src.Done;
                    s.Category = src.Category;
                    s.CustomColor = src.CustomColor;
                    s.Subtasks = SubtaskItem.CloneAll(src.Subtasks);
                    _data.DaySchedules(_selected).Add(s);
                }
            }
            RefreshAll();
            SaveSoon();
            Flash("已复制 " + targets.Count + " 项");
        }

        // ================= 统一刷新 =================
        void RefreshAll()
        {
            if (!IsLoaded) return;
            string mode = _data.Settings.ViewMode;
            if (mode == "week")
            {
                _monthLabel.Text = _viewWeek.Year + "年" + _viewWeek.Month + "月";
                RebuildWeekCalendar();
                RebuildWeekColumns();
                UpdateWeekDividers();
                RebuildTodo(); // 周视图待办浮窗打开时联动刷新（无浮窗时仅重建残留列表，无界面影响）
            }
            else if (mode == "day")
            {
                _monthLabel.Text = _viewMonth.Year + "年" + _viewMonth.Month + "月";
                RebuildSchedule();
                if (_dayShowTodo) RebuildTodo();
            }
            else
            {
                _monthLabel.Text = _viewMonth.Year + "年" + _viewMonth.Month + "月";
                RebuildCalendar();
                RebuildSchedule();
                RebuildTodo();
            }
            UpdateAccentVisuals();
        }

        void UpdateAccentVisuals()
        {
            SolidColorBrush accent = ColorUtil.Brush(_data.Settings.Accent);
            if (_todayBadge != null) _todayBadge.Background = accent;
            if (_appTitle != null) _appTitle.Foreground = accent;
            Brush dv = Ui.DividerBrush(accent.Color, _data.Settings.DividerStyle);
            if (_dashLine1 != null) _dashLine1.Background = dv;
            if (_dashLine2 != null) _dashLine2.Background = dv;
            SetAccent(this, accent);
        }

        void SetAccent(DependencyObject root, Brush accent)
        {
            int n = VisualTreeHelper.GetChildrenCount(root);
            for (int i = 0; i < n; i++)
            {
                DependencyObject child = VisualTreeHelper.GetChild(root, i);
                string an = AutomationProperties.GetName(child);
                if (an == "SchedAdd" || an == "TodoAdd")
                {
                    Border b = child as Border;
                    if (b != null) b.Background = accent;
                }
                SetAccent(child, accent);
            }
        }

        // 圆角强调色 "+" 按钮（Border 承载圆角背景；内部 Button 提供 UIA peer 与键盘可达性）
        Border MakeRoundPlus(string text, string tip, Action onClick, string automationId)
        {
            Border bd = new Border();
            bd.CornerRadius = new CornerRadius(6);
            bd.Background = ColorUtil.Brush(_data.Settings.Accent);
            bd.ClipToBounds = true;
            bd.HorizontalAlignment = HorizontalAlignment.Stretch;
            bd.VerticalAlignment = VerticalAlignment.Stretch;

            Button btn = new Button();
            btn.Content = text;
            btn.FontFamily = Ui.Font;
            btn.FontSize = 16;
            btn.Foreground = Brushes.White;
            btn.FontWeight = FontWeights.Bold;
            btn.Background = Brushes.Transparent;
            btn.BorderThickness = new Thickness(0);
            btn.Padding = new Thickness(0);
            btn.Margin = new Thickness(0);
            btn.Cursor = Cursors.Hand;
            btn.ToolTip = tip;
            btn.FocusVisualStyle = null;
            AutomationProperties.SetName(btn, automationId);
            btn.Click += delegate { onClick(); };
            bd.Child = btn;
            return bd;
        }
    }
}
