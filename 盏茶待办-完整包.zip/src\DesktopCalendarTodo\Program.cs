using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Threading;

namespace DesktopCalendarTodo
{
    public static class Program
    {
        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        static extern IntPtr FindWindow(string className, string windowTitle);

        [STAThread]
        public static int Main(string[] args)
        {
            string dataDir = DataStore.DefaultDir();
            bool selftest = false;
            bool monthlyReport = false;
            bool exitTest = false;
            bool multi = false; // 测试用：跳过单实例检查，允许与正在运行的正式实例并存（各自独立数据目录）
            bool notesStart = false; // 测试用：--notes 启动即进入备忘录
            for (int i = 0; i < args.Length; i++)
            {
                if (args[i] == "--selftest") selftest = true;
                if (args[i] == "--monthly-report") monthlyReport = true;
                if (args[i] == "--exit-test") exitTest = true;
                if (args[i] == "--multi") multi = true;
                if (args[i] == "--notes") notesStart = true;
                if (args[i] == "--datadir" && i + 1 < args.Length) dataDir = args[i + 1];
            }

            AppDomain.CurrentDomain.UnhandledException += delegate(object s, UnhandledExceptionEventArgs e)
            {
                WriteCrashLog(dataDir, e.ExceptionObject as Exception);
            };

            if (selftest)
            {
                bool ok = SelfTest.Run(dataDir);
                return ok ? 0 : 1;
            }

            if (monthlyReport)
            {
                // 强制生成本月月度总结（供手动触发/测试脚本使用，不做“本月已生成”去重）
                bool ok = RunMonthlyCli(dataDir);
                return ok ? 0 : 1;
            }

            // 单实例：同名互斥体存在时，只有确实找得到本程序主窗口才认为“已在运行”。
            // 某些异常退出场景会留下残留互斥体（没有对应进程/窗口），此时继续启动，
            // 避免用户双击 exe 毫无反应（且后续启动会通过主窗口检测阻止重复实例）。
            // --multi：测试脚本用它绕开单实例限制（配合独立 --datadir，不影响正式实例）。
            Mutex mutex = null;
            if (!multi)
            {
                bool created;
                mutex = new Mutex(true, "DesktopCalendarTodo.SingleInstance.v2", out created);
                if (!created)
                {
                    IntPtr existing = FindWindow(null, "盏茶待办");
                    if (existing != IntPtr.Zero)
                    {
                        mutex.Close();
                        return 0; // 已有实例在运行，直接退出
                    }
                    // 无主窗口：视为残留锁，继续启动（不写 crash.log，避免每次启动都留下记录）
                }
            }

            MainWindow.StartInNotes = notesStart;
            App app = new App(dataDir);
            if (exitTest)
            {
                // 供回归测试：启动后自动走真实退出路径（ExitApp -> Shutdown），验证进程/托盘/互斥锁正常释放
                System.Windows.Threading.DispatcherTimer tm = new System.Windows.Threading.DispatcherTimer();
                tm.Interval = TimeSpan.FromMilliseconds(1500);
                tm.Tick += delegate(object s, EventArgs e)
                {
                    tm.Stop();
                    MainWindow w = app.MainWindow as MainWindow;
                    if (w != null) w.ExitApp();
                };
                tm.Start();
            }
            app.Run();
            if (mutex != null) mutex.Close();
            return 0;
        }

        // 命令行强制生成本月月度总结：顺延未完成事项并写报告文件
        static bool RunMonthlyCli(string dataDir)
        {
            try
            {
                if (!Directory.Exists(dataDir)) Directory.CreateDirectory(dataDir);
                PlannerData data = DataStore.Load(dataDir);
                DateTime now = DateTime.Now;
                int pending;
                string text = Monthly.Generate(data, now, out pending);
                string path = Monthly.WriteReport(dataDir, now, text);
                if (path.Length == 0 || !File.Exists(path)) return false;
                data.Settings.LastMonthlyReport = now.ToString("yyyy-MM");
                DataStore.Save(dataDir, data);
                return true;
            }
            catch (Exception ex)
            {
                WriteCrashLog(dataDir, ex);
                return false;
            }
        }

        public static void WriteCrashLog(string dataDir, Exception ex)
        {
            try
            {
                string path = Path.Combine(dataDir, "crash.log");
                File.AppendAllText(path,
                    DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " " + (ex == null ? "unknown" : ex.ToString()) + "\r\n",
                    Encoding.UTF8);
            }
            catch { }
        }
    }

    public class App : Application
    {
        string _dataDir;
        MainWindow _win;

        public App(string dataDir)
        {
            _dataDir = dataDir;
            ShutdownMode = ShutdownMode.OnExplicitShutdown;
            DispatcherUnhandledException += delegate(object s, DispatcherUnhandledExceptionEventArgs e)
            {
                Program.WriteCrashLog(dataDir, e.Exception);
                e.Handled = true;
            };
        }

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            _win = new MainWindow(_dataDir);
            _win.Show();
        }

        protected override void OnExit(ExitEventArgs e)
        {
            if (_win != null) _win.DisposeTray();
            base.OnExit(e);
        }
    }

    // ---- 逻辑自检（无界面） ----
    public static class SelfTest
    {
        static List<string> _log = new List<string>();
        static int _failed;

        static void T(string name, bool ok, string detail)
        {
            _log.Add((ok ? "PASS " : "FAIL ") + name + (detail.Length > 0 ? "  ->  " + detail : ""));
            if (!ok) _failed++;
        }

        public static bool Run(string dataDir)
        {
            string work = Path.Combine(dataDir, ".selftest");
            try { if (!Directory.Exists(work)) Directory.CreateDirectory(work); }
            catch { work = Path.GetTempPath(); }

            _log.Add("== DesktopCalendarTodo selftest ==");
            _log.Add("data dir: " + work);
            _log.Add("runtime: " + Environment.Version.ToString());

            TestLunar();
            TestLunarSolar();
            TestJsonLegacy();
            TestDataOps(work);
            TestArrange(work);
            TestSettings(work);
            TestMonthly(work);
            TestArrangePlan();
            TestUtf8(work);

            // 清理
            try { if (Directory.Exists(work)) Directory.Delete(work, true); } catch { }

            _log.Add("== RESULT: " + (_failed == 0 ? "ALL PASS" : (_failed + " FAILED")) + " ==");
            string logPath = Path.Combine(dataDir, "selftest-log.txt");
            try
            {
                File.WriteAllText(logPath, string.Join("\r\n", _log.ToArray()) + "\r\n", new UTF8Encoding(true));
            }
            catch { }

            Console.WriteLine(string.Join("\r\n", _log.ToArray()));
            return _failed == 0;
        }

        static void TestLunar()
        {
            LunarDate d = Lunar.FromSolar(new DateTime(2024, 2, 10));
            T("lunar 2024-02-10 spring", d.GanZhiYear == "甲辰" && d.Month == 1 && d.Day == 1 && !d.IsLeap,
                d.GanZhiYear + " " + d.MonthName + d.DayName);

            d = Lunar.FromSolar(new DateTime(2024, 2, 24));
            T("lunar 2024-02-24 lantern", d.Month == 1 && d.Day == 15, d.MonthName + d.DayName);

            d = Lunar.FromSolar(new DateTime(2024, 9, 17));
            T("lunar 2024-09-17 midautumn", d.Month == 8 && d.Day == 15, d.MonthName + d.DayName);

            d = Lunar.FromSolar(new DateTime(2025, 1, 29));
            T("lunar 2025-01-29 spring", d.GanZhiYear == "乙巳" && d.Month == 1 && d.Day == 1, d.GanZhiYear + " " + d.MonthName + d.DayName);

            d = Lunar.FromSolar(new DateTime(2026, 2, 17));
            T("lunar 2026-02-17 spring", d.GanZhiYear == "丙午" && d.Month == 1 && d.Day == 1, d.GanZhiYear + " " + d.MonthName + d.DayName);

            d = Lunar.FromSolar(new DateTime(2023, 1, 22));
            T("lunar 2023-01-22 spring", d.GanZhiYear == "癸卯" && d.Month == 1 && d.Day == 1, d.GanZhiYear + " " + d.MonthName + d.DayName);

            d = Lunar.FromSolar(new DateTime(2023, 3, 22));
            T("lunar 2023-03-22 leap2", d.IsLeap && d.Month == 2 && d.Day == 1, d.MonthName + d.DayName);

            d = Lunar.FromSolar(new DateTime(1900, 1, 31));
            T("lunar 1900-01-31 base", d.Year == 1900 && d.Month == 1 && d.Day == 1, d.GanZhiYear + " " + d.MonthName + d.DayName);

            d = Lunar.FromSolar(new DateTime(2100, 1, 5));
            T("lunar 2100-01-05 upper", d.Year == 2099 && d.Month == 11 && d.Day == 25, d.Year + " " + d.MonthName + d.DayName);

            d = Lunar.FromSolar(new DateTime(2026, 10, 20));
            T("lunar 2026-10-20 today", d.Month >= 1 && d.Month <= 12 && d.Day >= 1 && d.Day <= 30 && d.GanZhiYear.Length == 2,
                d.GanZhiYear + " " + d.MonthName + d.DayName);
            _log.Add("INFO lunar 2026-10-20 = " + d.GanZhiYear + " " + d.MonthName + d.DayName + " (" + d.ShengXiao + ")");
        }

        static void TestJsonLegacy()
        {
            // v1 旧数据：含便签 notes、旧键 schedule/todo、部分 settings
            string v1 = "{\"version\":1,\"notes\":[{\"text\":\"旧便签内容\",\"color\":\"#FF0000\"}],"
                + "\"settings\":{\"width\":1000,\"height\":600,\"opacity\":0.8},"
                + "\"schedule\":{\"2026-10-20\":[{\"text\":\"旧日程\",\"time\":\"09:00\",\"category\":\"工作\"}]},"
                + "\"todo\":[{\"text\":\"旧待办\",\"category\":\"重要\"}]}";

            string dir = Path.Combine(DataStore.DefaultDir(), ".selftest");
            try { Directory.CreateDirectory(dir); } catch { }
            string file = Path.Combine(dir, "planner-data.json");
            try { File.WriteAllText(file, v1, new UTF8Encoding(false)); } catch { }

            PlannerData data = DataStore.Load(dir);
            T("legacy load todos", data.Todos.Count == 1 && data.Todos[0].Text == "旧待办" && data.Todos[0].Category == "重要",
                "todos=" + data.Todos.Count);
            T("legacy load sched", data.Schedules.ContainsKey("2026-10-20") && data.Schedules["2026-10-20"].Count == 1
                && data.Schedules["2026-10-20"][0].Category == "工作", "schedules keys=" + data.Schedules.Count);
            T("legacy notes kept", data.LegacyNotes != null && data.LegacyNotes.Kind == JKind.Array,
                data.LegacyNotes == null ? "null" : data.LegacyNotes.Arr.Count + " items");

            data.Todos[0].Done = true;
            DataStore.Save(dir, data);

            PlannerData reload = DataStore.Load(dir);
            T("legacy resave keeps notes", reload.LegacyNotes != null && reload.LegacyNotes.Kind == JKind.Array
                && reload.LegacyNotes.Arr.Count == 1, "notes=" + (reload.LegacyNotes == null ? 0 : reload.LegacyNotes.Arr.Count));
            T("legacy resave keeps edits", reload.Todos.Count == 1 && reload.Todos[0].Done, "done=" + reload.Todos[0].Done);
            T("legacy version=2", reload.Version == 2, "version=" + reload.Version);

            try { if (Directory.Exists(dir)) Directory.Delete(dir, true); } catch { }
        }

        static void TestDataOps(string work)
        {
            PlannerData d = new PlannerData();
            DateTime day = new DateTime(2026, 10, 20);
            List<ScheduleItem> list = d.DaySchedules(day);
            ScheduleItem a = new ScheduleItem();
            a.Id = "a"; a.Text = "第一项"; a.Time = "09:00"; a.Category = "重要";
            ScheduleItem b = new ScheduleItem();
            b.Id = "b"; b.Text = "第二项"; b.Category = "日常";
            ScheduleItem c = new ScheduleItem();
            c.Id = "c"; c.Text = "第三项"; c.Category = "紧急"; c.Done = true;
            list.Add(a); list.Add(b); list.Add(c);

            // 上移
            list.RemoveAt(2); list.Insert(1, c);
            T("schedule sort up", list[1].Id == "c", list[0].Id + "," + list[1].Id + "," + list[2].Id);

            // 子任务
            a.Subtasks.Add(new SubtaskItem("s1", "子任务一"));
            a.Subtasks.Add(new SubtaskItem("s2", "子任务二"));
            a.Subtasks[1].Done = true;
            a.Subtasks.RemoveAt(0);
            T("subtask ops", a.Subtasks.Count == 1 && a.Subtasks[0].Done, "subs=" + a.Subtasks.Count + " done=" + a.Subtasks[0].Done);

            // 编辑
            a.Text = "改后内容";
            a.Time = "10:30";
            a.EndTime = "11:30";
            T("schedule edit", a.Text == "改后内容" && a.Time == "10:30" && a.EndTime == "11:30",
                a.Text + " " + a.Time + "-" + a.EndTime);

            // 完成
            b.Done = true;
            T("schedule done", b.Done, "");

            // 删除
            list.RemoveAt(1);
            T("schedule delete", list.Count == 2, "count=" + list.Count);

            // 持久化
            DataStore.Save(work, d);
            PlannerData r = DataStore.Load(work);
            T("schedule persist", r.Schedules.ContainsKey("2026-10-20") && r.Schedules["2026-10-20"].Count == 2
                && r.Schedules["2026-10-20"][1].Id == "b" && r.Schedules["2026-10-20"][0].Subtasks.Count == 1
                && r.Schedules["2026-10-20"][0].EndTime == "11:30",
                "count=" + r.Schedules["2026-10-20"].Count + " endTime=" + r.Schedules["2026-10-20"][0].EndTime);

            // 分类颜色
            T("color custom", Cats.ColorOf("自定义颜色", "#112233") == "#112233" && Cats.ColorOf("日常", "") == "#6B7280",
                Cats.ColorOf("自定义颜色", "#112233") + "," + Cats.ColorOf("日常", ""));
            T("bold cats", Cats.IsBold("重要") && Cats.IsBold("紧急") && !Cats.IsBold("日常") && !Cats.IsBold("工作"),
                "");

            // 回撤：日程 -> 待办（保留原日期与时间标签）
            TodoItem rv = new TodoItem();
            rv.Id = Guid.NewGuid().ToString("N");
            rv.Text = a.Text;
            rv.Done = a.Done;
            rv.Category = a.Category;
            rv.CustomColor = a.CustomColor;
            rv.Date = "2026-10-20";
            rv.Time = a.Time;
            rv.EndTime = a.EndTime;
            d.Todos.Add(rv);
            T("revert builds todo", d.Todos.Count == 1 && d.Todos[0].Date == "2026-10-20" && d.Todos[0].Time == "10:30"
                && d.Todos[0].EndTime == "11:30", d.Todos[0].Date + " " + d.Todos[0].Time + "-" + d.Todos[0].EndTime);

            // 复制：克隆日程为新日程（同日期、新 Id、子任务保留）
            ScheduleItem cp = a.Clone();
            cp.Id = Guid.NewGuid().ToString("N");
            list.Add(cp);
            T("copy clones schedule", list.Count == 3 && list[2].Text == a.Text && list[2].Id != a.Id
                && list[2].Subtasks.Count == 1 && list[2].EndTime == "11:30", "count=" + list.Count + " subs=" + list[2].Subtasks.Count);

            DataStore.Save(work, d);
            PlannerData r3 = DataStore.Load(work);
            TodoItem rt = r3.Todos[0];
            T("todo date/time persists", rt.Date == "2026-10-20" && rt.Time == "10:30" && rt.EndTime == "11:30",
                rt.Date + " " + rt.Time + "-" + rt.EndTime);
            T("divider style persists", r3.Settings.DividerStyle == "dash", r3.Settings.DividerStyle);

            // 窗口样式（viewMode）读写与非法值回退
            r3.Settings.ViewMode = "week";
            DataStore.Save(work, r3);
            PlannerData r4 = DataStore.Load(work);
            T("viewMode week persists", r4.Settings.ViewMode == "week", r4.Settings.ViewMode);
            r4.Settings.ViewMode = "bogus";
            DataStore.Save(work, r4);
            PlannerData r5 = DataStore.Load(work);
            T("viewMode bogus falls back", r5.Settings.ViewMode == "month", r5.Settings.ViewMode);
        }

        static void TestArrange(string work)
        {
            PlannerData d = new PlannerData();
            TodoItem t = new TodoItem();
            t.Id = "t1"; t.Text = "安排我"; t.Category = "重要"; t.CustomColor = "#FF8800"; t.Done = true;
            d.Todos.Add(t);

            DateTime day = new DateTime(2026, 11, 5);
            List<ScheduleItem> list = d.DaySchedules(day);
            ScheduleItem s = new ScheduleItem();
            s.Id = Guid.NewGuid().ToString("N");
            s.Text = t.Text;
            s.Time = ""; // 待办无时间 -> 空时间，绝不写错误时间
            s.Done = t.Done;
            s.Category = t.Category;
            s.CustomColor = t.CustomColor;
            list.Add(s);
            d.Todos.RemoveAt(0);

            T("arrange moves", d.Todos.Count == 0 && list.Count == 1, "todos=" + d.Todos.Count);
            T("arrange preserves", list[0].Text == "安排我" && list[0].Done && list[0].Category == "重要"
                && list[0].CustomColor == "#FF8800" && list[0].Time == "",
                list[0].Text + "|" + list[0].Done + "|" + list[0].Category + "|time=" + list[0].Time);

            DataStore.Save(work, d);
            PlannerData r = DataStore.Load(work);
            ScheduleItem rs = r.Schedules["2026-11-05"][0];
            T("arrange persists", rs.Text == "安排我" && rs.Time == "" && rs.CustomColor == "#FF8800",
                rs.Text + " time=" + rs.Time + " color=" + rs.CustomColor);
        }

        static void TestSettings(string work)
        {
            AppSettings s = new AppSettings();
            s.Width = 1234; s.Height = 700;
            s.ScheduleWidth = 380; s.TodoWidth = 300;
            s.CalendarWidth = 352;
            s.Background = "#E6222429"; s.Accent = "#2DD4BF";
            s.Opacity = 0.7; s.Topmost = true; s.EdgeDock = false;
            PlannerData d = new PlannerData();
            d.Settings = s;
            DataStore.Save(work, d);
            PlannerData r = DataStore.Load(work);
            T("settings roundtrip", r.Settings.Width == 1234 && r.Settings.ScheduleWidth == 380
                && r.Settings.TodoWidth == 300 && r.Settings.Opacity == 0.7 && r.Settings.Topmost
                && !r.Settings.EdgeDock && r.Settings.Accent == "#2DD4BF" && r.Settings.CalendarWidth == 352,
                r.Settings.Width + "x" + r.Settings.Height + " sw=" + r.Settings.ScheduleWidth + " tw=" + r.Settings.TodoWidth
                + " cw=" + r.Settings.CalendarWidth + " op=" + r.Settings.Opacity + " acc=" + r.Settings.Accent);
        }

        static ScheduleItem NewSched(string id, string text, string time, string cat, bool done, string custom)
        {
            ScheduleItem s = new ScheduleItem();
            s.Id = id;
            s.Text = text;
            s.Time = time;
            s.Category = cat;
            s.Done = done;
            s.CustomColor = custom;
            return s;
        }

        static void TestMonthly(string work)
        {
            // 下一个工作日
            T("workday fri->mon", Monthly.NextWorkday(new DateTime(2026, 10, 16)) == new DateTime(2026, 10, 19),
                Monthly.NextWorkday(new DateTime(2026, 10, 16)).ToString("yyyy-MM-dd"));
            T("workday sat->mon", Monthly.NextWorkday(new DateTime(2026, 10, 17)) == new DateTime(2026, 10, 19),
                Monthly.NextWorkday(new DateTime(2026, 10, 17)).ToString("yyyy-MM-dd"));
            T("workday sun->mon", Monthly.NextWorkday(new DateTime(2026, 10, 18)) == new DateTime(2026, 10, 19),
                Monthly.NextWorkday(new DateTime(2026, 10, 18)).ToString("yyyy-MM-dd"));
            T("workday wed->thu", Monthly.NextWorkday(new DateTime(2026, 10, 21)) == new DateTime(2026, 10, 22), "");

            // 当月第 3 个周一
            T("3rd monday 10-19", Monthly.IsThirdMonday(new DateTime(2026, 10, 19)), "");
            T("not 3rd (2nd monday)", !Monthly.IsThirdMonday(new DateTime(2026, 10, 12)), "");
            T("not 3rd (4th monday)", !Monthly.IsThirdMonday(new DateTime(2026, 10, 26)), "");
            T("not monday", !Monthly.IsThirdMonday(new DateTime(2026, 10, 20)), "");

            // 月报生成 + 自动顺延
            PlannerData d = new PlannerData();
            DateTime now = new DateTime(2026, 10, 19, 10, 30, 0); // 10月第3个周一
            d.DaySchedules(new DateTime(2026, 10, 5)).Add(NewSched("d1", "完成产品评审", "16:30", "日常", true, ""));
            d.DaySchedules(new DateTime(2026, 10, 8)).Add(NewSched("d2", "健身", "19:00", "紧急", true, ""));
            d.DaySchedules(new DateTime(2026, 10, 6)).Add(NewSched("p1", "提交季度报告", "14:00", "重要", false, "#FF8800"));
            d.DaySchedules(new DateTime(2026, 10, 10)).Add(NewSched("p2", "给妈妈打电话", "", "紧急", false, ""));
            d.DaySchedules(new DateTime(2026, 10, 22)).Add(NewSched("p3", "周末郊游", "08:00", "生活", false, ""));
            d.DaySchedules(new DateTime(2026, 11, 2)).Add(NewSched("x1", "下月事项", "09:00", "工作", true, ""));

            int pending;
            string text = Monthly.Generate(d, now, out pending);
            T("monthly pending count", pending == 2, "pending=" + pending);
            T("monthly bullets", text.Contains("• 完成产品评审") && text.Contains("• 提交季度报告"), "");
            T("monthly counts", text.Contains("已完成事项（共 2 项）") && text.Contains("未完成 / 进行中事项（共 3 项）"), "");
            // 月报只读数据：不自动顺延、不改动任何日程
            T("monthly no auto defer", d.Schedules["2026-10-06"][0].Id == "p1" && d.Schedules["2026-10-10"][0].Id == "p2"
                && (!d.Schedules.ContainsKey("2026-10-20") || d.Schedules["2026-10-20"].Count == 0),
                "10-06=" + d.Schedules["2026-10-06"].Count + " 10-10=" + d.Schedules["2026-10-10"].Count);
            T("monthly pending section", text.Contains("其中今天及以前 2 项"), "");
            // 分类紧急程度排序：紧急 > 重要 > 工作 > 生活 > 日常（同类再按日期/时间）
            int iu1 = text.IndexOf("健身");
            int iu2 = text.IndexOf("完成产品评审");
            T("monthly urgency done", iu1 >= 0 && iu2 >= 0 && iu1 < iu2, "紧急(健身) 应排在 日常(完成产品评审) 前");
            int iu3 = text.IndexOf("给妈妈打电话");
            int iu4 = text.IndexOf("提交季度报告");
            T("monthly urgency pending", iu3 >= 0 && iu4 >= 0 && iu3 < iu4, "紧急(打电话) 应排在 重要(提交报告) 前");
            T("monthly category label", text.Contains("〔紧急〕") && text.Contains("〔重要〕"), "");
            T("monthly keeps fields", d.Schedules["2026-10-06"][0].Time == "14:00"
                && d.Schedules["2026-10-06"][0].Category == "重要"
                && d.Schedules["2026-10-06"][0].CustomColor == "#FF8800", "");
            T("monthly keeps future", d.Schedules.ContainsKey("2026-10-22") && d.Schedules["2026-10-22"][0].Id == "p3", "");
            T("monthly done unchanged", d.Schedules["2026-10-05"][0].Done && d.Schedules["2026-10-08"][0].Done, "");
            T("monthly ignores next month", !text.Contains("下月事项"), "");

            string path = Monthly.WriteReport(work, now, text);
            T("monthly report file", path.Length > 0 && File.Exists(path), path);
            string read = File.ReadAllText(path, Encoding.UTF8);
            T("monthly report utf8", read.Contains("月度总结") && read.Contains("一键回撤") && read.Contains("一键顺延"), "");
        }

        static void TestLunarSolar()
        {
            // 农历 -> 公历
            DateTime? d = Lunar.LunarToSolar(2024, 1, 1, false);
            T("lunar->solar 2024 正月初一", d.HasValue && d.Value == new DateTime(2024, 2, 10),
                d.HasValue ? d.Value.ToString("yyyy-MM-dd") : "null");
            // 今天回推（2026-10-29 = 农历九月二十）
            LunarDate lu = Lunar.FromSolar(new DateTime(2026, 10, 29));
            DateTime? back = Lunar.LunarToSolar(lu.Year, lu.Month, lu.Day, lu.IsLeap);
            T("lunar->solar roundtrip today", back.HasValue && back.Value == new DateTime(2026, 10, 29),
                back.HasValue ? back.Value.ToString("yyyy-MM-dd") : "null");
            // 闰二月
            DateTime? leap = Lunar.LunarToSolar(2023, 2, 1, true);
            T("lunar->solar leap2 2023", leap.HasValue && leap.Value == new DateTime(2023, 3, 22),
                leap.HasValue ? leap.Value.ToString("yyyy-MM-dd") : "null");
            // 该年不存在该闰月
            DateTime? noLeap = Lunar.LunarToSolar(2024, 2, 1, true);
            T("lunar->solar missing leap", !noLeap.HasValue, noLeap.HasValue ? "has" : "null");
            // 腊月廿九（2024 农历腊月为小月，无三十）
            DateTime? ny = Lunar.LunarToSolar(2024, 12, 29, false);
            T("lunar->solar 2024 腊月廿九", ny.HasValue && ny.Value == new DateTime(2025, 1, 28),
                ny.HasValue ? ny.Value.ToString("yyyy-MM-dd") : "null");
            // 小月不存在三十
            T("lunar->solar no day30", !Lunar.LunarToSolar(2024, 12, 30, false).HasValue, "guard");
            // 正月初一公历 = SolarNewYear
            T("lunar solar new year", Lunar.SolarNewYear(2025) == new DateTime(2025, 1, 29),
                Lunar.SolarNewYear(2025).ToString("yyyy-MM-dd"));
        }

        static void TestArrangePlan()
        {
            // 不重复
            ArrangePlan p = new ArrangePlan();
            p.StartDate = new DateTime(2026, 10, 29); p.EndDate = p.StartDate;
            p.RepeatType = ArrangePlan.RNone; p.RepeatCount = 1;
            List<DateTime> dates = p.GenerateDates();
            T("plan none", dates.Count == 1 && dates[0] == new DateTime(2026, 10, 29), "count=" + dates.Count);

            // 每天 x3
            p.RepeatType = ArrangePlan.RDay; p.RepeatCount = 3;
            dates = p.GenerateDates();
            T("plan daily x3", dates.Count == 3 && dates[2] == new DateTime(2026, 10, 31), "count=" + dates.Count);

            // 每周 x2
            p.RepeatType = ArrangePlan.RWeek; p.RepeatCount = 2;
            dates = p.GenerateDates();
            T("plan weekly x2", dates.Count == 2 && dates[1] == new DateTime(2026, 11, 5), "count=" + dates.Count);

            // 每月（月末钳制）
            p.RepeatType = ArrangePlan.RMonth; p.RepeatCount = 2; p.StartDate = new DateTime(2024, 1, 31);
            dates = p.GenerateDates();
            T("plan monthly clamp", dates.Count == 2 && dates[1] == new DateTime(2024, 2, 29),
                "d1=" + dates[1].ToString("yyyy-MM-dd"));

            // 每年（闰日钳制）
            p.RepeatType = ArrangePlan.RYear; p.RepeatCount = 2; p.StartDate = new DateTime(2024, 2, 29);
            dates = p.GenerateDates();
            T("plan yearly leap clamp", dates.Count == 2 && dates[1] == new DateTime(2025, 2, 28),
                "d1=" + dates[1].ToString("yyyy-MM-dd"));

            // 农历每年
            p.RepeatType = ArrangePlan.RLunarYear; p.RepeatCount = 2; p.StartDate = new DateTime(2026, 10, 29);
            dates = p.GenerateDates();
            T("plan lunaryear x2", dates.Count == 2 && dates[1].Year == 2027,
                "count=" + dates.Count + " d1=" + dates[1].ToString("yyyy-MM-dd"));

            // 结束日期截止
            p.RepeatType = ArrangePlan.RDay; p.RepeatCount = 0;
            p.StartDate = new DateTime(2026, 10, 29); p.EndDate = new DateTime(2026, 11, 1);
            dates = p.GenerateDates();
            T("plan daily to end", dates.Count == 4 && dates[3] == new DateTime(2026, 11, 1), "count=" + dates.Count);
        }

        static void TestUtf8(string work)
        {
            PlannerData d = new PlannerData();
            List<ScheduleItem> list = d.DaySchedules(new DateTime(2026, 12, 1));
            ScheduleItem it = new ScheduleItem();
            it.Id = "u1"; it.Text = "中文测试：日程✓完成"; it.Category = "生活";
            list.Add(it);
            DataStore.Save(work, d);

            byte[] bytes = File.ReadAllBytes(Path.Combine(work, "planner-data.json"));
            bool noBom = !(bytes.Length >= 3 && bytes[0] == 0xEF && bytes[1] == 0xBB && bytes[2] == 0xBF);
            string text = new UTF8Encoding(false).GetString(bytes);
            T("utf8 json", text.Contains("中文测试：日程✓完成") && text.Contains("2026-12-01"), "len=" + bytes.Length + " bom=" + (!noBom));
        }
    }
}
