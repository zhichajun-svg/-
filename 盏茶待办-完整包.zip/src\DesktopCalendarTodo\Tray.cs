using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace DesktopCalendarTodo
{
    public partial class MainWindow
    {
        NotifyIcon _tray;
        IntPtr _trayIconHandle;

        // 托盘图标：运行时绘制（圆角方块 + "日"字），无需外部 .ico
        void BuildTray()
        {
            _tray = new NotifyIcon();
            _tray.Text = "盏茶待办";
            _tray.Icon = CreateTrayIcon();
            _tray.Visible = true;

            ContextMenuStrip menu = new ContextMenuStrip();
            ToolStripMenuItem show = new ToolStripMenuItem("显示");
            show.Click += delegate { ShowMain(); };
            menu.Items.Add(show);
            ToolStripMenuItem exit = new ToolStripMenuItem("退出");
            exit.Click += delegate { ExitApp(); };
            menu.Items.Add(exit);

            _tray.ContextMenuStrip = menu;
            _tray.DoubleClick += delegate { ShowMain(); };
        }

        System.Drawing.Icon CreateTrayIcon()
        {
            Bitmap bmp = new Bitmap(32, 32);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                using (SolidBrush bg = new SolidBrush(System.Drawing.Color.FromArgb(255, 30, 32, 44)))
                {
                    FillRounded(g, bg, 2, 2, 28, 28, 7);
                }
                using (SolidBrush accent = new SolidBrush(System.Drawing.Color.FromArgb(255, 79, 140, 255)))
                {
                    FillRounded(g, accent, 2, 2, 28, 8, 7);
                }
                using (System.Drawing.Font f = new System.Drawing.Font("Microsoft YaHei UI", 13, System.Drawing.FontStyle.Bold, GraphicsUnit.Pixel))
                {
                    using (SolidBrush white = new SolidBrush(System.Drawing.Color.White))
                    {
                        StringFormat sf = new StringFormat();
                        sf.Alignment = StringAlignment.Center;
                        sf.LineAlignment = StringAlignment.Center;
                        g.DrawString("日", f, white, new RectangleF(2, 2, 28, 28), sf);
                    }
                }
            }
            _trayIconHandle = bmp.GetHicon();
            return System.Drawing.Icon.FromHandle(_trayIconHandle);
        }

        static void FillRounded(Graphics g, Brush brush, int x, int y, int w, int h, int r)
        {
            using (GraphicsPath path = new GraphicsPath())
            {
                path.AddArc(x, y, r * 2, r * 2, 180, 90);
                path.AddArc(x + w - r * 2, y, r * 2, r * 2, 270, 90);
                path.AddArc(x + w - r * 2, y + h - r * 2, r * 2, r * 2, 0, 90);
                path.AddArc(x, y + h - r * 2, r * 2, r * 2, 90, 90);
                path.CloseFigure();
                g.FillPath(brush, path);
            }
        }

        public void DisposeTray()
        {
            if (_tray != null)
            {
                _tray.Visible = false;
                _tray.Dispose();
                _tray = null;
            }
            if (_trayIconHandle != IntPtr.Zero)
            {
                try { DestroyIcon(_trayIconHandle); } catch { }
                _trayIconHandle = IntPtr.Zero;
            }
        }

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        static extern bool DestroyIcon(IntPtr handle);
    }
}
