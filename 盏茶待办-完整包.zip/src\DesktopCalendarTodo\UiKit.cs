using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;

namespace DesktopCalendarTodo
{
    // 通用 UI 工厂：统一字体、按钮、输入框、对话框外观
    public static class Ui
    {
        public static readonly FontFamily Font = new FontFamily("Microsoft YaHei UI");

        public static TextBlock Lbl(string text, double size, Color color, bool bold = false)
        {
            TextBlock t = new TextBlock();
            t.Text = text;
            t.FontSize = size;
            t.Foreground = new SolidColorBrush(color);
            t.FontFamily = Font;
            if (bold) t.FontWeight = FontWeights.Bold;
            t.TextTrimming = TextTrimming.CharacterEllipsis;
            return t;
        }

        // 可选择文本（只读透明文本框）：支持鼠标拖选 + Ctrl+C/右键复制
        // WPF TextBlock 不支持文本选择（IsTextSelectionEnabled 仅 UWP 有），用无边框只读 TextBox 替代
        public static TextBox SelectableText(string text, double size, Color color, bool bold = false)
        {
            TextBox b = new TextBox();
            b.Text = text;
            b.FontSize = size;
            b.FontFamily = Font;
            b.Foreground = new SolidColorBrush(color);
            b.FontWeight = bold ? FontWeights.Bold : FontWeights.Normal;
            b.IsReadOnly = true;
            b.BorderThickness = new Thickness(0);
            b.Background = Brushes.Transparent;
            b.Padding = new Thickness(0);
            b.Margin = new Thickness(0);
            b.TextWrapping = TextWrapping.Wrap;
            b.VerticalContentAlignment = VerticalAlignment.Top;
            b.IsReadOnlyCaretVisible = false;
            b.FocusVisualStyle = null;
            AutomationProperties.SetName(b, text);
            return b;
        }

        // 主工具栏按钮
        public static Button ToolButton(string text, string tip)
        {
            Button b = new Button();
            b.Content = text;
            b.FontFamily = Font;
            b.FontSize = 13;
            b.Foreground = new SolidColorBrush(Color.FromArgb(225, 255, 255, 255));
            b.Background = Brushes.Transparent;
            b.BorderThickness = new Thickness(0);
            b.Padding = new Thickness(10, 4, 10, 4);
            b.Cursor = Cursors.Hand;
            b.ToolTip = tip;
            b.VerticalAlignment = VerticalAlignment.Center;
            b.HorizontalContentAlignment = HorizontalAlignment.Center;
            b.VerticalContentAlignment = VerticalAlignment.Center;
            b.MinWidth = 34;
            b.MinHeight = 26;
            return b;
        }

        // 列表卡片内的小按钮：内边距与最小尺寸保证整块区域都可点按，悬停有反馈
        public static Button SmallButton(string text, string tip)
        {
            Button b = new Button();
            b.Content = text;
            b.FontFamily = Font;
            b.FontSize = 11;
            b.Foreground = new SolidColorBrush(Color.FromArgb(170, 255, 255, 255));
            b.Background = Brushes.Transparent;
            b.BorderThickness = new Thickness(0);
            b.Padding = new Thickness(6, 2, 6, 2);
            b.Cursor = Cursors.Hand;
            b.ToolTip = tip;
            b.MinWidth = 22;
            b.MinHeight = 22;
            b.HorizontalContentAlignment = HorizontalAlignment.Center;
            b.VerticalContentAlignment = VerticalAlignment.Center;
            b.MouseEnter += delegate { b.Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)); };
            b.MouseLeave += delegate { b.Background = Brushes.Transparent; };
            return b;
        }

        // 输入框（带回车提交支持、圆角深色样式）
        public static TextBox TextInput(string ghost, RoutedEventHandler enterHandler, string automationId)
        {
            Grid wrap = new Grid();
            wrap.Background = new SolidColorBrush(Color.FromArgb(28, 255, 255, 255));
            wrap.Height = 30;

            TextBox box = new TextBox();
            box.FontFamily = Font;
            box.FontSize = 12.5;
            box.Foreground = new SolidColorBrush(Color.FromArgb(235, 255, 255, 255));
            box.Background = Brushes.Transparent;
            box.BorderThickness = new Thickness(0);
            box.Padding = new Thickness(8, 4, 8, 4);
            box.VerticalContentAlignment = VerticalAlignment.Center;
            box.CaretBrush = new SolidColorBrush(Color.FromArgb(235, 255, 255, 255));
            AutomationProperties.SetName(box, automationId + "_box");

            TextBlock ghostLbl = Ui.Lbl(ghost, 12, Color.FromArgb(110, 255, 255, 255));
            ghostLbl.Margin = new Thickness(9, 0, 0, 0);
            ghostLbl.IsHitTestVisible = false;
            ghostLbl.VerticalAlignment = VerticalAlignment.Center;
            ghostLbl.HorizontalAlignment = HorizontalAlignment.Left;

            wrap.Children.Add(box);
            wrap.Children.Add(ghostLbl);

            box.TextChanged += delegate(object s, TextChangedEventArgs e)
            {
                ghostLbl.Visibility = (box.Text.Length == 0 ? Visibility.Visible : Visibility.Collapsed);
            };
            if (enterHandler != null)
            {
                box.KeyDown += delegate(object s, KeyEventArgs e)
                {
                    if (e.Key == Key.Enter)
                    {
                        e.Handled = true;
                        enterHandler(box, null);
                    }
                };
            }
            box.Tag = wrap;
            return box;
        }

        // 圆角色块按钮（可被 UIA 识别，便于无障碍与自动化录制）
        static ControlTemplate _roundTmpl;

        static ControlTemplate RoundTemplate()
        {
            if (_roundTmpl != null) return _roundTmpl;
            string xaml = "<ControlTemplate TargetType='Button' " +
                "xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' " +
                "xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml'>" +
                "<Border CornerRadius='8' Background='{TemplateBinding Background}' " +
                "BorderBrush='{TemplateBinding BorderBrush}' BorderThickness='{TemplateBinding BorderThickness}'>" +
                "<ContentPresenter HorizontalAlignment='Center' VerticalAlignment='Center'/></Border></ControlTemplate>";
            _roundTmpl = (ControlTemplate)System.Windows.Markup.XamlReader.Parse(xaml);
            return _roundTmpl;
        }

        public static Button DotButton(string automationName, Brush bg, string text, string tip)
        {
            Button b = new Button();
            b.Width = 30; b.Height = 30; b.Margin = new Thickness(3);
            b.Cursor = Cursors.Hand;
            b.Background = bg;
            b.BorderThickness = new Thickness(1);
            b.BorderBrush = new SolidColorBrush(Color.FromArgb(80, 255, 255, 255));
            b.ToolTip = tip;
            b.Content = Ui.Lbl(text, 14, Colors.White, true);
            b.Template = RoundTemplate();
            AutomationProperties.SetName(b, automationName);
            return b;
        }

        public static Button ColorSwatch(string automationName, string hex, Action<string> onPick)
        {
            Button b = new Button();
            b.Width = 30; b.Height = 30; b.Margin = new Thickness(3);
            b.Cursor = Cursors.Hand;
            b.Background = ColorUtil.Brush(hex);
            b.BorderThickness = new Thickness(1);
            b.BorderBrush = Brushes.Transparent;
            b.ToolTip = hex;
            b.Tag = hex;
            b.Template = RoundTemplate();
            AutomationProperties.SetName(b, automationName);
            string sel = hex;
            b.Click += delegate { onPick(sel); };
            return b;
        }

        // 把输入框的圆角外壳包成带边距的格子
        public static Border WrapInput(TextBox box)        {
            Grid wrap = (Grid)box.Tag;
            Border bd = new Border();
            bd.CornerRadius = new CornerRadius(6);
            bd.Child = wrap;
            bd.ClipToBounds = true;
            return bd;
        }

        public static void Hover(Button b, Color hoverColor)
        {
            b.MouseEnter += delegate { b.Background = new SolidColorBrush(hoverColor); };
            b.MouseLeave += delegate { b.Background = Brushes.Transparent; };
        }

        // 自定义颜色历史：新颜色插到最前，去重，最多 max 个
        public static void PushHistory(List<string> list, string hex, int max)
        {
            if (list == null || string.IsNullOrEmpty(hex)) return;
            for (int i = list.Count - 1; i >= 0; i--)
                if (string.Equals(list[i], hex, StringComparison.OrdinalIgnoreCase)) list.RemoveAt(i);
            list.Insert(0, hex);
            while (list.Count > max) list.RemoveAt(list.Count - 1);
        }

        public static Border MakeHistorySwatch(string hex, Action<string> pick)
        {
            Border sw = new Border();
            sw.Width = 30; sw.Height = 30; sw.Margin = new Thickness(3);
            sw.CornerRadius = new CornerRadius(8);
            sw.Background = ColorUtil.Brush(hex);
            sw.Cursor = Cursors.Hand;
            sw.ToolTip = hex;
            string sel = hex;
            sw.MouseLeftButtonUp += delegate { pick(sel); };
            return sw;
        }

        // 皮肤快照："名称|背景色|强调色|透明度|分隔线样式"
        public static string SkinSnapshot(AppSettings s, string name)
        {
            return name + "|" + s.Background + "|" + s.Accent + "|"
                 + s.Opacity.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture) + "|" + s.DividerStyle;
        }

        public static bool SkinName(string str, out string name)
        {
            name = "";
            if (string.IsNullOrEmpty(str)) return false;
            int i = str.IndexOf('|');
            name = i > 0 ? str.Substring(0, i) : str;
            return name.Length > 0;
        }

        public static bool ApplySkin(string str, AppSettings s, out string name)
        {
            name = "";
            if (string.IsNullOrEmpty(str)) return false;
            string[] parts = str.Split('|');
            if (parts.Length < 5) return false;
            name = parts[0];
            s.Background = parts[1];
            s.Accent = parts[2];
            double op;
            if (double.TryParse(parts[3], System.Globalization.NumberStyles.Float,
                    System.Globalization.CultureInfo.InvariantCulture, out op)) s.Opacity = Math.Max(0.35, Math.Min(1.0, op));
            string dv = parts[4];
            if (dv == "solid" || dv == "dash" || dv == "double" || dv == "star" || dv == "dot") s.DividerStyle = dv;
            return name.Length > 0;
        }

        // 统一细滚动条：宽 6px、无箭头、圆角滑块使用强调色（弹窗与主窗口共用）
        public static void ApplyThinScrollBars(FrameworkElement root, Color accent)
        {
            if (root == null) return;
            string hex = string.Format("#{0:x2}{1:x2}{2:x2}", accent.R, accent.G, accent.B);
            string xaml =
                "<ControlTemplate xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' " +
                "xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml' TargetType='ScrollBar'>" +
                "<Grid Background='Transparent'>" +
                "<Track x:Name='PART_Track' IsDirectionReversed='True'>" +
                "<Track.DecreaseRepeatButton><RepeatButton Command='ScrollBar.PageUpCommand' Opacity='0' Focusable='False'/></Track.DecreaseRepeatButton>" +
                "<Track.Thumb><Thumb MinHeight='20' Focusable='False'><Thumb.Template>" +
                "<ControlTemplate TargetType='Thumb'><Border CornerRadius='3' Background='" + hex + "'/></ControlTemplate>" +
                "</Thumb.Template></Thumb></Track.Thumb>" +
                "<Track.IncreaseRepeatButton><RepeatButton Command='ScrollBar.PageDownCommand' Opacity='0' Focusable='False'/></Track.IncreaseRepeatButton>" +
                "</Track></Grid></ControlTemplate>";
            ControlTemplate tmpl;
            try { tmpl = (ControlTemplate)System.Windows.Markup.XamlReader.Parse(xaml); }
            catch { return; }
            Style sb = new Style(typeof(ScrollBar));
            sb.Setters.Add(new Setter(FrameworkElement.WidthProperty, 6.0));
            sb.Setters.Add(new Setter(FrameworkElement.MinWidthProperty, 6.0));
            sb.Setters.Add(new Setter(Control.BackgroundProperty, Brushes.Transparent));
            sb.Setters.Add(new Setter(Control.TemplateProperty, tmpl));
            root.Resources[typeof(ScrollBar)] = sb;
        }

        // 弹窗 / 浮窗统一底色：设置里的背景色 × 整体透明度（最小 60 保证可读）
        public static SolidColorBrush ThemedBackground()        {
            AppSettings s = MainWindow.CurrentSettings;
            Color bg = ColorUtil.Parse(s != null ? s.Background : "#E6191A22", Color.FromArgb(230, 25, 26, 34));
            double op = s != null ? s.Opacity : 0.95;
            int alpha = (int)(bg.A * op);
            if (alpha < 60) alpha = 60;
            if (alpha > 255) alpha = 255;
            return new SolidColorBrush(Color.FromArgb((byte)alpha, bg.R, bg.G, bg.B));
        }

        public static bool IsDarkBg(Color c)
        {
            double lum = 0.299 * c.R + 0.587 * c.G + 0.114 * c.B;
            return lum < 140;
        }

        // 竖向分隔线笔刷（面板分隔线），颜色随强调色变化；样式：solid/dash/double/star/dot
        // 全部以 6px 宽平铺单元绘制，与分隔线容器宽度一致
        public static Brush DividerBrush(Color accent, string style)
        {
            DrawingGroup dg = new DrawingGroup();
            GeometryDrawing gd = new GeometryDrawing();
            SolidColorBrush ab = new SolidColorBrush(accent);
            ab.Freeze();
            if (style == "solid")
            {
                // 6x6 平铺：居中 2px 宽竖线全程填充 => 实线
                gd.Brush = ab;
                gd.Geometry = new RectangleGeometry(new Rect(2, 0, 2, 6));
            }
            else if (style == "dash")
            {
                // 6x6 平铺：居中 2px 宽、顶部 3px 填充 => 竖向虚线（3px 亮 / 3px 暗）
                gd.Brush = ab;
                gd.Geometry = new RectangleGeometry(new Rect(2, 0, 2, 3));
            }
            else if (style == "double")
            {
                // 6x6 平铺：左右各一条 2px 竖线（间隔 2px 空隙）=> 双线
                gd.Brush = ab;
                gd.Geometry = new RectangleGeometry(new Rect(0, 0, 2, 3));
                GeometryDrawing gd2 = new GeometryDrawing();
                gd2.Brush = ab;
                gd2.Geometry = new RectangleGeometry(new Rect(4, 0, 2, 3));
                gd2.Freeze();
                dg.Children.Add(gd2);
            }
            else if (style == "star")
            {
                // 6x6 平铺：居中五角星（星星分隔线）
                gd.Brush = ab;
                gd.Geometry = MakeStarGeometry(new Point(3, 3), 2.6, 1.05, -Math.PI / 2);
            }
            else if (style == "dot")
            {
                // 6x6 平铺：居中圆点
                gd.Brush = ab;
                gd.Geometry = new EllipseGeometry(new Point(3, 3), 1.7, 1.7);
            }
            else
            {
                gd.Brush = ab;
                gd.Geometry = new RectangleGeometry(new Rect(2, 0, 2, 3));
            }
            gd.Freeze();
            dg.Children.Add(gd);
            dg.Freeze();
            DrawingBrush db = new DrawingBrush(dg);
            db.TileMode = TileMode.Tile;
            db.Viewport = new Rect(0, 0, 6, 6);
            db.ViewportUnits = BrushMappingMode.Absolute;
            db.Stretch = Stretch.None; // 保持绘制内容原始尺寸，避免被拉伸填满整块导致实线
            db.Freeze();
            return db;
        }

        // 五角星路径（中心 cx,cy；外半径 R，内半径 r；起始角 startAngle 弧度）
        static Geometry MakeStarGeometry(Point c, double R, double r, double startAngle)
        {
            StreamGeometry sg = new StreamGeometry();
            using (StreamGeometryContext ctx = sg.Open())
            {
                Point start = new Point(c.X + R * Math.Cos(startAngle), c.Y + R * Math.Sin(startAngle));
                ctx.BeginFigure(start, true, true);
                for (int i = 1; i < 10; i++)
                {
                    double ang = startAngle + i * Math.PI / 5.0;
                    double rad = (i % 2 == 0) ? R : r;
                    ctx.LineTo(new Point(c.X + rad * Math.Cos(ang), c.Y + rad * Math.Sin(ang)), true, false);
                }
                ctx.Close();
            }
            sg.Freeze();
            return sg;
        }
    }

    // 模态小对话框：无标题栏、圆角深色，避免默认白框
    public class DialogHost : Window
    {
        // 让弹窗贴着触发按钮显示（按钮下方；下方放不下就翻到上方），并限制在屏幕工作区内
        public void PlaceNear(FrameworkElement anchor)
        {
            if (anchor == null || Owner == null) return;
            try
            {
                Point p = anchor.PointToScreen(new Point(0, anchor.ActualHeight + 4));
                double x = p.X;
                double y = p.Y;
                double sw = SystemParameters.WorkArea.Right;
                double sh = SystemParameters.WorkArea.Bottom;
                if (double.IsNaN(Width) || Width <= 0) Width = 240;
                if (double.IsNaN(Height) || Height <= 0) Height = 200;
                if (x + Width > sw) x = sw - Width - 8;
                if (y + Height > sh) y = p.Y - Height - anchor.ActualHeight - 8;
                if (x < 8) x = 8;
                if (y < 8) y = 8;
                WindowStartupLocation = WindowStartupLocation.Manual;
                Left = x;
                Top = y;
            }
            catch { }
        }

        public DialogHost(Window owner, string title, double width, double height)
            : this(owner, title, width, height, false)
        {
        }

        // autoHeight=true：按内容精确定高（SizeToContent.Height）且禁用滚动条，用于“内容恰好可见”的弹窗
        public DialogHost(Window owner, string title, double width, double height, bool autoHeight)
        {
            WindowStyle = WindowStyle.None;
            AllowsTransparency = true;
            Background = Brushes.Transparent;
            ResizeMode = ResizeMode.NoResize;
            ShowInTaskbar = false;
            Width = width;
            Height = height;
            Owner = owner;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;
            UseLayoutRounding = true;

            Border bd = new Border();
            bd.CornerRadius = new CornerRadius(10);
            // 弹窗底色/透明度与设置里的背景色保持一致
            bd.Background = Ui.ThemedBackground();
            bd.BorderBrush = new SolidColorBrush(Color.FromArgb(60, 255, 255, 255));
            bd.BorderThickness = new Thickness(1);
            bd.Padding = new Thickness(16, 12, 16, 14);
            Color accDial = ColorUtil.Parse(MainWindow.CurrentSettings != null ? MainWindow.CurrentSettings.Accent : "#4F8CFF",
                Color.FromArgb(255, 79, 140, 255));
            Ui.ApplyThinScrollBars(bd, accDial);

            Grid root = new Grid();
            root.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });

            TextBlock ttl = Ui.Lbl(title, 14, Colors.White, true);
            Grid.SetRow(ttl, 0);
            root.Children.Add(ttl);

            StackPanel body = new StackPanel();
            body.Margin = new Thickness(0, 12, 0, 12);
            ScrollViewer sv = new ScrollViewer();
            sv.Content = body;
            sv.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
            sv.HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
            // 内容超高时（如小窗口下的设置面板）允许滚动，避免按钮区被挤出窗口
            sv.MaxHeight = height - 76;
            Grid.SetRow(sv, 1);
            root.Children.Add(sv);

            StackPanel btns = new StackPanel() { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
            Grid.SetRow(btns, 2);
            root.Children.Add(btns);

            bd.Child = root;
            Content = bd;

            Body = body;
            Buttons = btns;

            if (autoHeight)
            {
                SizeToContent = SizeToContent.Height;
                sv.MaxHeight = double.PositiveInfinity;
                sv.VerticalScrollBarVisibility = ScrollBarVisibility.Disabled;
            }
        }

        public StackPanel Body;
        public StackPanel Buttons;

        public Button AddAction(string text, bool primary)
        {
            Button b = new Button();
            b.Content = text;
            b.FontFamily = Ui.Font;
            b.FontSize = 12.5;
            b.Padding = new Thickness(14, 5, 14, 5);
            b.Cursor = Cursors.Hand;
            b.BorderThickness = new Thickness(0);
            b.Margin = new Thickness(8, 0, 0, 0);
            if (primary)
            {
                // 主按钮（确定/确认/完成/保存）统一使用设置里的强调色
                AppSettings theme2 = MainWindow.CurrentSettings;
                b.Background = ColorUtil.Brush(theme2 != null ? theme2.Accent : "#4F8CFF");
                b.Foreground = Brushes.White;
            }
            else
            {
                b.Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255));
                b.Foreground = new SolidColorBrush(Color.FromArgb(220, 255, 255, 255));
            }
            Buttons.Children.Add(b);
            return b;
        }
    }

    public static class Dialogs
    {
        public static string DefaultAccent = "#4F8CFF";

        // 单文本编辑
        public static bool EditText(Window owner, string title, string initial, out string result)
        {
            string res = initial;
            DialogHost d = new DialogHost(owner, title, 360, 150);
            TextBox box = Ui.TextInput("", null, "editbox");
            box.Text = initial;
            box.Height = 30;
            Border wrap = Ui.WrapInput(box);
            d.Body.Children.Add(wrap);

            bool ok = false;
            Button save = d.AddAction("保存", true);
            Button cancel = d.AddAction("取消", false);
            save.Click += delegate { if (box.Text.Trim().Length > 0) { res = box.Text.Trim(); ok = true; d.Close(); } };
            cancel.Click += delegate { d.Close(); };
            box.KeyDown += delegate(object s, KeyEventArgs e)
            {
                if (e.Key == Key.Enter && box.Text.Trim().Length > 0) { res = box.Text.Trim(); ok = true; d.Close(); }
            };
            d.Loaded += delegate { box.Focus(); box.SelectAll(); };
            d.ShowDialog();
            result = res;
            return ok;
        }

        // 分类操作：名称 / 颜色 / 删除。返回 0=取消 1=保存 2=删除
        public static int EditCategory(Window owner, string title, string initialName, string initialColor,
            out string name, out string color, bool canDelete)
        {
            string resName = initialName;
            string resColor = initialColor;
            int res = 0;
            DialogHost d = new DialogHost(owner, title, 420, 250);

            TextBox box = Ui.TextInput("", null, "catname");
            box.Text = initialName;
            box.Height = 30;
            d.Body.Children.Add(Ui.Lbl("名称", 11, Color.FromArgb(160, 255, 255, 255)));
            d.Body.Children.Add(Ui.WrapInput(box));

            TextBlock colorLbl = Ui.Lbl("颜色（点击色块切换）", 11, Color.FromArgb(160, 255, 255, 255));
            colorLbl.Margin = new Thickness(0, 10, 0, 4);
            d.Body.Children.Add(colorLbl);

            WrapPanel wp = new WrapPanel();
            List<Border> swatches = new List<Border>();
            System.Action refresh = null;
            refresh = delegate
            {
                for (int i = 0; i < swatches.Count; i++)
                {
                    bool on = swatches[i].Tag != null && (swatches[i].Tag as string).ToLowerInvariant() == (resColor ?? "").ToLowerInvariant();
                    swatches[i].BorderBrush = on ? new SolidColorBrush(Colors.White) : Brushes.Transparent;
                    swatches[i].BorderThickness = new Thickness(on ? 2 : 1);
                }
            };
            for (int i = 0; i < ColorUtil.Palette.Length; i++)
            {
                string hex = ColorUtil.Palette[i];
                Border sw = new Border();
                sw.Width = 30; sw.Height = 30;
                sw.Margin = new Thickness(3);
                sw.CornerRadius = new CornerRadius(8);
                sw.Background = ColorUtil.Brush(hex);
                sw.Cursor = Cursors.Hand;
                sw.ToolTip = hex;
                sw.Tag = hex;
                AutomationProperties.SetName(sw, "CatColor_" + hex.TrimStart('#'));
                sw.MouseLeftButtonUp += delegate { resColor = hex; refresh(); };
                swatches.Add(sw);
                wp.Children.Add(sw);
            }
            d.Body.Children.Add(wp);

            if (canDelete)
            {
                Button del = d.AddAction("删除", false);
                del.Foreground = new SolidColorBrush(Color.FromArgb(255, 240, 120, 120));
                del.Click += delegate { res = 2; resName = box.Text.Trim(); d.Close(); };
            }
            Button save = d.AddAction("保存", true);
            Button cancel = d.AddAction("取消", false);
            save.Click += delegate
            {
                resName = box.Text.Trim();
                if (resName.Length > 0) { res = 1; d.Close(); }
            };
            cancel.Click += delegate { d.Close(); };
            box.KeyDown += delegate(object s, KeyEventArgs e)
            {
                if (e.Key == Key.Enter && box.Text.Trim().Length > 0)
                {
                    resName = box.Text.Trim();
                    res = 1;
                    d.Close();
                }
            };
            d.Loaded += delegate { box.Focus(); box.SelectAll(); };
            refresh();
            d.ShowDialog();
            name = resName;
            color = resColor;
            return res;
        }

        // 兼容旧调用：只做重命名 + 改色
        public static bool EditCategory(Window owner, string title, string initialName, string initialColor,
            out string name, out string color)
        {
            return EditCategory(owner, title, initialName, initialColor, out name, out color, false) == 1;
        }

        // 日程编辑：内容 + 时间（时间可空，格式 HH:mm）
        public static bool EditSchedule(Window owner, string title, string initialText, string initialTime, out string text, out string time)
        {
            string resText = initialText;
            string resTime = initialTime;
            DialogHost d = new DialogHost(owner, title, 380, 190);

            TextBox tbox = Ui.TextInput("日程内容", null, "editsched_text");
            tbox.Text = initialText;
            tbox.Height = 30;
            d.Body.Children.Add(Ui.WrapInput(tbox));

            TextBox timeBox = Ui.TextInput("时间 HH:mm（可留空）", null, "editsched_time");
            timeBox.Text = initialTime;
            timeBox.Height = 30;
            timeBox.Margin = new Thickness(0, 8, 0, 0);
            d.Body.Children.Add(Ui.WrapInput(timeBox));

            bool ok = false;
            Button save = d.AddAction("保存", true);
            Button cancel = d.AddAction("取消", false);
            save.Click += delegate
            {
                string t = tbox.Text.Trim();
                if (t.Length == 0) return;
                string tm = timeBox.Text.Trim();
                if (tm.Length > 0 && !IsValidTime(tm)) return;
                resText = t;
                resTime = tm;
                ok = true;
                d.Close();
            };
            cancel.Click += delegate { d.Close(); };
            tbox.KeyDown += delegate(object s, KeyEventArgs e)
            {
                if (e.Key == Key.Enter && tbox.Text.Trim().Length > 0)
                {
                    string t = tbox.Text.Trim();
                    string tm = timeBox.Text.Trim();
                    if (tm.Length > 0 && !IsValidTime(tm)) return;
                    resText = t; resTime = tm; ok = true; d.Close();
                }
            };
            d.Loaded += delegate { tbox.Focus(); tbox.SelectAll(); };
            d.ShowDialog();
            text = resText;
            time = resTime;
            return ok;
        }

        public static bool IsValidTime(string t)
        {
            DateTime dt;
            return DateTime.TryParseExact(t, new string[] { "H:mm", "HH:mm", "Hmm", "HHmm" },
                System.Globalization.CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None, out dt);
        }

        // 颜色选择：返回选中色或 null（取消）
        public static string PickColor(Window owner, string current)
        {
            DialogHost d = new DialogHost(owner, "选择颜色", 360, 250);
            string result = null;

            WrapPanel wp = new WrapPanel();
            wp.Width = 300;
            for (int i = 0; i < ColorUtil.Palette.Length; i++)
            {
                string hex = ColorUtil.Palette[i];
                Border sw = new Border();
                sw.Width = 34;
                sw.Height = 34;
                sw.Margin = new Thickness(4);
                sw.CornerRadius = new CornerRadius(8);
                sw.Background = ColorUtil.Brush(hex);
                sw.Cursor = Cursors.Hand;
                sw.ToolTip = hex;
                string sel = hex;
                sw.MouseLeftButtonUp += delegate { result = sel; d.Close(); };
                if (hex.ToLowerInvariant() == (current ?? "").ToLowerInvariant())
                {
                    sw.BorderBrush = new SolidColorBrush(Colors.White);
                    sw.BorderThickness = new Thickness(2);
                }
                wp.Children.Add(sw);
            }
            d.Body.Children.Add(wp);
            d.Body.Children.Add(Ui.Lbl("点击色块即可选中", 11, Color.FromArgb(130, 255, 255, 255)));

            Button cancel = d.AddAction("取消", false);
            cancel.Click += delegate { d.Close(); };
            d.ShowDialog();
            return result;
        }

        // 分类选择：返回分类名或 null（取消）；「自定义颜色」与「＋ 新建分类…」都会先取色、再命名新分类
        public static string PickCategory(Window owner, string current, string currentCustomColor)
        {
            List<string> options = new List<string>();
            for (int i = 0; i < Cats.Names.Length - 1; i++) options.Add(Cats.Names[i]); // 不含“自定义颜色”
            List<string> custom = MainWindow.CategoryList;
            for (int i = 0; i < custom.Count; i++)
                if (!options.Contains(custom[i])) options.Add(custom[i]);

            int rows = options.Count + 1;
            DialogHost d = new DialogHost(owner, "选择分类", 330, Math.Min(560, rows * 34 + 92));
            string result = null;

            for (int i = 0; i < options.Count; i++)
            {
                string cat = options[i];
                Border row = new Border();
                row.Margin = new Thickness(0, 2, 0, 2);
                row.Padding = new Thickness(8, 6, 8, 6);
                row.CornerRadius = new CornerRadius(6);
                row.Cursor = Cursors.Hand;
                row.Background = (cat == current)
                    ? new SolidColorBrush(Color.FromArgb(60, 79, 140, 255))
                    : new SolidColorBrush(Color.FromArgb(16, 255, 255, 255));

                StackPanel sp = new StackPanel() { Orientation = Orientation.Horizontal };
                Border dot = new Border();
                dot.Width = 12;
                dot.Height = 12;
                dot.CornerRadius = new CornerRadius(6);
                dot.VerticalAlignment = VerticalAlignment.Center;
                dot.Background = ColorUtil.Brush(Cats.ColorOf(cat, currentCustomColor));
                sp.Children.Add(dot);
                TextBlock lbl = Ui.Lbl(cat, 13, Colors.White);
                lbl.Margin = new Thickness(8, 0, 0, 0);
                sp.Children.Add(lbl);
                row.Child = sp;

                string sel = cat;
                row.MouseLeftButtonUp += delegate
                {
                    if (sel == "＋ 新建分类…")
                    {
                        string c = Dialogs.PickColor(owner, currentCustomColor);
                        if (c == null) return;
                        string name = "";
                        if (!Dialogs.EditText(owner, "命名新分类", "新分类", out name)) return;
                        name = name == null ? "" : name.Trim();
                        if (name.Length == 0) return;
                        MainWindow.AddCategory(name, c);
                        CustomColorCache = c;
                        result = name;
                        d.Close();
                    }
                    else
                    {
                        result = sel;
                        d.Close();
                    }
                };
                d.Body.Children.Add(row);
            }

            // 新建分类入口
            Border newRow = new Border();
            newRow.Margin = new Thickness(0, 6, 0, 2);
            newRow.Padding = new Thickness(8, 6, 8, 6);
            newRow.CornerRadius = new CornerRadius(6);
            newRow.Cursor = Cursors.Hand;
            newRow.Background = new SolidColorBrush(Color.FromArgb(24, 79, 140, 255));
            TextBlock newLbl = Ui.Lbl("＋ 新建分类…", 13, Color.FromArgb(235, 255, 255, 255), true);
            newRow.Child = newLbl;
            newRow.MouseLeftButtonUp += delegate
            {
                string c = Dialogs.PickColor(owner, currentCustomColor);
                if (c == null) return;
                string name = "";
                if (!Dialogs.EditText(owner, "命名新分类", "新分类", out name)) return;
                name = name == null ? "" : name.Trim();
                if (name.Length == 0) return;
                MainWindow.AddCategory(name, c);
                CustomColorCache = c;
                result = name;
                d.Close();
            };
            d.Body.Children.Add(newRow);

            Button cancel = d.AddAction("取消", false);
            cancel.Click += delegate { d.Close(); };
            d.ShowDialog();
            return result;
        }

        // 自定义颜色选择结果缓存（与 PickCategory 配合）
        public static string CustomColorCache;

        // ================= 待办安排弹窗：开始 / 结束 / 重复 =================
        public static bool PickArrangePlan(Window owner, string todoText, DateTime defaultDate, out ArrangePlan plan)
        {
            ArrangePlan res = new ArrangePlan();
            res.StartDate = defaultDate.Date;
            res.EndDate = defaultDate.Date;
            plan = res;
            bool ok = false;

            DialogHost d = new DialogHost(owner, "安排待办", 490, 480);

            TextBlock hint0 = Ui.Lbl("待办：", 11, Color.FromArgb(160, 255, 255, 255));
            d.Body.Children.Add(hint0);
            TextBlock todoLbl = Ui.Lbl(todoText, 12.5, Colors.White, true);
            todoLbl.TextTrimming = TextTrimming.CharacterEllipsis;
            todoLbl.MaxWidth = 440;
            todoLbl.Margin = new Thickness(0, 2, 0, 10);
            d.Body.Children.Add(todoLbl);

            // ---- 标签栏 ----
            StackPanel tabBar = new StackPanel() { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 10) };
            Border tabStart = MakeArrangeTab("开始");
            Border tabEnd = MakeArrangeTab("结束");
            Border tabRepeat = MakeArrangeTab("重复");
            tabBar.Children.Add(tabStart);
            tabBar.Children.Add(tabEnd);
            tabBar.Children.Add(tabRepeat);
            d.Body.Children.Add(tabBar);

            // ---- 开始面板 ----
            StackPanel pStart = new StackPanel();
            pStart.Children.Add(Ui.Lbl("开始日期", 12, Color.FromArgb(200, 255, 255, 255), true));
            DatePicker dpStart = MakeDatePicker(res.StartDate);
            Border wStartDp = new Border() { Margin = new Thickness(0, 4, 0, 0) };
            wStartDp.Child = dpStart;
            pStart.Children.Add(wStartDp);
            pStart.Children.Add(Ui.Lbl("开始时间（HH:mm，可留空）", 12, Color.FromArgb(200, 255, 255, 255), true));
            TextBox tbStartTime = Ui.TextInput("如 09:30", null, "ArrangeStartTime");
            tbStartTime.Text = "";
            Border wStartTm = Ui.WrapInput(tbStartTime);
            wStartTm.Margin = new Thickness(0, 4, 0, 0);
            pStart.Children.Add(wStartTm);
            d.Body.Children.Add(pStart);

            // ---- 结束面板 ----
            StackPanel pEnd = new StackPanel();
            pEnd.Visibility = Visibility.Collapsed;
            pEnd.Children.Add(Ui.Lbl("结束日期", 12, Color.FromArgb(200, 255, 255, 255), true));
            DatePicker dpEnd = MakeDatePicker(res.EndDate);
            Border wEndDp = new Border() { Margin = new Thickness(0, 4, 0, 0) };
            wEndDp.Child = dpEnd;
            pEnd.Children.Add(wEndDp);
            pEnd.Children.Add(Ui.Lbl("结束时间（HH:mm，可留空）", 12, Color.FromArgb(200, 255, 255, 255), true));
            TextBox tbEndTime = Ui.TextInput("如 17:30", null, "ArrangeEndTime");
            tbEndTime.Text = "";
            Border wEndTm = Ui.WrapInput(tbEndTime);
            wEndTm.Margin = new Thickness(0, 4, 0, 0);
            pEnd.Children.Add(wEndTm);
            TextBlock endHint = Ui.Lbl("重复时，结束日期作为系列截止；未修改结束日期则仅按重复次数生成。", 11, Color.FromArgb(150, 255, 255, 255));
            endHint.TextWrapping = TextWrapping.Wrap;
            endHint.Margin = new Thickness(0, 8, 0, 0);
            pEnd.Children.Add(endHint);
            d.Body.Children.Add(pEnd);

            // ---- 重复面板 ----
            StackPanel pRepeat = new StackPanel();
            pRepeat.Visibility = Visibility.Collapsed;
            string selRepeat = ArrangePlan.RNone;
            string[] repeatOptions = { "不重复", "每天", "每周", "每月", "每年", "农历每年" };
            string[] repeatValues = { ArrangePlan.RNone, ArrangePlan.RDay, ArrangePlan.RWeek, ArrangePlan.RMonth, ArrangePlan.RYear, ArrangePlan.RLunarYear };
            List<Action> refreshers = new List<Action>();
            for (int i = 0; i < repeatOptions.Length; i++)
            {
                string val = repeatValues[i];
                Border row = new Border();
                row.Margin = new Thickness(0, 2, 0, 2);
                row.Padding = new Thickness(10, 5, 10, 5);
                row.CornerRadius = new CornerRadius(6);
                row.Cursor = Cursors.Hand;
                Grid rg = new Grid();
                rg.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1, GridUnitType.Star) });
                rg.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
                TextBlock rl = Ui.Lbl(repeatOptions[i], 13, Colors.White);
                Grid.SetColumn(rl, 0);
                rg.Children.Add(rl);
                TextBlock mark = Ui.Lbl("✓", 13, Colors.White, true);
                mark.Visibility = Visibility.Collapsed;
                Grid.SetColumn(mark, 1);
                rg.Children.Add(mark);
                row.Child = rg;
                Action refresh = delegate
                {
                    bool sel = (selRepeat == val);
                    row.Background = sel
                        ? new SolidColorBrush(Color.FromArgb(70, 79, 140, 255))
                        : new SolidColorBrush(Color.FromArgb(16, 255, 255, 255));
                    mark.Visibility = sel ? Visibility.Visible : Visibility.Collapsed;
                };
                refreshers.Add(refresh);
                row.MouseLeftButtonUp += delegate { selRepeat = val; for (int k = 0; k < refreshers.Count; k++) refreshers[k](); };
                pRepeat.Children.Add(row);
            }
            for (int k = 0; k < refreshers.Count; k++) refreshers[k]();

            pRepeat.Children.Add(Ui.Lbl("重复次数（总发生次数，1-9999）", 12, Color.FromArgb(200, 255, 255, 255), true));
            TextBox tbCount = Ui.TextInput("1", null, "ArrangeCount");
            tbCount.Text = "1";
            Border wCount = Ui.WrapInput(tbCount);
            wCount.Margin = new Thickness(0, 4, 0, 0);
            pRepeat.Children.Add(wCount);
            TextBlock countHint = Ui.Lbl("0 或留空表示不限次数，此时需设置晚于开始日期的结束日期。", 11, Color.FromArgb(150, 255, 255, 255));
            countHint.TextWrapping = TextWrapping.Wrap;
            countHint.Margin = new Thickness(0, 8, 0, 0);
            pRepeat.Children.Add(countHint);
            d.Body.Children.Add(pRepeat);

            // ---- 状态行 ----
            TextBlock status = Ui.Lbl("", 11.5, Color.FromArgb(255, 130, 130, 130));
            status.Margin = new Thickness(0, 8, 0, 0);
            d.Body.Children.Add(status);

            // ---- 标签切换 ----
            Action<int> showTab = delegate(int idx)
            {
                pStart.Visibility = (idx == 0) ? Visibility.Visible : Visibility.Collapsed;
                pEnd.Visibility = (idx == 1) ? Visibility.Visible : Visibility.Collapsed;
                pRepeat.Visibility = (idx == 2) ? Visibility.Visible : Visibility.Collapsed;
                StyleArrangeTab(tabStart, idx == 0);
                StyleArrangeTab(tabEnd, idx == 1);
                StyleArrangeTab(tabRepeat, idx == 2);
            };
            tabStart.MouseLeftButtonUp += delegate { showTab(0); };
            tabEnd.MouseLeftButtonUp += delegate { showTab(1); };
            tabRepeat.MouseLeftButtonUp += delegate { showTab(2); };
            showTab(0);

            // ---- 确定 / 取消 ----
            Button cancelBtn = d.AddAction("取消", false);
            cancelBtn.Click += delegate { d.Close(); };
            Button okBtn = d.AddAction("确定", true);
            Action tryOk = delegate
            {
                string st = tbStartTime.Text.Trim();
                string et = tbEndTime.Text.Trim();
                if (st.Length > 0 && !IsValidTime(st)) { status.Text = "开始时间格式应为 HH:mm（如 09:30）"; return; }
                if (et.Length > 0 && !IsValidTime(et)) { status.Text = "结束时间格式应为 HH:mm（如 17:30）"; return; }
                int cnt;
                string ct = tbCount.Text.Trim();
                if (ct.Length == 0) cnt = 0;
                else if (!int.TryParse(ct, out cnt) || cnt < 0 || cnt > 9999) { status.Text = "重复次数需为 0-9999 的整数"; return; }
                DateTime sd = dpStart.SelectedDate.HasValue ? dpStart.SelectedDate.Value.Date : defaultDate.Date;
                DateTime ed = dpEnd.SelectedDate.HasValue ? dpEnd.SelectedDate.Value.Date : sd;
                if (selRepeat != ArrangePlan.RNone && cnt == 0 && ed <= sd)
                {
                    status.Text = "重复时请填写重复次数，或设置晚于开始日期的结束日期";
                    return;
                }
                res.StartDate = sd;
                res.StartTime = st;
                res.EndTime = et;
                res.EndDate = ed;
                res.RepeatType = selRepeat;
                res.RepeatCount = cnt;
                ok = true;
                d.Close();
            };
            okBtn.Click += delegate { tryOk(); };
            tbStartTime.KeyDown += delegate(object s, KeyEventArgs e) { if (e.Key == Key.Enter) { e.Handled = true; tryOk(); } };
            tbEndTime.KeyDown += delegate(object s, KeyEventArgs e) { if (e.Key == Key.Enter) { e.Handled = true; tryOk(); } };
            tbCount.KeyDown += delegate(object s, KeyEventArgs e) { if (e.Key == Key.Enter) { e.Handled = true; tryOk(); } };
            d.Loaded += delegate { dpStart.Focus(); };
            d.ShowDialog();
            return ok;
        }

        static Border MakeArrangeTab(string text)
        {
            Border b = new Border();
            b.Padding = new Thickness(16, 6, 16, 6);
            b.CornerRadius = new CornerRadius(6);
            b.Cursor = Cursors.Hand;
            b.Margin = new Thickness(0, 0, 6, 0);
            TextBlock l = Ui.Lbl(text, 13, Colors.White, true);
            b.Child = l;
            StyleArrangeTab(b, false);
            return b;
        }

        static void StyleArrangeTab(Border b, bool selected)
        {
            if (selected)
            {
                b.Background = new SolidColorBrush(Color.FromArgb(70, 79, 140, 255));
                TextBlock l = b.Child as TextBlock;
                if (l != null) l.Foreground = Brushes.White;
            }
            else
            {
                b.Background = new SolidColorBrush(Color.FromArgb(22, 255, 255, 255));
                TextBlock l = b.Child as TextBlock;
                if (l != null) l.Foreground = new SolidColorBrush(Color.FromArgb(170, 255, 255, 255));
            }
        }

        static DatePicker MakeDatePicker(DateTime d)
        {
            DatePicker dp = new DatePicker();
            dp.SelectedDate = d.Date;
            dp.FontFamily = Ui.Font;
            dp.FontSize = 12.5;
            dp.Foreground = new SolidColorBrush(Color.FromArgb(235, 255, 255, 255));
            dp.Background = new SolidColorBrush(Color.FromArgb(28, 255, 255, 255));
            dp.BorderBrush = new SolidColorBrush(Color.FromArgb(60, 255, 255, 255));
            dp.BorderThickness = new Thickness(1);
            dp.Height = 30;
            dp.Width = 210;
            dp.HorizontalAlignment = HorizontalAlignment.Left;
            return dp;
        }

        // 确认框
        public static bool Confirm(Window owner, string title, string message)
        {
            DialogHost d = new DialogHost(owner, title, 340, 150);
            TextBlock msg = Ui.Lbl(message, 12.5, Color.FromArgb(225, 255, 255, 255));
            msg.TextWrapping = TextWrapping.Wrap;
            d.Body.Children.Add(msg);
            bool ok = false;
            Button yes = d.AddAction("确定", true);
            Button no = d.AddAction("取消", false);
            yes.Click += delegate { ok = true; d.Close(); };
            no.Click += delegate { d.Close(); };
            d.ShowDialog();
            return ok;
        }

        // 月报生成后的询问：一键回撤 / 一键顺延 / 否（三选一，默认“否”）
        // 返回 "revert" / "defer" / "none"
        public static string AskMonthlyAction(Window owner, int count, DateTime target)
        {
            string result = "none";
            string sel = "none";
            DialogHost d = new DialogHost(owner, "月度总结", 480, 430);

            AppSettings theme = MainWindow.CurrentSettings;
            Color accent = ColorUtil.Parse(theme != null ? theme.Accent : "#4F8CFF", Color.FromArgb(255, 79, 140, 255));

            TextBlock q = Ui.Lbl("是否将今天及以前所有未完成日程", 14.5, Colors.White, true);
            q.TextAlignment = TextAlignment.Center;
            q.TextWrapping = TextWrapping.Wrap;
            q.Margin = new Thickness(0, 4, 0, 2);
            d.Body.Children.Add(q);
            TextBlock sub = Ui.Lbl("共 " + count + " 项 · 选择后点「确认」执行", 11, Color.FromArgb(150, 255, 255, 255));
            sub.HorizontalAlignment = HorizontalAlignment.Center;
            sub.TextAlignment = TextAlignment.Center;
            sub.Margin = new Thickness(0, 0, 0, 12);
            d.Body.Children.Add(sub);

            List<Border> rows = new List<Border>();
            List<string> vals = new List<string>();
            List<Border> dots = new List<Border>();
            Action refresh = delegate
            {
                for (int i = 0; i < rows.Count; i++)
                {
                    bool on = (vals[i] == sel);
                    rows[i].Background = on
                        ? new SolidColorBrush(Color.FromArgb(54, accent.R, accent.G, accent.B))
                        : new SolidColorBrush(Color.FromArgb(14, 255, 255, 255));
                    rows[i].BorderBrush = on ? new SolidColorBrush(accent) : Brushes.Transparent;
                    dots[i].Background = on ? new SolidColorBrush(accent) : Brushes.Transparent;
                    dots[i].BorderBrush = on ? new SolidColorBrush(accent) : new SolidColorBrush(Color.FromArgb(120, 255, 255, 255));
                }
            };

            Action<string, string, string> addRow = delegate(string value, string title, string desc)
            {
                Border row = new Border();
                row.CornerRadius = new CornerRadius(8);
                row.BorderThickness = new Thickness(1);
                row.Padding = new Thickness(10, 8, 10, 8);
                row.Margin = new Thickness(0, 3, 0, 3);
                row.Cursor = Cursors.Hand;
                StackPanel sp = new StackPanel() { Orientation = Orientation.Horizontal };
                Border dot = new Border();
                dot.Width = 14;
                dot.Height = 14;
                dot.CornerRadius = new CornerRadius(7);
                dot.BorderThickness = new Thickness(1.5);
                dot.VerticalAlignment = VerticalAlignment.Center;
                dot.Margin = new Thickness(0, 0, 10, 0);
                sp.Children.Add(dot);
                StackPanel text = new StackPanel();
                text.Children.Add(Ui.Lbl(title, 13, Colors.White, true));
                TextBlock descLbl = Ui.Lbl(desc, 10.5, Color.FromArgb(155, 255, 255, 255));
                descLbl.TextWrapping = TextWrapping.Wrap;
                descLbl.Margin = new Thickness(0, 2, 0, 0);
                text.Children.Add(descLbl);
                sp.Children.Add(text);
                row.Child = sp;
                string v = value;
                row.MouseLeftButtonUp += delegate { sel = v; refresh(); };
                rows.Add(row);
                vals.Add(value);
                dots.Add(dot);
                d.Body.Children.Add(row);
            };

            addRow("revert", "一键回撤", "全部移回待办箱，保留分类、颜色、时间与完成状态");
            addRow("defer", "一键顺延", "统一顺延至 " + target.ToString("M月d日 dddd") + "（今天之后的第一个工作日，不逐项后移）");
            addRow("none", "否", "保持现状，不做任何处理");
            refresh();

            Button cancel = d.AddAction("取消", false);
            cancel.Click += delegate { d.Close(); };
            Button ok = d.AddAction("确认", true);
            ok.Click += delegate { result = sel; d.Close(); };
            d.ShowDialog();
            return result;
        }

        // 复制目标选择：返回 "sched" / "todo"；取消返回 false
        public static bool PickCopyTarget(Window owner, string title, out string target)
        {
            target = null;
            DialogHost d = new DialogHost(owner, title, 340, 168);
            string tgt = null;
            Button b1 = new Button();
            b1.Content = "复制为新日程（含日期/时间标签）";
            b1.FontFamily = Ui.Font;
            b1.FontSize = 12.5;
            b1.Foreground = new SolidColorBrush(Colors.White);
            b1.Background = ColorUtil.Brush("#2A3A55");
            b1.BorderThickness = new Thickness(0);
            b1.Padding = new Thickness(10, 7, 10, 7);
            b1.HorizontalAlignment = HorizontalAlignment.Stretch;
            b1.Margin = new Thickness(0, 0, 0, 8);
            b1.Cursor = Cursors.Hand;
            b1.Click += delegate { tgt = "sched"; d.Close(); };
            d.Body.Children.Add(b1);
            Button b2 = new Button();
            b2.Content = "复制为新待办";
            b2.FontFamily = Ui.Font;
            b2.FontSize = 12.5;
            b2.Foreground = new SolidColorBrush(Colors.White);
            b2.Background = ColorUtil.Brush("#2A3A55");
            b2.BorderThickness = new Thickness(0);
            b2.Padding = new Thickness(10, 7, 10, 7);
            b2.HorizontalAlignment = HorizontalAlignment.Stretch;
            b2.Cursor = Cursors.Hand;
            b2.Click += delegate { tgt = "todo"; d.Close(); };
            d.Body.Children.Add(b2);
            d.ShowDialog();
            target = tgt;
            return target != null;
        }

        // 设置面板
        public static void ShowSettings(Window owner, AppSettings s, Action apply, Action monthlyReport)
        {
            DialogHost d = new DialogHost(owner, "设置", 420, 560);

            // 背景色
            TextBlock t1 = Ui.Lbl("背景色", 12, Color.FromArgb(200, 255, 255, 255), true);
            d.Body.Children.Add(t1);
            WrapPanel bgWp = new WrapPanel();
            for (int i = 0; i < ColorUtil.BgPresets.Length; i++)
            {
                string hex = ColorUtil.BgPresets[i];
                Border sw = new Border();
                sw.Width = 34; sw.Height = 34; sw.Margin = new Thickness(3);
                sw.CornerRadius = new CornerRadius(8);
                sw.Background = ColorUtil.Brush(hex);
                sw.Cursor = Cursors.Hand;
                sw.ToolTip = hex;
                string sel = hex;
                sw.MouseLeftButtonUp += delegate { s.Background = sel; apply(); };
                if (hex.ToLowerInvariant() == s.Background.ToLowerInvariant())
                { sw.BorderBrush = new SolidColorBrush(Colors.White); sw.BorderThickness = new Thickness(2); }
                bgWp.Children.Add(sw);
            }
            // 追加完整色板
            for (int i = 0; i < ColorUtil.Palette.Length; i++)
            {
                string hex = ColorUtil.Palette[i];
                Border sw = new Border();
                sw.Width = 30; sw.Height = 30; sw.Margin = new Thickness(3);
                sw.CornerRadius = new CornerRadius(8);
                sw.Background = ColorUtil.Brush(hex);
                sw.Cursor = Cursors.Hand;
                sw.ToolTip = hex;
                string sel = hex;
                sw.MouseLeftButtonUp += delegate { s.Background = sel; apply(); };
                if (hex.ToLowerInvariant() == s.Background.ToLowerInvariant())
                { sw.BorderBrush = new SolidColorBrush(Colors.White); sw.BorderThickness = new Thickness(2); }
                bgWp.Children.Add(sw);
            }
            // 自定义颜色历史（新→旧，新选取的置顶）
            int bgHistStart = bgWp.Children.Count;
            for (int i = 0; i < Math.Min(6, s.BgHistory.Count); i++)
            {
                string hh = s.BgHistory[i];
                bgWp.Children.Add(Ui.MakeHistorySwatch(hh, delegate(string h) { s.Background = h; apply(); }));
            }
            // 自定义取色（Button 以便自动化/无障碍识别）
            Button customBg = Ui.DotButton("ColorPickBg", new SolidColorBrush(Color.FromArgb(40, 255, 255, 255)), "…", "自定义颜色…");
            customBg.Click += delegate
            {
                using (System.Windows.Forms.ColorDialog cd = new System.Windows.Forms.ColorDialog())
                {
                    Color cur = ColorUtil.Parse(s.Background, Color.FromArgb(230, 25, 26, 34));
                    cd.Color = System.Drawing.Color.FromArgb(cur.R, cur.G, cur.B);
                    if (cd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        System.Drawing.Color c = cd.Color;
                        string hex = "#" + cur.A.ToString("x2") + c.R.ToString("x2") + c.G.ToString("x2") + c.B.ToString("x2");
                        s.Background = hex;
                        Ui.PushHistory(s.BgHistory, hex, 8);
                        if (bgWp.Children.Count > bgHistStart + 6) bgWp.Children.RemoveAt(bgWp.Children.Count - 2);
                        bgWp.Children.Insert(bgHistStart, Ui.MakeHistorySwatch(hex, delegate(string h) { s.Background = h; apply(); }));
                        apply();
                    }
                }
            };
            bgWp.Children.Add(customBg);
            d.Body.Children.Add(bgWp);
            TextBlock bgHint = Ui.Lbl("前 8 块为深色预设，其后为常用色板，… 打开系统取色器（保留当前透明度）。", 10.5, Color.FromArgb(140, 255, 255, 255));
            bgHint.TextWrapping = TextWrapping.Wrap;
            bgHint.Margin = new Thickness(2, 0, 0, 0);
            d.Body.Children.Add(bgHint);

            // 强调色
            TextBlock t2 = Ui.Lbl("强调色", 12, Color.FromArgb(200, 255, 255, 255), true);
            t2.Margin = new Thickness(0, 10, 0, 0);
            d.Body.Children.Add(t2);
            WrapPanel acWp = new WrapPanel();
            for (int i = 0; i < ColorUtil.Palette.Length; i++)
            {
                string hex = ColorUtil.Palette[i];
                Border sw = new Border();
                sw.Width = 30; sw.Height = 30; sw.Margin = new Thickness(3);
                sw.CornerRadius = new CornerRadius(8);
                sw.Background = ColorUtil.Brush(hex);
                sw.Cursor = Cursors.Hand;
                sw.ToolTip = hex;
                string sel = hex;
                sw.MouseLeftButtonUp += delegate { s.Accent = sel; apply(); };
                if (hex.ToLowerInvariant() == s.Accent.ToLowerInvariant())
                { sw.BorderBrush = new SolidColorBrush(Colors.White); sw.BorderThickness = new Thickness(2); }
                acWp.Children.Add(sw);
            }
            // 强调色自定义颜色历史（新→旧，新选取的置顶）
            int acHistStart = acWp.Children.Count;
            for (int i = 0; i < Math.Min(6, s.AccentHistory.Count); i++)
            {
                string hh = s.AccentHistory[i];
                acWp.Children.Add(Ui.MakeHistorySwatch(hh, delegate(string h) { s.Accent = h; apply(); }));
            }
            // 强调色自定义取色（Button 以便自动化/无障碍识别）
            Button customAc = Ui.DotButton("ColorPickAccent", new SolidColorBrush(Color.FromArgb(40, 255, 255, 255)), "…", "自定义颜色…");
            customAc.Click += delegate
            {
                using (System.Windows.Forms.ColorDialog cd = new System.Windows.Forms.ColorDialog())
                {
                    Color cur = ColorUtil.Parse(s.Accent, Color.FromArgb(255, 79, 140, 255));
                    cd.Color = System.Drawing.Color.FromArgb(cur.R, cur.G, cur.B);
                    if (cd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    {
                        System.Drawing.Color c = cd.Color;
                        string hex = "#" + cur.A.ToString("x2") + c.R.ToString("x2") + c.G.ToString("x2") + c.B.ToString("x2");
                        s.Accent = hex;
                        Ui.PushHistory(s.AccentHistory, hex, 8);
                        if (acWp.Children.Count > acHistStart + 6) acWp.Children.RemoveAt(acWp.Children.Count - 2);
                        acWp.Children.Insert(acHistStart, Ui.MakeHistorySwatch(hex, delegate(string h) { s.Accent = h; apply(); }));
                        apply();
                    }
                }
            };
            acWp.Children.Add(customAc);
            d.Body.Children.Add(acWp);
            TextBlock acHint = Ui.Lbl("… 打开系统取色器（保留当前透明度）。", 10.5, Color.FromArgb(140, 255, 255, 255));
            acHint.TextWrapping = TextWrapping.Wrap;
            acHint.Margin = new Thickness(2, 0, 0, 0);
            d.Body.Children.Add(acHint);

            // 分隔线样式
            TextBlock t3x = Ui.Lbl("竖向分隔线样式", 12, Color.FromArgb(200, 255, 255, 255), true);
            t3x.Margin = new Thickness(0, 10, 0, 0);
            d.Body.Children.Add(t3x);
            WrapPanel dwWp = new WrapPanel();
            string[] styles = { "solid", "dash", "double", "star", "dot" };
            string[] styleNames = { "实线", "虚线", "双线", "星星", "圆点" };
            List<Border> divChips = new List<Border>();
            List<string> divKeys = new List<string>();
            Action refreshDiv = delegate
            {
                for (int k = 0; k < divChips.Count; k++)
                {
                    bool sel = (s.DividerStyle == divKeys[k]);
                    divChips[k].BorderBrush = sel ? new SolidColorBrush(Colors.White) : Brushes.Transparent;
                    divChips[k].BorderThickness = new Thickness(sel ? 2 : 0);
                }
            };
            for (int i = 0; i < styles.Length; i++)
            {
                string key = styles[i];
                Border swd = new Border();
                swd.Width = 52; swd.Height = 30; swd.Margin = new Thickness(3);
                swd.CornerRadius = new CornerRadius(8);
                swd.Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255));
                swd.Cursor = Cursors.Hand;
                TextBlock lbl = Ui.Lbl(styleNames[i], 11.5, Color.FromArgb(225, 255, 255, 255), true);
                lbl.HorizontalAlignment = HorizontalAlignment.Center;
                lbl.VerticalAlignment = VerticalAlignment.Center;
                swd.Child = lbl;
                AutomationProperties.SetName(swd, "Div" + key);
                string sKey = key;
                swd.MouseLeftButtonUp += delegate { s.DividerStyle = sKey; refreshDiv(); apply(); };
                divChips.Add(swd);
                divKeys.Add(key);
                dwWp.Children.Add(swd);
            }
            refreshDiv();
            d.Body.Children.Add(dwWp);

            // 窗口样式（月/周/日视图）
            TextBlock t2x = Ui.Lbl("窗口样式", 12, Color.FromArgb(200, 255, 255, 255), true);
            t2x.Margin = new Thickness(0, 10, 0, 0);
            d.Body.Children.Add(t2x);
            WrapPanel vmWp = new WrapPanel();
            string[] modes = { "month", "week", "day" };
            string[] modeNames = { "月视图", "周视图", "日视图" };
            string[] modeTips = { "月历 + 当日日程 + 待办（三栏）", "单周横排日历 + 日程下置，待办收起到标题行", "以日程为主体，日历收起为图标，待办收起为左侧标签" };
            List<Border> vmChips = new List<Border>();
            List<string> vmKeys = new List<string>();
            Action refreshVm = delegate
            {
                for (int k = 0; k < vmChips.Count; k++)
                {
                    bool sel = (s.ViewMode == vmKeys[k]);
                    vmChips[k].BorderBrush = sel ? new SolidColorBrush(Colors.White) : Brushes.Transparent;
                    vmChips[k].BorderThickness = new Thickness(sel ? 2 : 0);
                }
            };
            for (int i = 0; i < modes.Length; i++)
            {
                string key = modes[i];
                Border svm = new Border();
                svm.Width = 82; svm.Height = 30; svm.Margin = new Thickness(3);
                svm.CornerRadius = new CornerRadius(8);
                svm.Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255));
                svm.Cursor = Cursors.Hand;
                svm.ToolTip = modeTips[i];
                TextBlock lbl = Ui.Lbl(modeNames[i], 11.5, Color.FromArgb(225, 255, 255, 255), true);
                lbl.HorizontalAlignment = HorizontalAlignment.Center;
                lbl.VerticalAlignment = VerticalAlignment.Center;
                svm.Child = lbl;
                AutomationProperties.SetName(svm, "View" + key);
                string sKey = key;
                svm.MouseLeftButtonUp += delegate { s.ViewMode = sKey; refreshVm(); apply(); };
                vmChips.Add(svm);
                vmKeys.Add(key);
                vmWp.Children.Add(svm);
            }
            refreshVm();
            d.Body.Children.Add(vmWp);

            // 透明度
            TextBlock t3 = Ui.Lbl("整体透明度", 12, Color.FromArgb(200, 255, 255, 255), true);
            t3.Margin = new Thickness(0, 10, 0, 0);
            d.Body.Children.Add(t3);
            StackPanel opRow = new StackPanel() { Orientation = Orientation.Horizontal };
            Slider op = new Slider();
            op.Minimum = 0.35;
            op.Maximum = 1.0;
            op.Width = 240;
            op.Value = s.Opacity;
            AutomationProperties.SetName(op, "OpacitySlider");
            op.ValueChanged += delegate { s.Opacity = op.Value; apply(); };
            opRow.Children.Add(op);
            TextBlock opVal = Ui.Lbl(((int)(s.Opacity * 100)) + "%", 12, Color.FromArgb(200, 255, 255, 255));
            opVal.Margin = new Thickness(10, 0, 0, 0);
            opVal.VerticalAlignment = VerticalAlignment.Center;
            opRow.Children.Add(opVal);
            d.Body.Children.Add(opRow);
            op.ValueChanged += delegate { opVal.Text = ((int)(op.Value * 100)) + "%"; };

            // 我的皮肤（最多保存 3 种整体设置）
            TextBlock tSkin = Ui.Lbl("我的皮肤（最多 3 种）", 12, Color.FromArgb(200, 255, 255, 255), true);
            tSkin.Margin = new Thickness(0, 10, 0, 0);
            d.Body.Children.Add(tSkin);
            List<TextBlock> skinNameLbls = new List<TextBlock>();
            for (int i = 0; i < 3; i++)
            {
                int slot = i;
                Border rowSkin = new Border();
                rowSkin.CornerRadius = new CornerRadius(8);
                rowSkin.Background = new SolidColorBrush(Color.FromArgb(20, 255, 255, 255));
                rowSkin.Padding = new Thickness(8, 5, 8, 5);
                rowSkin.Margin = new Thickness(0, 3, 0, 0);
                Grid sg = new Grid();
                sg.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1, GridUnitType.Star) });
                sg.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
                TextBlock nmLbl = Ui.Lbl("（空槽位）", 11.5, Color.FromArgb(225, 255, 255, 255));
                nmLbl.VerticalAlignment = VerticalAlignment.Center;
                nmLbl.TextTrimming = TextTrimming.CharacterEllipsis;
                string curName = "";
                if (slot < s.Skins.Count && Ui.SkinName(s.Skins[slot], out curName)) nmLbl.Text = curName;
                skinNameLbls.Add(nmLbl);
                Grid.SetColumn(nmLbl, 0);
                sg.Children.Add(nmLbl);
                StackPanel sbtns = new StackPanel() { Orientation = Orientation.Horizontal };
                Button sSave = Ui.SmallButton("保存", "把当前设置保存到该槽位");
                sSave.Click += delegate
                {
                    string nm = "";
                    if (!Dialogs.EditText(d, "皮肤名称", "皮肤" + (slot + 1), out nm)) return;
                    nm = nm == null ? "" : nm.Trim();
                    if (nm.Length == 0) return;
                    while (s.Skins.Count <= slot) s.Skins.Add("");
                    s.Skins[slot] = Ui.SkinSnapshot(s, nm);
                    skinNameLbls[slot].Text = nm;
                    apply();
                };
                sbtns.Children.Add(sSave);
                Button sUse = Ui.SmallButton("应用", "整体切换到该皮肤");
                sUse.Click += delegate
                {
                    if (slot >= s.Skins.Count || string.IsNullOrEmpty(s.Skins[slot])) { System.Windows.MessageBox.Show("该槽位还没有保存皮肤", "我的皮肤"); return; }
                    string nm;
                    if (!Ui.ApplySkin(s.Skins[slot], s, out nm)) { System.Windows.MessageBox.Show("皮肤数据无效", "我的皮肤"); return; }
                    apply();
                };
                sbtns.Children.Add(sUse);
                Button sDel = Ui.SmallButton("删", "删除该皮肤");
                sDel.Click += delegate
                {
                    if (slot < s.Skins.Count) s.Skins.RemoveAt(slot);
                    skinNameLbls[slot].Text = "（空槽位）";
                    apply();
                };
                sbtns.Children.Add(sDel);
                Grid.SetColumn(sbtns, 1);
                sg.Children.Add(sbtns);
                rowSkin.Child = sg;
                d.Body.Children.Add(rowSkin);
            }

            // 置顶
            CheckBox pin = new CheckBox();
            pin.Content = "始终置顶";
            pin.FontFamily = Ui.Font;
            pin.FontSize = 12.5;
            pin.Foreground = new SolidColorBrush(Color.FromArgb(225, 255, 255, 255));
            pin.Margin = new Thickness(0, 12, 0, 0);
            pin.IsChecked = s.Topmost;
            pin.Checked += delegate { s.Topmost = true; apply(); };
            pin.Unchecked += delegate { s.Topmost = false; apply(); };
            d.Body.Children.Add(pin);

            // 贴边收起
            CheckBox dock = new CheckBox();
            dock.Content = "拖到屏幕边缘自动收起（鼠标划过展开）";
            dock.FontFamily = Ui.Font;
            dock.FontSize = 12.5;
            dock.Foreground = new SolidColorBrush(Color.FromArgb(225, 255, 255, 255));
            dock.Margin = new Thickness(0, 8, 0, 0);
            dock.IsChecked = s.EdgeDock;
            dock.Checked += delegate { s.EdgeDock = true; apply(); };
            dock.Unchecked += delegate { s.EdgeDock = false; apply(); };
            d.Body.Children.Add(dock);

            // 生成月度总结（手动触发）
            TextBlock t4 = Ui.Lbl("自动月报：每月第 3 个周一 10:30 自动生成并顺延未完成事项", 11, Color.FromArgb(170, 255, 255, 255));
            t4.Margin = new Thickness(0, 14, 0, 0);
            t4.TextWrapping = TextWrapping.Wrap;
            d.Body.Children.Add(t4);
            Button report = new Button();
            report.Content = "立即生成本月月度总结";
            report.FontFamily = Ui.Font;
            report.FontSize = 12.5;
            report.Foreground = new SolidColorBrush(Color.FromArgb(225, 255, 255, 255));
            report.Background = ColorUtil.Brush(s.Accent);
            report.BorderThickness = new Thickness(0);
            report.Padding = new Thickness(10, 5, 10, 5);
            report.HorizontalAlignment = HorizontalAlignment.Left;
            report.Margin = new Thickness(0, 8, 0, 0);
            report.Cursor = Cursors.Hand;
            // 先生成月报并关闭设置窗口，再弹出“一键回撤/一键顺延/否”的询问窗口
            report.Click += delegate { d.Close(); monthlyReport(); };
            d.Body.Children.Add(report);

            Button done = d.AddAction("完成", true);
            done.Click += delegate { d.Close(); };
            d.ShowDialog();
        }
    }
}
