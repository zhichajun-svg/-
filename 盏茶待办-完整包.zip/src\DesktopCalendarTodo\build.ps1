# DesktopCalendarTodo build script (no network, no NuGet)
# Uses in-box .NET Framework csc.exe + GAC reference assemblies.
# Optional -OutDir: emit the exe into another directory (used by tests); defaults to release.
param([string]$OutDir = "")
$ErrorActionPreference = "Stop"

$srcDir = Split-Path -Parent $PSScriptRoot            # ...\src
$projDir = Split-Path -Parent $srcDir                  # project root (UTF-8 path, no literal here)
$src = Join-Path $srcDir "DesktopCalendarTodo"
$outDir = $OutDir
if ([string]::IsNullOrEmpty($outDir)) { $outDir = Join-Path $projDir "release" }
if (-not (Test-Path -LiteralPath $outDir)) { New-Item -ItemType Directory -Path $outDir | Out-Null }
$out = Join-Path $outDir "DesktopCalendarTodo.exe"

$csc = "C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if (-not (Test-Path $csc)) { $csc = "C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe" }

$gac = "C:\Windows\Microsoft.NET\assembly"

function Get-Ref([string]$asm) {
    foreach ($root in @("GAC_MSIL", "GAC_32", "GAC_64")) {
        $cand = Join-Path (Join-Path $gac $root) $asm
        $found = Get-ChildItem -Path $cand -Recurse -Filter "$asm.dll" -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($found) { return $found.FullName }
    }
    throw "Cannot find reference assembly: $asm"
}

# WPF 程序集需显式引用；System.* 系列由 csc 自动引用，重复引用会报 CS1703
$refs = @(
    (Get-Ref "PresentationFramework"),
    (Get-Ref "PresentationCore"),
    (Get-Ref "WindowsBase"),
    (Get-Ref "System.Xaml")
)

$names = @("Json.cs", "Lunar.cs", "Models.cs", "DataStore.cs", "Monthly.cs",
           "UiKit.cs", "MainWindow.cs", "Panels.cs", "Notes.cs", "Export.cs", "Tray.cs", "Program.cs")
$sources = @()
foreach ($n in $names) { $sources += (Join-Path $src $n) }

$argList = @()
$argList += "/nologo"
$argList += "/target:winexe"
$argList += "/platform:anycpu"
$argList += "/optimize+"
$argList += "/codepage:65001"
$argList += "/utf8output"
$argList += "/out:$out"
foreach ($r in $refs) { $argList += "/r:$r" }
$argList += $sources

& $csc $argList
if ($LASTEXITCODE -ne 0) { throw "csc failed with exit code $LASTEXITCODE" }

Write-Output ("BUILD OK: " + $out)
